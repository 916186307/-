<template>
  <div class="all">
    <div class="top-back" @click="$router.go(-1)">
      <img class="top-back-logo" src="static/home/topBack.png" alt="">
      <div class="tit">
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
    export default {

    }
</script>

<style scoped>
  .top-back{
    width: 100%;
    /* padding: 20px; */
    background-color: transparent;
    line-height: 60px;
    /* margin-top: 20px; */
    overflow: hidden;
  }
  .top-back img {
    display: inline-block;
    margin-left: 30px;
    margin-top: 50px;
    line-height: 70px;
  }
  .top-back-logo{
    width: 50px;
  }
  .tit {
    display: block;
    font-weight: bold;
    font-size:36px;
    font-family:MicrosoftYaHei-Bold;
    font-weight:bold;
    color:rgba(31,31,31,1);
    margin-left: 30px;
    margin-top: 32px;
    margin-bottom: 51px;
  }
</style>
