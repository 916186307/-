<template>
  <div class="scope">
    <div class="top-head">
      <input placeholder="Search" @focus="upSearch" type="search">
      <img class="search" src="@/assets/img/icon/search.png" >
      <img class="ling" src="@/assets/img/icon/ling.png" >
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    upSearch() {
      this.$router.push({
        name: 'SearchPage'
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.top-head {
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 30px;
  margin: 10px 0 0 30px;
  padding: 10px 20px;
  overflow: hidden;
  >input {
    box-sizing: border-box;
    padding: 10px 70px 0 70px;
    line-height: 1;
    width: 633px;
    height: 76px;
    border-radius: 25PX;
    border: none;
    outline: none;
    background-color: #fff;
    margin-right: 60px;
  }
  >input[href=placeholder] {
    color: #aeaeaa;
  }
  >.search {
    position: absolute;
    left: 39px;
    top: 30px;
    width: 40px;
    height: 40px;
  }
  >.ling {
    margin-right: 30px;
    width: 34px;
    // height: 44px;
  }
}

</style>

