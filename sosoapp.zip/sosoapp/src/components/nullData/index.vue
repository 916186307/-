<template>
    <div class="null-box">
        <img src="@/assets/img/icon/null-data.png" >
        <div class="tit">暂无数据</div>
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang="scss" scoped>
    .null-box {
        width: 700px;
        border-radius: 10PX;
        background-color: #fff;
        margin: 20px auto 0;
        padding-bottom: 40px;
        text-align: center;
        >.tit {
            font-size: 30px;
        }
        >img {
            width: 300px;
        }
    }
</style>

