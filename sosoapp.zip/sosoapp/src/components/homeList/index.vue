<template>
  <div>
    <div  v-if="list.length !== 0">
      <div v-for="item in list" :key="item.cardTypeName" class="b-list" @click="$router.push({name: 'AppDetail',query:{id: item.id}})">
        <div class="img-banner">
          <img v-lazy="item.main_img">
        </div>
        <div class="center-msg">
          <div class="img-star">
            <img class="img-ls" src="static/home/star-lever.png" alt="">
            <span class="star-msg">8.2</span>
          </div>
          <div class="tit" v-text="item.name"></div>
          <div class="msg">{{item.desc | voerfllow50}}</div>
          <div class="bottom-box">
          </div>
        </div>
        <div class="left">
          <button class="btn-tab" v-show="i" v-for="i in item.tags" :key="i.cardTypeName" >{{i ? i.tags : ''}}</button>
          <div class="d-in">
            <!-- <img class="img-logo-ls" src="static/home/star-logo.png" alt="">
            <button class="btn-logo">收藏</button>
            <img class="img-logo-ls" src="static/home/msg-logo.png" alt="">
            <button class="btn-logo">评论</button> -->
          </div>
        </div>

      </div>

    </div>

    <nullData v-show="list.length === 0"></nullData>


  </div>
</template>

<script>
import nullData from '@/components/nullData'

export default {
  props: {
    list: {
      type: Array,
      default: function() {
        return []
      }
    }
  },
  components: {
    nullData
  }
}
</script>

<style lang="scss" scoped>
  .b-list {
  box-sizing: border-box;
  border-radius: 10PX;
  width: 700px;
  margin: 20px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 14px 16px -16px rgba(174,174,174,.3);
}

  // 中心消息
  .center-msg {
    margin: 50px auto;
    margin-bottom: 40px;
    max-height: 400px;
    overflow: hidden;
    > .tit {
      font-size: 32px;
      font-weight: bold;
    }
    > .msg {
      color: #888;
      margin-top: 30px;
      font-size: 26px;
    }
    > .bottom-box {
      // margin-top: 60px;
      > .left {
        /*float: left;*/
        margin: 20px;
        /*display: flex;*/
        width: 200px;
        /*justify-content: space-between;*/
        color: #888;
      }
      > .right {
        float: right;
        display: flex;
        width: 200px;
        justify-content: space-between;
        color: #999;
        img {
          width: 30px;
        }
        span {
          display: inline-flex;
          align-items: center;
        }
      }
    }
    
  }

  .img-banner {
    display: flex;
    justify-content: center;
    align-items: center;
    max-width: 700px;
    height: 300px;
    border-radius: 20PX;
    margin: auto;
    margin-top: 20px;
    >img {
      border-radius: 5PX;
      width: 100%;
      height: 100%;
    }
  }
  .img-star {
    display: flex;
    align-items: center;
  }

  .img-ls{
    width: 30px;
    height: 30px;
    margin-right: 10px;
  }
  .img-star{
    float: right;
  }
  .star-msg{
    font-size: 26px;
    color: RGB(171,170,170);
  }
  .btn-tab{
    margin: 20px 10px 10px 0;;
    background-color: RGB(238,238,238);
    border: 0;
    font-size: 26px;
    padding: 10px 20px;
    border-radius: 5px;
    opacity: 0.9;
  }
  .d-in{
    display: inline-flex;
    align-items: center;
    float: right;
    font-size: 26px;
    margin-top: 30px;
  }
  .btn-logo{
    // margin: 0 10px;
    // background-color: RGB(238,238,238);
    background-color: transparent;
    font-size: 26px;
    color: RGB(145,146,149);
    border:0;
    border-radius: 5px;
    /*opacity: 0.9;*/
  }
  .img-logo-ls{
    width: 28px;
    height: 28px;
  }
</style>


