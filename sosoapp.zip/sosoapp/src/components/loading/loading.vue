<template>
  <div class="loading">
    <mt-spinner type="double-bounce"></mt-spinner>
  </div>
</template>

<style scoped>
  .loading {
    display: flex;
    justify-content: center;
  }
</style>
