import loadingComponent from './loading.vue'

const loading = {
  install: function(vue) {
    vue.component('Loading', loadingComponent)
  }
}

export default loading
