import request from '@/utils/request';

/** 登录
 * @param  {} account  登录账号 昵称或者手机号
 * @param  {} password 
 */
export function login(data) {
  return request({
    url: '/spider/user/login',
    method: 'post',
    data: data
  })
}

/** 获取验证码
 * @param  {string} phone  手机号
 * @param  {int} type 1 注册 2登陆 3找回密码
 */
export function getCode(data) {
  return request({
    url: '/spider/user/code',
    method: 'post',
    data: data
  })
}

/** 注册
 * @param  {string} phone  手机号
 * @param  {int} code 手机验证码
 * @param  {int} password 密码
 * @param  {int} type 1 直接用户 2中间用户 3公司用户
 */
export function regist(data) {
  return request({
    url: '/spider/user/register',
    method: 'post',
    data: data
  })
}

/** 找回密码
 * @param  {string} new  新密码
 * @param  {int} phone 手机号	
 * @param  {int} code 验证码	
 */
export function setPwd(data) {
  return request({
    url: '/spider/user/reset',
    method: 'post',
    data: data
  })
}

/** 获取用户信息
 * @param 
 */
export function getInfo() {
  return request({
    url: '/spider/user/info',
    method: 'get'
  })
}

/** 获取用户信息
 * @param 
 */
export function setInfo(data) {
  return request({
    url: '/spider/user/info',
    method: 'put',
    data
  })
}

/** 退出登录
 */
export function logout() {
  return request({
    url: '/spider/user/logout',
    method: 'delete'
  })
}

/** 获取收藏列表
 */
export function getSc() {
  return request({
    url: '/spider/favorite/dapp',
    method: 'get'
  })
}

/** 站内转eos
 * nickname
 * eos
 */
export function transfer(data) {
  return request({
    url: '/spider/user/site/transfer',
    method: 'post',
    data: data
  })
}

/** 获取eos余额
 * nickname
 * eos
 */
export function getEos() {
  return request({
    url: '/spider/balance/eos',
    method: 'get'
  })
}

/** 用户设置二维码
 * @param  {} wx  wx
 * @param  {} ali 支付宝二维码
 */
export function setToCode(data) {
  return request({
    url: '/spider/user/qrcode',
    method: 'put',
    data: data
  })
}

/** 用户获取自己二维码
 */
export function getToCode() {
  return request({
    url: '/spider/user/qrcode',
    method: 'get'
  })
}

/** 用户获取自己的支付密码
 * @param {} pay_code
 */
export function setPayPwd(data) {
  return request({
    url: '/spider/user/set/pay',
    method: 'put',
    data: data
  })
}
