import request from '@/utils/request';

/** 示例接口
 * @param  {} location 
 * @param  {} type_id 
 * @param  {} tag_id 
 * @param  {} name 
 */
export function getDappList(data) {
  return request({
    url: '/spider/dapps',
    method: 'get',
    params: data
  })
}

/** 收藏dapp列表
 * @param  {} dapp_id 
 */
export function scDapp(data) {
  return request({
    url: '/spider/favorite/dapp',
    method: 'post',
    data: data
  })
}

/** 收藏dapp列表
 * @param  {} dapp_id 
 */
export function delDapp(data) {
  return request({
    url: '/spider/favorite/dapp',
    method: 'delete',
    data: data
  })
}

/** 区块链币的数据排行
 * @param  {} name
 */
export function getDappData(data) {
  return request({
    url: '/spider/coin/search',
    method: 'get',
    params: data
  })
}

/** 区块链币的数据排行
 * @param  {}
 */
export function getTop(data) {
  return request({
    url: '/spider/home/top',
    method: 'post',
    data: data
  })
}

