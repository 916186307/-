import request from '@/utils/request';

/** 上传文件
 * @param  {} type	类型 1图片 2音频 3文件 4视频
 * @param  {} file  文件
 */
export function upfile(data) {
  return request({
    url: '/spider/user/upload',
    method: 'post',
    data: data
  })
}

