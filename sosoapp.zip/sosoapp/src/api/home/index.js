import request from '@/utils/request';

/** 示例接口
 * @param  {} data 
 */
export function getHomeData(data) {
  return request({
    url: '/api/***',
    method: 'post',
    data: data
  })
}

/** 获取app详情
 * @param  {} data 
 */
export function getAppDetail(id) {
  return request({
    url: `/spider/dapp/${id}`,
    method: 'get',
    data: {}
  })
}

/** 获取app列表
 * @param  {} data 
 */
export function getAppList(data) {
  return request({
    url: 'spider/dapps',
    method: 'get',
    params: data
  })
}

/** 获取轮播图
 * @param  {} data 
 */
export function getBanner() {
  return request({
    url: '/spider/banner',
    method: 'get'
  })
}
