import request from '@/utils/request';

/** 用户二维码公开表
 */
export function getQrcodes() {
  return request({
    url: '/spider/user/qrcodes',
    method: 'get'
  })
}

/** 获取交易列表
 */
export function getDealList(data) {
  return request({
    url: '/spider/deal',
    method: 'get',
    params: data
  })
}

/** 添加交易列表
 * @param {} type
 * @param {} eos
 * @param {} eos_price
 */
export function addDeal(data) {
  return request({
    url: '/spider/deal',
    method: 'post',
    data
  })
}

/**
 * 获取订单列表
 * @param   {[type]}  1 买 2 卖  
 */
export function getOrderList(data) {
  return request({
    url: '/spider/deal/user',
    method: 'get',
    params: data
  })
}

/**
 * 下单
 * @param   {[number]} id
 */
export function placeOrder(id) {
  return request({
    url: '/spider/deal/buy',
    method: 'put',
    data: {
      id
    }
  })
}

/**
 * 获取币价
 */
export function getEosPrice() {
  return request({
    url: '/spider/coin/price',
    method: 'get'
  })
}

/**
 * 商户创建订单
 * @param type  1买 2卖	
 * @param rate  汇率	
 * @param eos_up eos个数上限 
 * @param eos_down eos个数下限
 * @param pay_pwd 交易密码
 * 
 */
export function createOrder(data) {
  return request({
    url: '/spider/merchant/create',
    method: 'post',
    data
  })
}

/**
 * 获取商户创建订单
 * @param type  1买 2卖	
 * 
 */
export function getCreateOrder(data) {
  return request({
    url: '/spider/merchant',
    method: 'get',
    params: data
  })
}

/**
 * 用户创建订单
 * @param type  1买 2卖	
 * @param eos 
 * @param id 
 * 
 */
export function userCreateOrder(data) {
  return request({
    url: '/spider/deal',
    method: 'post',
    data
  })
}

/**
 * 标记为已支付
 * @param id 
 * 
 */
export function markPay(id) {
  return request({
    url: '/spider/deal/pay',
    method: 'put',
    data: {
      id
    }
  })
}

/**
 * 取消订单
 * @param id 
 * 
 */
export function cancelOrder(id) {
  return request({
    url: '/spider/deal/cancel',
    method: 'put',
    data: {
      id
    }
  })
}

/**
 * 查询订单详情
 * @param id 
 * 
 */
export function getOrderDetail(id) {
  return request({
    url: '/spider/deal/info',
    method: 'get',
    params: {
      id
    }
  })
}

/**
 * 商家放行EOS
 * @param id 
 * 
 */
export function releaseEos(data) {
  return request({
    url: '/spider/deal/transfer',
    method: 'put',
    data: data
  })
}
