<template>
  <div id="app">
    <router-view class="route"/>
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  }
}
</script>

<style>
html,body {
  height: 100%;
}
#app {
  box-sizing: border-box;
  width: 750px;
  height: 100%;
  margin: 0 auto;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
</style>
