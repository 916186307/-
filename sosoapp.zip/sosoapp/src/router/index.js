import Router from 'vue-router'
import store from '../store'
import { getInfo } from '@/api/user'

let router = new Router({
  // mode: 'history',
  routes: [
    // 首页
    {
      path: '/',
      name: 'Foots',
      // redirect: '/tabTransaction',
      redirect: '/home',
      meta: { title: 'phone.index' },
      component: resolve => require(['@/view/foots'], resolve),
      children: [
        // 主页
        {
          path: '/home',
          name: 'Home',
          meta: { title: 'phone.index' },
          component: resolve => require(['@/view/home'], resolve)
        },
        // 排行
        {
          path: '/sort',
          name: 'Sort',
          meta: { title: '排行榜' },
          component: resolve => require(['@/view/sort'], resolve)
        },
        // 行情
        {
          path: '/market',
          name: 'market',
          meta: { title: '行情' },
          component: resolve => require(['@/view/market'], resolve)
        },
        // 社区
        {
          path: 'community',
          name: 'Community',
          meta: { title: '社区' },
          component: resolve => require(['@/view/community'], resolve)
        },
        // 糖果盒
        {
          path: 'candy',
          name: 'Candy',
          meta: { title: '糖果盒' },
          component: resolve => require(['@/view/candy'], resolve)
        },
        // 我的
        {
          path: 'my',
          name: 'My',
          meta: { title: '我的' },
          requireAuth: true,
          component: resolve => require(['@/view/my'], resolve)
        },
        {
          path: 'assets',
          name: 'Assets',
          meta: { title: '资产' },
          component: resolve => require(['@/view/assets'], resolve)
        }
      ]
    },
    {
      path: '/appDetail',
      name: 'AppDetail',
      meta: { title: 'app详情' },
      component: resolve => require(['@/view/appDetail'], resolve)
    },
    {
      path: '/tc',
      name: 'Tc',
      meta: { title: '转账' },
      component: resolve => require(['@/view/assets/tc'], resolve)
    },
    {
      path: '/receipt',
      name: 'Receipt',
      meta: { title: '收款' },
      component: resolve => require(['@/view/assets/receipt'], resolve)
    },
    {
      path: '/collection',
      name: 'Collection',
      meta: { title: '我的收藏' },
      component: resolve => require(['@/view/my/collection'], resolve)
    },
    {
      path: '/feedback',
      name: 'Feedback',
      meta: { title: '我的收藏' },
      component: resolve => require(['@/view/my/feedback'], resolve)
    },
    {
      path: '/aboutMe',
      name: 'AboutMe',
      meta: { title: '关于我们' },
      component: resolve => require(['@/view/my/aboutMe'], resolve)
    },
    {
      path: '/addCommunity',
      name: 'AddCommunity',
      meta: { title: '加入社群' },
      component: resolve => require(['@/view/my/addCommunity'], resolve)
    },
    {
      path: '/login',
      name: 'Login',
      meta: { requireAuth: true, title: '登录' },
      component: resolve => require(['@/view/login'], resolve)
    },
    {
      path: '/regist',
      name: 'Regist',
      meta: { requireAuth: true, title: '注册' },
      component: resolve => require(['@/view/login/regist'], resolve)
    },
    {
      path: '/setPwd',
      name: 'SetPwd',
      meta: { requireAuth: true, title: '找回密码' },
      component: resolve => require(['@/view/login/setPwd'], resolve)
    },
    {
      path: '/searchPage',
      name: 'SearchPage',
      meta: { requireAuth: true, title: '搜索dapp' },
      component: resolve => require(['@/view/searchPage'], resolve)
    },
    {
      path: '/order',
      name: 'Order',
      meta: { requireAuth: true, title: '订单记录' },
      component: resolve => require(['@/view/assets/order'], resolve)
    },
    {
      path: '/payway',
      name: 'payWay',
      meta: { requireAuth: true, title: '收款方式' },
      component: resolve => require(['@/view/assets/payway'], resolve)
    },
    {
      path: '/payfor',
      name: 'payFor',
      meta: { requireAuth: true, title: '付款界面' },
      component: resolve => require(['@/view/assets/payfor'], resolve)
    },
    {
      path: '/joingroup',
      name: 'joinGroup',
      meta: { requireAuth: true, title: '加入社群' },
      component: resolve => require(['@/view/joinGroup'], resolve)
    },
    {
      path: '/privacy',
      name: 'Privacy',
      meta: { requireAuth: true, title: '隐私政策' },
      component: resolve => require(['@/view/my/privacy'], resolve)
    },
    {
      path: '/useragreement',
      name: 'UserAgreement',
      meta: { requireAuth: true, title: '用户协议' },
      component: resolve => require(['@/view/my/useragreement'], resolve)
      
    },
    {
      path: '/systemSet',
      name: 'SystemSet',
      meta: { requireAuth: true, title: '系统设置' },
      component: resolve => require(['@/view/my/system'], resolve)
    },
    {
      path: '/safecenter',
      name: 'SafeCenter',
      meta: { requireAuth: true, title: '安全中心' },
      component: resolve => require(['@/view/my/safecenter'], resolve)
    },
    {
      path: '/accountmodify',
      name: 'AccountModify',
      meta: { requireAuth: true, title: '账号密码修改' },
      component: resolve => require(['@/view/my/accountmodify'], resolve)
    },
    {
      path: '/passwordmodify',
      name: 'PasswordModify',
      meta: { requireAuth: true, title: '交易密码修改' },
      component: resolve => require(['@/view/my/passwordmodify'], resolve)
    },
    {
      path: '/othersetting',
      name: 'OtherSetting',
      meta: { requireAuth: true, title: '其他设置' },
      component: resolve => require(['@/view/my/othersetting'], resolve)
    },
    {
      path: '/tabTransaction',
      name: 'TabTransaction',
      meta: { requireAuth: true, title: '交易' },
      component: resolve => require(['@/view/assets/tab-transaction'], resolve)
    },
    {
      path: '/feedback',
      name: 'Feedback',
      meta: { requireAuth: true, title: '建议反馈' },
      component: resolve => require(['@/view/my/feedback'], resolve)
    },
    {
      path: '/submitorder',
      name: 'SubmitOrder',
      meta: { requireAuth: true, title: '挂单' },
      component: resolve => require(['@/view/assets/tab-transaction/submitorder'], resolve)
    }
  ]
})

router.beforeEach((to, from, next) => {
  getInfo().then(d => {
    store.commit('setUserInfo', d.data)
  }).catch(() => {
    store.commit('setUserInfo', '')
    next({
      path: '/login'
    })
  })

  if (!to.meta.requireAuth) { // 判断该路由是否需要登录权限
    if (store.state.token) { // 通过vuex state获取当前的token是否存在
      next()
    } else {
      next({
        path: '/login'
      })
    }
  } else {
    next();
  }
})

export default router
