<template>
  <div class="box"  v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
    <!-- <mt-header title="首页">
      <div @click="$router.go(-1)" slot="left">
        <mt-button icon="back"></mt-button>
      </div>
      <mt-button icon="more" slot="right"></mt-button>
    </mt-header> -->
    <header-search></header-search>

    <div class="row">
      <div class="l">
        <span class="tit">今日</span>
        <span class="min">推荐</span>
      </div>
      <div class="r">
        3月7日
      </div>
    </div>

    <!-- 轮播图 -->
    <div class="swiper-container banner-top">
      <div class="swiper-wrapper">
          <!-- <div class="swiper-slide" v-for="item in bannerList" :key="item.cardTypeName" >
            <a :href="item.goto_url">
              <img :src="item.img_url" >
            </a>
          </div> -->
          <div class="swiper-slide">
            <img src="@/assets/img/image/b4.png" >
          </div>
          <div class="swiper-slide">
            <img src="@/assets/img/image/b5.png" >
          </div>
      </div>
      <div class="swiper-pagination banner-top-pagination"></div>
    </div>

    <div class="type-tit top">
      最新
    </div>

    <div class="center-banner">
      <div class="swiper-box">
        <div class="item" v-for="item in dapps" :key="item.cardTypeName" @click="$router.push({ name: 'AppDetail',query: { id: item.id } })">
          <img :src="item.logo" >
          <div class="name">{{item.name}}</div>
          <div class="dsc">
            <span>{{item.one_word.slice(0,10)}}</span>
            <!-- <span v-for="i in item.tags" :key="i.cardTypeName">{{i.tags}}</span> -->
          </div>
        </div>
      </div>
    </div>
    <!-- <div class="swiper-container banner-center">
      <div class="swiper-wrapper">
          <div class="swiper-slide" v-for="item in dapps" :key="item.cardTypeName" :style="`background-image: url(${item.main_img})`"></div>
      </div>
    </div> -->
    <div class="type-tit">
      游戏列表
    </div>
    
    <div v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
      <homeList :list="list"></homeList>
    </div>
    
    <div class="t-c" v-show="loading">
      <mt-spinner type="double-bounce"></mt-spinner>
    </div>

  </div>
</template>
<script>
import headerSearch from '@/components/header';
import { getAppList, getBanner } from '@/api/home'
import Swiper from 'swiper'
import homeList from '@/components/homeList'
export default {
  components: {
    homeList,
    headerSearch
  },
  data() {
    return {
      loading: false,
      pageInfo: {
        page: 1,
        limits: 10,
        total: 0
      },
      bannerList: [],
      dapps: [],
      list: []
    }
  },
  created() {
    this.init()
  },
  mounted() {
    
  },

  methods: {
    init() {
      getAppList({
        limits: this.pageInfo.limits,
        page: this.pageInfo.page,
        location: '',
        type_id: ''
      }).then(d => {
        this.list = d.data.date
        this.dapps = d.data.date.splice(0, 5)
      }).then(() => {
        new Swiper('.banner-center', {
          loop: true,
          // pagination: '.swiper-pagination'
          centeredSlides: true
        })
      })

      getBanner().then(d => { this.bannerList = d.data.date }).then(() => {
        new Swiper('.banner-top', {
          loop: true,
          // pagination: '.swiper-pagination'
          pagination: {
            el: '.banner-top-pagination'
          }
        })
      })
    },

    loadMore() {
      this.pageInfo.page++
      this.getLst()
    },

    getLst() {
      this.loading = true
      getAppList({
        limits: this.pageInfo.limits,
        page: this.pageInfo.page,
        location: '',
        type_id: ''
      }).then(d => {
        console.log(d)
        // this.list.concat(d.data.date)
        for (const ele of d.data.date) {
          this.list.push(ele)
        }
        this.loading = false
      })
    }
  }
}
</script>
<style lang="scss" scoped>
  @import "../../../node_modules/swiper/dist/css/swiper.css";
  .banner-top {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 769px;
    // border-radius: 15px;
    margin: auto;
    margin-top: 20px;
  }

  .center-banner {
    width: 700px;
    margin: auto;
    overflow: auto;
    >.swiper-box {
      display: flex;
      width: 1200px;
      >.item {
        width: 298px;
        margin: 0 20px;
        >img {
          border-radius: 8PX;
          width: 298px;
          height: 298px;
        }
        >.name {
          font-size: 30px;
          /*font-weight: bold;*/
          margin-top: 10px;
          /*margin-bottom: 2px;*/
        }
        >.dsc {
          >span {
            display: inline-block;
            font-size: 26px;
            letter-spacing: 1px;
            color: #bebebe;
            // background-color: #fff;
            border-radius: 5PX;
            padding: 0 10px 0 0;
            margin: 0 10px 0 0;
            line-height: 5px;
          }
        }
      }
    }
  }

  .row {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    width: 670px;
    margin: 29px auto 0;
    >.l {
      >.tit {
        font-weight: bold;
        font-size: 60px;
        color: #0f0f0f;
      }
      >.min {
        font-size: 30px;
        letter-spacing: 1px;
        color: #c4c4c4;
      }
    }
    >.r {
      font-size: 22px;
      line-height: 35px;
      letter-spacing: 0px;
      color: #d1d1d1;
    }
  }

  .type-tit {
    width: 670px;
    font-weight: bold;
    font-size: 60px;
    letter-spacing: 1px;
    color: #0f0f0f;
    margin: 50px auto 20px;
  }
  
  .type-tit.top {
    margin-top: 10px;
  }

</style>
<style>
/* swipper 样式 */
.banner-top {
  height: 808px !important;
}

.banner-center {
  width: 700px;
}

.banner-center .swiper-slide {
  height: 469px !important;
  width: 298px  !important;;
  border-radius: 15PX;
  background-repeat: no-repeat;
  background-position: center center;
  background-size: auto 100%;
}

.banner-top-pagination {
  bottom: 5px !important;
}
.swiper-pagination-bullets > span {
  display: inline-block;
  width: 15px;
  height: 15px;
  margin: 0 5px;
  border-radius: 50%;
  background-color: #37d4e2;
  transition: all .4s ease;
}
.swiper-pagination-bullets > span.swiper-pagination-bullet-active {
  background-color: #e5e5e5;
  width: 30px;
  border-radius: 10px;
}
.banner-top .swiper-slide {
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  height: 769px !important;
  border-radius: 15PX;
  background-repeat: no-repeat;
  background-position: center center;
}
.banner-top .swiper-slide img{
  display: block;
  margin: auto;
  border-radius: 10PX;
  height: 750px;
  width: 700px;
}

.t-c {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
