<template>
  <div>
    <mt-header title="社区">
      <div @click="$router.go(-1)" slot="left">
        <mt-button icon="back"></mt-button>
      </div>
      <mt-button icon="more" slot="right"></mt-button>
    </mt-header>
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang="scss" scoped>

</style>


