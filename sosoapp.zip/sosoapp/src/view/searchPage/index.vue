<template>
  <div class="scoped">
    <div class="search-box">
      <img src="@/assets/img/icon/search.png" class="l" >
      <input @keyup.13="search" v-model="name" ref="search" type="text" placeholder="Search">
      <!-- <img class="r" src="@/assets/img/icon/ling.png" > -->
      <span class="r" @click="$router.go(-1)">取消</span>
    </div>

    <div v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
      <home-list :list="listData"></home-list>
    </div>

    <!-- <ul v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
      <li class="item" @click="$router.push({ name: 'AppDetail', query:{ id: item.id } })" v-for="item in listData" :key="item.cardTypeName" :style="`background-image: url(${item.main_img})`" >
        <div class="name">{{item.name}}</div>
        <div class="score">
          <img src="@/assets/img/icon/xing@2x.png">
          <span>{{item.scores}}</span>
        </div>
        <div class="type-box">
          <span v-for="i in item.tags" :key="i.cardTypeName">{{i.tags}}</span>
        </div>
      </li>
    </ul> -->

    <div class="t-c" v-show="loading">
      <mt-spinner type="double-bounce"></mt-spinner>
    </div>

  </div>
</template>

<script>
import { getDappList } from '@/api/dapp'
import homeList from '@/components/homeList'
// import homeList from '';
export default {
  components: {
    homeList
  },
  data() {
    return {
      listData: [],
      name: '',
      loading: false,
      pageInfo: {
        limits: 10,
        page: 1,
        total: 0
      }
    }
  },
  created() {
    this.init()
  },
  mounted() {
    // 默认获取焦点
    this.$refs.search.select()
  },

  methods: {
    init() {
      this.loading = true
      getDappList({
        name: this.name,
        page: this.pageInfo.page,
        limits: this.pageInfo.limits
      }).then(d => {
        this.loading = false
        for (const ele of d.data.date) {
          this.listData.push(ele)
        }
      }).catch(err => console.log(err))
    },
    search() {
      this.listData = []
      this.pageInfo.page = 1
      this.init()
    },
    loadMore() {
      this.pageInfo.page++
      this.init()
    }
  }
}
</script>

<style lang="scss" scoped>
  .scoped {
    background-color: #f5f5f5;
    min-height: 100%;
    overflow: hidden;
    >.search-box {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 672px;
      margin: 20px auto 79px;
      >input {
        width: 603px;
        height: 76px;
        box-sizing: border-box;
        padding: 10px 30px 0 80px;
        outline: none;
        border: none;
        background-color: #fff;
        border-radius: 15PX;
      }
      >.r {
        display: block;
        width: 74px;
        height: 54px;
        // background-color: #eaeaea;
        color: #5c5c5c;
        border-radius: 5px;
        text-align: center;
        line-height: 54px;
        margin-left: 20px;
      }
      >img.l {
        position: absolute;
        top: 25px;
        left: 20px;
        height: 31px;
      }
    }

    >ul {
      >li.item {
        position: relative;
        width: 670px;
        height: 769px;
        background-color: #ffdc49;
        border-radius: 15px;
        margin: 0 auto 63px;
        background-repeat: no-repeat;
        background-position: center center;
        background-size: auto 100%;
        overflow: hidden;
        >.name {
          margin: 138px 0 0 25px;
          font-size: 36px;
          line-height: 1;
          letter-spacing: 1px;
          color: #151515;
        }
        >.doc {
          margin: 14px 0 0 25px;
          width: 336px;
          font-size: 24px;
          line-height: 35px;
          letter-spacing: 1px;
          color: #d1d1d1;
        }
        >.score {
          display: flex;
          align-items: center;
          position: absolute;
          top: 149px;
          right: 17px;
          >img {
            width: 29px;
            height: 29px;
            margin-right: 10px;
          }
          >span {
            font-size: 23px;
            color: #202020;
          }
        }
        >.type-box {
          position: absolute;
          top: 197px;
          right: 17px;
          display: flex;
          > span {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: nowrap;
            padding: 13px 26px;
            background-color: #eeeeee;
            border-radius: 15px;
            margin: 0 4px;
          }
        }
      }
    }
  }

  .t-c {
    display: flex;
    justify-content: center;
  }
</style>

