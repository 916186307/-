<template>
  <div>
    <!-- <div class="item">身份识别</div> -->
    <div class="item" @click="$router.push({ name:'SafeCenter' })">安全中心</div>
    <div class="item" @click="$router.push({ name:'OtherSetting' })">其他设置</div>
    <div class="item" @click="$router.push({ name:'Feedback' })">建议反馈</div>
    <div class="item" @click="$router.push({ name: 'AboutMe' })">关于我们</div>
    <!--<div class="item" @click="exit">退出登录</div>-->
    <mt-button @click="exit" class="submit" size="normal" type="primary" >退出登录</mt-button>
  </div>
</template>

<script>
import { logout } from '@/api/user'
export default {
  methods: {
    exit() {
      this.$router.push({
        name: 'Login'
      })
      this.$store.commit('setToken', '')
      logout().then(d => {
        console.log(this.$store.state.token)
        console.log(d)
      })
    }
  }
}
</script>


<style lang="scss" scoped>
  .item {
    box-sizing: border-box;
    line-height: 90px;
    text-indent: 20px;
    width: 710px;
    /*margin: auto;*/
    height: 90px;
    border-radius: 5px;
    background-color: #fff;
    margin: 0 auto 3px;
    font-size: 26px;
  }
  .submit {
    // motion-path: 50px;
    width: 654px;
    display: block;
    margin: 89px auto 58px;
    background-color: rgba(210,220,221,1);
  }
</style>

