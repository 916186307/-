<template>
  <div>
    <div class="scoped">
      <div v-show="listState === 2" class="item" v-for="item in list" :key="item.cardTypeName" @click="$router.push({name: 'AppDetail',query:{id: item.id}})">
        <div class="head" :style="`background-image: url(${item.logo})`"></div>
        <div class="h1">{{item.name}}</div>
        <div class="h2">{{item.one_word | voerfllow}}</div>
      </div>
      <div class="item none"  v-show="listState === 2"></div>
      <div class="item none"  v-show="listState === 2"></div>
    </div>


    <div class="coll-spa" v-show="listState === 3">
      <img class="pic-coll"  src="@/assets/img/icon/no-collection.png" alt="">
      <div class="txt-coll">看到好玩的,别忘了点击收藏哟</div>
    </div>
    <!--<div v-show="listState === 1">-->
      <!--loading...-->
    <!--</div>-->
    <div class="item none"></div>

    <!-- <div class="more-box">
      <div class="more">
        加载更多  
      </div>
    </div> -->
  </div>
</template>

<script>
import { getSc } from '@/api/user';
import { Toast } from 'mint-ui';
export default {
  components: {
  },
  data() {
    return {
      listState: 1, // 1 loading 2 over 3 nullData
      noCollection: false,
      list: []
    }
  },

  created() {
    this.init();
  },
  methods: {
    init() {
      this.listState = 1
      getSc().then(d => {
        this.list = d.data.date
        if (d.data.date.length === 0) {
          this.listState = 3
        } else {
          this.listState = 2
        }
      }).catch(err => Toast(err.msg))
    }
    // Collection() {
    //   if (this.list === '') {
    //     this.noCollection = true;
    //   }
    // }
  }
}
</script>

<style lang="scss" scoped>
  .scoped {
    display: flex;
    justify-content: space-between;
    // justify-content: space-around;
    flex-wrap: wrap;
    width: 710px;
    margin: auto;
    >.item {
      width: 174px;
      height: 228px;
      margin: 0 2px;
      margin-bottom: 45px;
      >.head {
        width: 188px;
        height: 188px;
        border-radius: 5px;
        background-repeat: no-repeat;
        background-size: 100% 100%;
      }
      >.h1{
        font-size: 26px;
        line-height: 44px;
        letter-spacing: 0px;
        color: #282828;
      }
      >.h2{
        font-size: 24px;
        letter-spacing: 0px;
        color: #b0b0b0;
      }
    }
    >.item.none {
      opacity: 0;
    }
    .more-box {
      width: 100%;
      .more {
        line-height: 64px;
        text-align: center;
        width: 226px;
        height: 64px;
        background-color: #fff;
        border-radius: 15px;
        margin: auto;
        font-size: 24px;
        color: #dfdfdf;
      }
    }
  }
  .coll-spa{
    margin-top: 90px;
    text-align: center;
    .pic-coll{
      position: relative;
      width: 300px;
      height: 300px;
    }
    .txt-coll{
      /*position: absolute;*/
      /*left: 180px;*/
      /*bottom: 250px;*/
      /*!*color: black;*!*/
      font-size: 30px;
      color: #999999;
      text-align: center;
      display: block;
      line-height: 100px;
    }
  }

</style>

