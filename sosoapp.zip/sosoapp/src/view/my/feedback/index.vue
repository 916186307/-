<template>
  <div>
    <topBack>意见反馈</topBack>
    <textarea class="text" cols="30" rows="10" v-model="text"></textarea>

    <div class="submit" @click="sendMsg">提交</div>

  </div>
</template>

<script>
import topBack from '@/components/topBack'
import { Toast } from 'mint-ui'

export default {
  components: {
    topBack
  },
  data() {
    return {
      text: ''
    }
  },
  methods: {
    sendMsg() {
      if (!this.text) {
        Toast('请输入您的意见')
      } else {
        Toast('您的意见已反馈')
      }
      this.text = ''
    }
  }
}
</script>


<style lang="scss" scoped>
  .text {
    display: block;
    box-sizing: border-box;
    padding: 20px 30px;
    width: 672px;
    height: 336px;
    background-color: #fff;
    border-radius: 15px;
    /*border: none;*/
    border: solid 1PX #f5f5f5;
    outline: none;
    margin: 8px auto 0;
    -webkit-appearance: none;
  }
  .submit {
    width: 351px;
    height: 77px;
    background-color: #37d4e2;
    border-radius: 15px;
    margin: 88px auto 0;
    text-align: center;
    font-size: 30px;
    line-height: 77px;
    letter-spacing: 0;
    color: #ffffff;

  }
</style>

