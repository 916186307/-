<template>
  <div>
    <topBack>
      交易密码
    </topBack>
    <div class="set-pwd">
      <div class="div-spa">
        <input class="input-kg" label="交易密码" placeholder="请输入交易密码"  v-model="pay_code">
      </div>

      <div class="div-spa">
        <input class="input-kg" label="交易密码" placeholder="请确定交易密码"  v-model="pay_code2">
      </div>

      <div class="div-spa">
        <button @click="submit" class="submit-btn" size="normal" type="primary">提交</button>
      </div>
    </div>
  </div>
</template>

<script>
  import { setPayPwd } from '@/api/user'
  import topBack from '@/components/topBack/index.vue';
  import { Toast } from 'mint-ui';
  export default {
    components: {
      topBack
    },
    data() {
      return {
        codeBtn: false, // 验证码按钮状态
        codeBtnTxt: '发送验证码',
        pay_code: '',
        pay_code2: ''
      }
    },
    mounted() {
      this.pay_code = ''
      this.pay_code2 = ''
    },
    methods: {
      submit() {
        if (this.pay_code !== this.pay_code2) {
          Toast('两次密码输入不一致');
          return false;
        }

        setPayPwd({
          pay_code: this.pay_code
        }).then(() => {
          Toast('交易密码重置成功')
        }).catch(err => {
          Toast(err.msg)
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
    .scoped {
    background-color: #eee;
    height: 100%;
  }
  .set-pwd {
    box-sizing: border-box;
    background-color: #fff;
    
    .b-pwd {
      display: flex;
      justify-content: space-between;
      font-size: 25px;
      color: $them-color;
    }
  }
  .input-kg {
    box-sizing: border-box;
    padding-left: 14px;
    width:671px;
    height:92px;
    outline: none;
    /*border: none;*/
    border:1PX solid rgba(238,238,238,1);
    -webkit-appearance: none;
    border-radius: 15px;
  }
  .input-yz{
    box-sizing: border-box;
    padding-left: 14px;
    width:378px;
    height:92px;
    outline: none;
    /*border: none;*/
    border:1PX solid rgba(238,238,238,1);
    -webkit-appearance: none;
    border-radius: 15px;
  }
  .btn-kg{
    width:279px;
    height:92px;
    background:rgba(238,238,238,1);
    border-radius:15px;
    color:rgba(94,94,94,1);
    font-size: 24px;
  }
  .submit-btn{
    border: none;
    outline: none;
    background-color: transparent;
    font-size:30px;
    font-family:MicrosoftYaHei;
    font-weight:400;
    color:rgba(55,212,226,1);
    margin: 115px auto 53px;
  }
  .div-spa{
    display: flex;
    justify-content: space-between;
    // width: 500px;
    width: 100%;
    width: 671px;
    margin: auto;
    margin-bottom: 21px;
    input::-webkit-input-placeholder {
      color:rgba(214,214,214,1);
      font-size: 24px;
    }
  }
</style>
