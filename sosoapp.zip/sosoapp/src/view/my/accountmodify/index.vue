<template>
    <div class="scoped">
      <topBack>
        账号密码修改
      </topBack>
      <div class="set-pwd">
        <div class="div-spa">
          <input class="input-kg" label="手机号" placeholder="请输入手机号"  v-model="phone">
        </div>
        <div class="div-spa">
          <input class="input-yz" label="验证码" placeholder="请输入验证码" type="text" v-model="code">
          <mt-button @click="sendCode" class="btn-kg"  size="small" :disabled="codeBtn">{{codeBtnTxt}}</mt-button>
        </div>
        <div class="div-spa">
          <input class="input-kg" label="新密码" placeholder="请输入新密码"  type="password" v-model="newPwd">
        </div>
        <div class="div-spa">
          <input class="input-kg" label="确认密码" placeholder="请确认密码"  type="password" v-model="newPwd2">
        </div>
        <div class="div-spa">
          <button @click="submit" class="submit-btn" size="normal" type="primary">确认</button>
        </div>

      </div>
    </div>
</template>

<script>
    import { setPwd, getCode } from '@/api/user'
    import topBack from '@/components/topBack/index.vue';
    import { Toast } from 'mint-ui';
    export default {
      components: {
        topBack
      },
      data() {
        return {
          codeBtn: false, // 验证码按钮状态
          codeBtnTxt: '发送验证码',

          code: '', // 验证码
          newPwd: '', // 新密码
          newPwd2: '', // 新密码
          phone: '' // 手机号
        }
      },
      mounted() {
        this.code = ''
        this.newPwd = ''
        this.newPwd2 = ''
        this.phone = ''
      },
      methods: {
        submit() {
          // 验证手机号格式
          if (!(/^1[34578]\d{9}$/.test(this.phone))) {
            Toast('手机号码有误，请重填');
            return false;
          }

          if (this.newPwd !== this.newPwd2) {
            Toast('两次密码输入不一致');
            return false;
          }

          if (this.code === '') {
            Toast('请输入验证码');
            return false;
          }

          setPwd({
            code: this.code,
            new: this.newPwd,
            phone: this.phone
          }).then(() => {
            Toast('密码重置成功')
          }).catch(err => {
            Toast(err.msg)
          })
        },

        sendCode() {
          // 验证手机号格式
          if (!(/^1[34578]\d{9}$/.test(this.phone))) {
            Toast('手机号码有误，请重填');
            return false;
          }

          // 发动倒计时逻辑
          clearInterval(timer)
          this.codeBtn = true;
          this.codeBtnTxt = 60;
          let timer = setInterval(() => {
            this.codeBtnTxt--
          }, 1000);
          setTimeout(() => {
            clearInterval(timer)
            this.codeBtn = false
            this.codeBtnTxt = '重新发送'
          }, 60000);

          getCode({
            phone: this.phone,
            type: '3'
          }).then(d => {
            if (d.code === 200) {
              Toast('发送成功 请注意查收')
            } else {
              Toast(d.msg)
            }
          }).catch(err => {
            this.codeBtn = false
            this.codeBtnTxt = '重新发送'
            clearInterval(timer)
            Toast(err.msg)
          })
        }
      }
    }
</script>

<style lang="scss" scoped>
  .scoped {
    background-color: #fff;
    height: 100%;
  }
  .set-pwd {
    box-sizing: border-box;
    background-color: #fff;
    
    .b-pwd {
      display: flex;
      justify-content: space-between;
      font-size: 25px;
      color: $them-color;
    }
  }
  .input-kg {
    box-sizing: border-box;
    padding-left: 14px;
    width:671px;
    height:92px;
    outline: none;
    /*border: none;*/
    border:1PX solid rgba(238,238,238,1);
    -webkit-appearance: none;
    border-radius: 15px;
  }
  .input-yz{
    box-sizing: border-box;
    padding-left: 14px;
    width:378px;
    height:92px;
    outline: none;
    /*border: none;*/
    border:1px solid rgba(238,238,238,1);
    -webkit-appearance: none;
    border-radius: 15px;
  }
  .btn-kg{
    width:279px;
    height:92px;
    background:rgba(238,238,238,1);
    border-radius:15px;
    color:rgba(94,94,94,1);
    font-size: 24px;
  }
  .submit-btn{
    border: none;
    outline: none;
    background-color: transparent;
    font-size:30px;
    font-family:MicrosoftYaHei;
    font-weight:400;
    color:rgba(55,212,226,1);
    margin: 115px auto 53px;
  }
  .div-spa{
    display: flex;
    justify-content: space-between;
    // width: 500px;
    width: 100%;
    width: 671px;
    margin: auto;
    margin-bottom: 21px;
    input::-webkit-input-placeholder {
      color:rgba(214,214,214,1);
      font-size: 24px;
    }
  }
  hr{
    color: #161616;
    opacity: .4;
  }
</style>
