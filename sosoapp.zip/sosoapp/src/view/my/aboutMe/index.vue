<template>
<div>
  <topBack>关于我们</topBack>
  <div class="box">
    <div class="row">
      <div class="left">检查更新</div>
      <div class="right">
        <span>1.5.6</span>
        <img src="@/assets/img/icon/arrow-left.png" >
      </div>
    </div>

    <div class="row"@click="$router.push({ name: 'UserAgreement' })">
      <div class="left">用户协议</div>
      <div class="right">
        <img src="@/assets/img/icon/arrow-left.png" >
      </div>
    </div>

    <div class="row" @click="$router.push({name: 'Privacy'})">
      <div class="left">隐私政策</div>
      <div class="right">
        <img src="@/assets/img/icon/arrow-left.png" >
      </div>
    </div>

    <div class="row" @click="$router.push({name: 'joinGroup'})">
      <div class="left">加入社群</div>
      <div class="right">
        <img src="@/assets/img/icon/arrow-left.png" >
      </div>
    </div>

  </div>
</div>
</template>

<script>
import topBack from '@/components/topBack/index.vue';
export default {
  components: {
    topBack
  }
}
</script>

<style lang="scss" scoped>
  .box {
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    height: 456px;
    background-color: #fff;
    border-radius: 5px;
    margin: auto;
  }
  .logo {
    display: block;
    margin: 100px auto 200px;
    width: 600px;
  }
  .row:nth-child(4) {
    border: none;
  }
  .row {
    box-sizing: border-box;
    width: 690px;
    margin: auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1PX solid #eee;
    padding-bottom: 20px;
    >.left {
      font-size: 28px;
      line-height: 29px;
      letter-spacing: 0px;
      color: #333;
      /*margin: 10px 0 10px 10px;*/
    }
    >.right {
      display: flex;
      align-items: center;
      font-size: 28px;
      line-height: 29px;
      letter-spacing: 0px;
      color: #b9b9b9;
      /*margin: 30px;*/
      >img {
        transform: rotate(180deg);
        width: 30px;
        height: 30px;
      }
    }
  }
  footer {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    text-align: center;
    font-size: 25px;
    line-height: 40px;
    color: #999;
  }
</style>


