<template>
    <div>
      <topBack>安全中心</topBack>

      <div class="div-spc">
        <div class="txt-t">账号密码</div>
        <div class="txt-sm" @click="$router.push({name: 'AccountModify'})">修改<img class="moreright" src="@/assets/img/icon/moreright.png"></div>
      </div>
      <div class="div-spc">
        <div class="txt-t">交易密码</div>
        <div class="txt-sm" @click="$router.push({name: 'PasswordModify'})">修改<img class="moreright" src="@/assets/img/icon/moreright.png"></div>
      </div>
      <div class="div-spc">
        <div class="ver-txt">短信验证</div>
        <mt-switch class="txt-sm-b" v-model="value"></mt-switch>
      </div>
      <div class="div-spc">
        <div class="ver-txt">邮箱验证</div>
        <mt-switch class="txt-sm-b" v-model="value1"></mt-switch>
      </div>
      <div class="div-spc">
        <div class="ver-txt">谷歌验证</div>
        <mt-switch class="txt-sm-b" v-model="value2"></mt-switch>
      </div>
      <div class="div-spc">
        <div class="ver-txt">手势密码</div>
        <mt-switch class="txt-sm-b" v-model="value3"></mt-switch>
      </div>
      <div class="div-spc">
        <div class="ver-txt">指纹登陆</div>
        <mt-switch class="txt-sm-b" v-model="value4"></mt-switch>
      </div>
    </div>
</template>

<script>
    import topBack from '@/components/topBack/index.vue';
    export default {
      data() {
        return {
          value: '',
          value1: '',
          value2: '',
          value3: '',
          value4: ''
        }
      },
      components: {
        topBack
      }
    }
</script>

<style scoped>
  .div-spc{
    display: flex;
    justify-content: space-between;
    margin: 0 30px 60px 30px;
    font-size: 24px;
    align-items: center;
  }
  .txt-sm{
    font-size: 28px;
    color: #161616;
    opacity: .5;
    margin-right: 30px;
  }
  .txt-sm-b{
    margin-right: 30px;
    /*height: 50px;*/
  }
  .txt-t{
    font-size: 28px;
    /*padding-bottom: 30px;*/
  }
  .tit-top{
    font-size: 30px;
    margin: 30px;
    font-weight: bold;
  }
  .ver-txt{
    font-size: 28px;
    line-height: 60px;
  }
  .moreright{
    margin-left: 10px;
    width: 15px;
    height: 18px;
    padding-top: 10px;
  }
</style>
