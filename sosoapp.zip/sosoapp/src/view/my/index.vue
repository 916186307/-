<template>
  <div>
    <div class="head">
      <div class="left">
        <img :src="$store.state.userInfo.avatar" @click="$refs.file.click()">
        <imageCipper 
          @ok="ok"
          @cancel="cancel"
          ref="clipper" 
          v-if="cipperShow"
          :img="headUrl"
          :clipper-img-width="500"
          :clipper-img-height="500">
        </imageCipper>

      </div>
      <div class="right">
        <div class="r1" @click="showNameInput = true" v-show="!showNameInput">{{$store.state.userInfo.nickname || '无名'}}</div>
        <div class="r1" v-show="showNameInput">
          <input ref="nameInput" type="text">
          <img @click="setUserName($refs.nameInput)" src="@/assets/img/icon/pince.png" >
        </div>
        <div class="r2">
          <img src="@/assets/img/icon/Shape@2x.png">
          <span>四川成都</span>
        </div>
        <div class="r3">
          <img src="@/assets/img/icon/f@2x.png" >
          <img src="@/assets/img/icon/gezi.png" >
          <img src="@/assets/img/icon/canon.png" >
        </div>
      </div>
    </div>

    <div class="tab-nav">
      <span :class="{act: $store.state.menu.my === 1}" @click="setMenu(1)"  >我的收藏</span>
      <span :class="{act: $store.state.menu.my === 2}" @click="setMenu(2)"  >系统设置</span>
      <!-- <span :class="{act: navIndex === 3}" @click="navIndex = 3" >关于我们</span>
      <span :class="{act: navIndex === 4}" @click="navIndex = 4" >系统设置</span> -->
    </div>

    <div v-if="$store.state.menu.my === 1"><collection></collection></div>
    <div v-if="$store.state.menu.my === 2"><systemSet></systemSet></div>

    <input type="file" style="display: none;" ref="file" @change="uploadImg($refs.file)">
  </div>
</template>

<script>
import imageCipper from '@/components/imageCipper/index.vue'
import { logout, setInfo, getInfo } from '@/api/user'
import { Toast } from 'mint-ui'
import { upfile } from '@/api/public'
import aboutMe from '@/view/my/aboutMe'
import collection from '@/view/my/collection'
import feedback from '@/view/my/feedback'
import addCommunity from '@/view/my/addCommunity'
import systemSet from '@/view/my/system'

export default {
  components: {
    imageCipper,
    systemSet,
    aboutMe,
    feedback,
    collection,
    addCommunity
  },
  data() {
    return {
      headUrl: '',
      cipperShow: false, // 裁剪组建显示
      showNameInput: false,
      navIndex: 1
    }
  },
  methods: {
    loginOut() {
      logout().then(d => {
        Toast(d.msg)
        this.$store.commit('setToken', '')
        this.$store.commit('setUserInfo', {})
        this.$router.push({
          name: 'Login'
        })
      }).catch(err => {
        Toast(err.msg)
      })
    },
    setMenu(num) {
      let menu = this.$store.state.menu
      menu.my = num
      this.$store.commit('setMenu', menu)
    },

    setHead(url) {
      setInfo({ avatar: url }).then(d => {
        Toast('头像更新成功')
        this.headUrl = ''
        getInfo().then(d => this.$store.commit('setUserInfo', d.data))
      }).catch(err => Toast(err.msg))
    },

    uploadImg(dom, key) {
      let file = dom.files[0]
      const windowURL = window.URL || window.webkitURL
      let dataUrl = windowURL.createObjectURL(file)
      this[key] = dataUrl
      let reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onload = e => {
        this.cipperShow = true
        this.headUrl = e.target.result
        dom.value = ''
      }
      // dom.value = ''
    },

    setUserName(dom) {
      let nickname = dom.value
      dom.value = ''
      this.showNameInput = false
      setInfo({ nickname }).then(d => {
        Toast('名称更新成功')
        getInfo().then(d => this.$store.commit('setUserInfo', d.data))
      }).catch(err => Toast(err.msg))
    },

    ok(data) {
      this.cipperShow = false
      upfile({
        type: 1,
        file: data  
      }).then(d => {
        this.setHead(d.data.url)
      }).catch(err => Toast(err.msg))
    },

    cancel() {
      this.cipperShow = false
    }

  }
}
</script>

<style lang="scss" scoped>
  .head {
    display: flex;
    align-items: center;
    box-sizing: border-box;
    padding: 40px 80px;
    width: 710px;
    // background-color: #fff;
    // box-shadow: 0 14px 16px -16px rgba(174,174,174,.3);
    border-radius: 10PX;
    background-color: #fff;
    margin: 20px auto 0;
    >.left {
      >img {
        width: 142px;
        height: 142px;
        border-radius: 142px;
      }
    }
    >.right {
      margin-left: 67px;
      >.r1 {
        display: flex;
        align-items: center;
        font-size: 36px;
        color: #242424;
        font-weight: bold;
        input {
          border: 1PX solid #eaeaea;
          padding: 10px;
          width: 150px;
        }
        img {
          width: 30px;
          margin-left: 30px;
        }
      }
      >.r2 {
        display: flex;
        align-items: center;
        color: #e6e6e6;
        font-size: 26px;
        margin-top: 26px;
        >img {
          width: 16px;
          height: 21px;
          margin-right: 37px;
        }
      }
      >.r3 {
        display: flex;
        justify-content: space-between;
        width: 300px;
        margin-top: 19px;
        >img {
          width: 60px;
          height: 60px;
        }
      }
    }
  }

  .tab-nav {
    box-sizing: border-box;
    padding: 0 16px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    width: 710px;
    height: 94px;
    background-color: #fff;
    border-radius: 5PX;
    margin: 0 auto 38px;
    font-size: 30px;
    >span {
      font-size: 30px;
      letter-spacing: 0px;
      color: #161616;
      padding-bottom: 20px;
      border-bottom: 6px solid transparent;
      opacity: .2;
    }
    >span.act {
      opacity: 1;
      color: #202020;
      border-bottom: 6px solid black;
      padding-bottom: 20px
    }
  }

  .user-select {
    >li {
      box-sizing: border-box;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-radius: 10PX;
      padding: 30px 20px;
      margin: 30px 0;
      font-size: 30px;
      background-color: #fff;
      width: 720px;
      margin: 10px auto;
      box-shadow: 0 14PX 16PX -16PX rgba(174,174,174,.3);
      >img {
        width: 40px;
        height: 40px;
        transform: rotate(-90deg);
      }
      >.left {
        display: flex;
        justify-content: space-between;
        align-items: center;
        >img {
          width: 40px;
          height: 40px;
          margin-left: 20px;
        }
      }
    }
  }
</style>


