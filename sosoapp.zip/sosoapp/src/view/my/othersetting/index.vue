<template>
    <div>
      <topBack>其他设置</topBack>
        <div class="div-spc" v-for="item in languageList">
          <div class="font-le">语言</div>
          <div class="txt-sm" @click="toggle(item)">{{item.language}}<img class="moreright" src="@/assets/img/icon/moreright.png"></div>
        </div>
        <div class="div-spc" v-for="item in moneyTypeList">
          <div class="font-le">计价方式</div>
          <div class="txt-sm" @click="toggle1(item)">{{item.moneyType}}<img class="moreright" src="@/assets/img/icon/moreright.png"></div>
        </div>
        <div class="div-spc" v-for="item in colorList">
          <div class="font-le">涨跌颜色</div>
          <div class="txt-sm" @click="toggle2(item)">{{item.upDownColor}}<img class="moreright" src="@/assets/img/icon/moreright.png"></div>
        </div>


      <mt-actionsheet
        :actions="actions"
        v-model="sheetVisible">
      </mt-actionsheet>
      <mt-actionsheet
        :actions="actions1"
        v-model="sheetVisible1">
      </mt-actionsheet>
      <mt-actionsheet
        :actions="actions2"
        v-model="sheetVisible2"
      name="1">
      </mt-actionsheet>
    </div>
</template>

<script>
    import topBack from '@/components/topBack/index.vue';
    export default {
      components: {
        topBack
      },
      data() {
        return {
          sheetVisible: false,
          sheetVisible1: false,
          sheetVisible2: false,
          actions: [
            { name: '简体中文', method: '' },
            { name: '英语', method: '' }
          ],
          actions1: [
            { name: '人民币', method: '' },
            { name: '美元', method: '' }
          ],
          actions2: [
            { name: '红涨绿跌', method: '' },
            { name: '红跌绿涨', method: '' }
          ],
          languageList: [
            { id: '1', language: '简体中文' }
            // { id: '2', language: 'English' }
          ],
          moneyTypeList: [
            { id: '1', moneyType: '人民币' }
            // { id: '2', moneyType: '美元' }
          ],
          colorList: [
            { id: '1', upDownColor: '红涨绿跌' }
            // { id: '2', upDownColor: '红跌绿涨' }
          ]
        }
      },
      methods: {
        toggle: function() {
          // this.rowData = rowData
          this.sheetVisible = true;
        },
        toggle1: function() {
          // this.rowData = rowData
          this.sheetVisible1 = true;
        },
        toggle2: function() {
          // this.rowData = rowData
          this.sheetVisible2 = true;
        }
      }
    }
</script>

<style scoped>
  .div-spc{
    display: flex;
    justify-content: space-between;
    margin: 0 0 60px 30px;
    font-size: 28px;
  }
  .tit-top{
    font-size: 30px;
    margin: 30px;
    font-weight: bold;
  }
  .txt-sm{
    font-size: 28px;
    color: #161616;
    opacity: .4;
    margin-right: 30px;
  }
  .moreright{
    margin-left: 10px;
    width: 15px;
    height: 18px;
    padding-top: 10px;
  }
  .font-le{
    font-size: 28px;
  }
</style>
