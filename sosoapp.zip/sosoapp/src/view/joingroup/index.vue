<template>
    <div>
      <topBack>加入社群</topBack>
      <!--<div class="tit-l"></div>-->
      <div style="background-color:#fff;">
        <div class="tit-s txt-div-bor tit-wz">
          <div>微信号：123456</div>
          <div class="txt-jt">最新版本：1.2.3</div>
        </div>
        <div class="tit-s txt-div-bor tit-wz">
          <div>公众号：1234578</div>
          <div class="txt-jt">〉</div>
        </div>
        <div class="tit-s txt-div-bor tit-wz">
          <div>QQ群：1234578</div>
          <div class="txt-jt">〉</div>
        </div>
        <div class="tit-s txt-div-bor tit-wz">
          <div>微博：1234578</div>
          <div class="txt-jt">〉</div>
        </div>
        <div class="tit-s txt-div-bor tit-wz">
          <div>微信：1234578</div>
          <div class="txt-jt">〉</div>
        </div>
      </div>
    </div>
</template>

<script>
    import topBack from '@/components/topBack/index.vue';
    export default {
      components: {
        topBack
      }
    }
</script>

<style scoped>
  .tit-wz{
    display: flex;
    justify-content: space-between;
  }
  .tit-l{
    margin: 30px;
    font-size: 35px;
    font-weight: bold;
  }
  .tit-s{
    margin-left: 30px;
    font-size: 25px;
    padding: 20px 0 20px 0;
  }
  .txt-div-bor{
    border-bottom:1px solid #ebeae7;
  }
  .tit-s-right{
    margin: 40px;
    padding: 20px;
    font-size:20px;
    color:#161616;
    opacity: .4;
  }
  .txt-jt{
    margin-bottom: 10px;
    color: #161616;
    opacity: .4;
  }

</style>
