<template>
  <div  class="scoped">
    <topBack>手机注册</topBack>
    <div class="tit-b">国家和地区注册后不可更改</div>

    <div class="input-box">
      <input type="text" placeholder="手机号码" v-model="phone">
      <img src="@/assets/img/icon/clearbtn.png" class="close-btn"  :class="{open:phone }" @click="phone = ''">
    </div>

    <!--<div class="input-box">-->
      <!--<input type="text" placeholder="短信验证码"  v-model="code">-->
      <!--<button class="code-btn" @click="sendCode" :disabled="codeBtn">{{codeBtnTxt}}</button>-->
    <!--</div>-->
    <div class="code-box">
      <input class="code-input" type="text" placeholder="短信验证码"  v-model="code">
      <img src="@/assets/img/icon/clearbtn.png" class="close-btn-code"  :class="{open:code }" @click="code  = ''">
      <button class="code-btn" @click="sendCode" :disabled="codeBtn">{{codeBtnTxt}}</button>
    </div>


    <div class="input-box">
      <!--<input type="text" placeholder="密码"  v-model="password">-->
      <input type="password" placeholder="密码" v-show="eye" v-model="password">
      <div v-show="!eye" class="passClose" v-model="password">{{password}}</div>
      <div class="pass-btn" :class="{open:password }">
        <img v-show="!eye" @click="eye= !eye" class="eye" src="@/assets/img/icon/passbtn.png" alt="">
        <img v-show="eye" @click="eye= !eye" class="eye-close" src="@/assets/img/icon/eye.png" alt="">
      </div>
    </div>

    <div class="input-box">
      <!--<input type="text" placeholder="确认密码"  v-model="password2">-->
      <input type="password" placeholder="密码" v-show="eye1" v-model="password2">
      <div v-show="!eye1" class="passClose" v-model="password2">{{password2}}</div>
      <div class="pass-btn" :class="{open:password2 }">
        <img v-show="!eye1" @click="eye1= !eye1" class="eye" src="@/assets/img/icon/passbtn.png" alt="">
        <img v-show="eye1" @click="eye1= !eye1" class="eye-close" src="@/assets/img/icon/eye.png" alt="">
      </div>
    </div>

    <mt-button @click="submit" class="submit" size="normal" type="primary" >注册</mt-button>

    <!-- <div class="regist-box">
      <mt-field label="手机号" placeholder="请输入用户名" v-model="phone" type="text"></mt-field>
      <mt-field label="验证码" placeholder="请输入验证码" type="text" v-model="code">
        <mt-button @click="sendCode"  size="small" :disabled="codeBtn">{{codeBtnTxt}}</mt-button>
      </mt-field>
      <mt-field label="密码" placeholder="请输入密码" type="password" v-model="password"></mt-field>
      <mt-field label="确认密码" placeholder="请再次输入密码" type="password" v-model="password2"></mt-field>
      <mt-button @click="submit" class="submit" size="normal" type="primary" style="width: 80%;">注册</mt-button>
    </div> -->

    <div class="bottom-txt">
      <span @click="$router.push({name: 'Login'})">已有soso账号？<span class="act">登录</span></span>
    </div>

  </div>
</template>

<script>
import { getCode, regist } from '@/api/user'
import { setInterval, clearInterval, setTimeout } from 'timers';
import { Toast } from 'mint-ui';
import topBack from '@/components/topBack'
export default {
  components: {
    topBack
  },
  data() {
    return {
      codeBtn: false, // 验证码按钮状态
      codeBtnTxt: '发送验证码',

      eye: true,
      eye1: true,
      code: '', // 验证码
      phone: '', // 手机号
      password: '', // 密码
      password2: '' // 密码2
    }
  },

  methods: {
    /**
     * 发送验证码
     */
    sendCode() {
      // 验证手机号格式
      if (!(/^1[34578]\d{9}$/.test(this.phone))) {
        Toast('手机号码有误，请重填');  
        return false; 
      }

      // 发动倒计时逻辑
      clearInterval(timer)
      this.codeBtn = true;
      this.codeBtnTxt = 60;
      let timer = setInterval(() => {
        this.codeBtnTxt--
      }, 1000);
      setInterval(() => {
        clearInterval(timer)
        this.codeBtn = false
        this.codeBtnTxt = '重新发送'
      }, 60000);

      getCode({
        phone: this.phone,
        type: '1'
      }).then(d => {
        if (d.code === 200) {
          Toast('发送成功 请注意查收')
        } else {
          Toast(d.msg)
        }
      }).catch(err => {
        this.codeBtn = false
        this.codeBtnTxt = '重新发送'
        clearInterval(timer)
        Toast(err.msg)
      })
    },

    /**
     * 提交表单
     */
    submit() {
      // 验证手机号格式
      if (!(/^1[34578]\d{9}$/.test(this.phone))) {
        Toast('手机号码有误，请重填');  
        return false; 
      }

      if (this.password !== this.password2) {
        Toast('两次密码输入不一致');  
        return false; 
      }

      if (this.code === '') {
        Toast('请输入验证码');  
        return false; 
      }

      regist({
        phone: this.phone, // 手机号
        code: this.code, // 验证码
        password: this.password // 密码
      }).then(d => {
        if (d.code === 200) {
          Toast('注册成功,3秒后跳转登录');  
          setTimeout(() => {
            this.$router.push({
              name: 'Login'
            })
          }, 3000)
        } else {
          Toast(d.msg);  
        }
      })
    }
  }
};
</script>

<style lang="scss" scoped>
  .scoped {
    background-color: #fff;
  }
  .logo {
    display: block;
    width: 500px;
    margin: 100px auto;
  }
  .regist-box {
    box-sizing: border-box;
    height: 100%;
    margin: auto;
    background-color: #fff;
    .submit {
      motion-path: 50px;
      display: block;
      margin: 50px auto;
      background-color: $them-color;
    }
  }
  .scoped {
    overflow: hidden;
    >.tit {
      margin-left: 51px;
      margin-top: 169px;
      font-size:60px;
      font-family:MicrosoftYaHei;
      font-weight:400;
      color:rgba(22,22,22,1);
      line-height:36px;
    }
    >.tit-b {
      font-size:30px;
      font-family:MicrosoftYaHei;
      font-weight:400;
      color:rgba(210,220,221,1);
      line-height:36px;
      margin-left: 46px;
      margin-bottom: 151px;
    }
    .input-box {
      position: relative;
      display: flex;
      justify-content: center;
      width: 648px;
      margin: 0 auto 91px;
      >.code-btn {
        position: absolute;
        right: 0;
        bottom: 19px;
        color: #4ED8E5;
        background-color: transparent;
        border: none;
        outline: none;
        font-size: 26px;
        font-weight: 400;
        border-radius: 0;
      }
      >input {
        width: 100%;
        border: none;
        outline: none;
        border-bottom: 1PX solid  rgba(215,226,227,1);
        padding-bottom: 22px;
        border-radius: 0;
        font-size: 26px;
      }
      >input::-webkit-input-placeholder {
        font-size: 26px;
        color:rgba(210,220,221,1);
      }
    }
    .submit {
      width: 628px;
      display: block;
      margin: 89px 0 58px 62px;
      background-color: rgba(210,220,221,1);
    }
    .bottom-txt {
      text-align: center;
      margin-bottom: 20px;
      font-size:28px;
      font-weight: 400;
      color:rgba(210,220,221,1);
      .act {
        color:rgba(55,212,226,1);
        margin-left: 40px;
      }
    }
  }

/*验证码*/
  .code-box{
    position: relative;
    display: flex;
    justify-content: left;
    width: 648px;
    margin: 0 auto 91px;
    >.code-btn {
      position: absolute;
      right: 0;
      bottom: 19px;
      color: #4ED8E5;
      background-color: transparent;
      border: none;
      outline: none;
      font-size: 26px;
      font-weight: 400;
    }
    >input {
      width: 100%;
      border: none;
      outline: none;
      border-bottom: 2px solid  rgba(215,226,227,1);
      border-radius: 0;
      padding-bottom: 22px;
      font-size: 26px;
    }
    >input::-webkit-input-placeholder {
      color:rgba(210,220,221,1);
    }
  }
  .code-input{
    width: 440px !important;
  }

  /*清空按钮显隐*/
  .close-btn {
    transition: all .4s ease;
    opacity: 0;
    transform-origin: 50% 50%;
    transform: scale(0);
    width: 35px;
    height: 35px;
  }
  .close-btn.open {
    opacity: 1;
    transform: scale(1);
  }

  /*二维码按钮显隐*/
  .close-btn-code {
    transition: all .4s ease;
    opacity: 0;
    transform-origin: 50% 50%;
    transform: scale(0);
    width: 35px;
    height: 35px;

  }
  .close-btn-code.open{
    opacity: 1;
    transform: scale(1);
  }

  /*密码按钮显隐*/
  .pass-btn {
    transition: all .4s ease;
    opacity: 0;
    transform-origin: 50% 50%;
    transform: scale(0);
    width: 35px;
    height: 35px;
  }
  .pass-btn.open {
    opacity: 1;
    transform: scale(1);
  }

  /*密码按钮*/
  .eye{
    width: 35px;
    height: 28px;
  }
  .eye-close{

    width: 35px;
    height: 35px;
  }
  .passClose{
    width: 648px;
    border: none;
    outline: none;
    border-bottom: 2px solid  rgba(215,226,227,1);
    padding-bottom: 20px;
    height: 35px;
    font-size: 26px;
  }
</style>

