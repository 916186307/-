<template>
  <div class="scoped">
    <topBack>忘记密码</topBack>
    <!--<div class="tit"></div>-->
    <div class="tit-b">请设置8-16位的密码</div>

    <div class="input-box">
      <input type="text" placeholder="手机号码" v-model="phone">
      <img src="@/assets/img/icon/clearbtn.png" class="close-btn"  :class="{open:phone }" @click="phone = ''">
    </div>

    <div class="code-box">
      <div class="code-bh">
        <input class="code-input" type="text" placeholder="短信验证码"  v-model="code">
        <img src="@/assets/img/icon/clearbtn.png" class="close-btn-code"  :class="{open:code }" @click="code  = ''">
      </div>
      <button class="code-btn" @click="sendCode" :disabled="codeBtn">{{codeBtnTxt}}</button>
    </div>

    <div class="input-box">
      <!--<input type="text" placeholder="密码"  v-model="newPwd">-->
      <input :type="`${eye1 ? 'password' : 'text'}`" placeholder="确认密码" v-model="newPwd" >
      <!--<div v-show="!eye1" class="passClose" v-model="newPwd">{{newPwd}}</div>-->
      <div class="pass-btn" :class="{open:newPwd }">
        <img v-show="!eye1" @click="eye1= !eye1" class="eye" src="@/assets/img/icon/eye.png" alt="">
        <img v-show="eye1" @click="eye1= !eye1" class="eye-close" src="@/assets/img/icon/passbtn.png" alt="">
      </div>

    </div>

    <div class="input-box">
      <!--<input type="text" placeholder="确认密码"  v-model="newPwd2">-->
      <input :type="`${eye ? 'password' : 'text'}`" placeholder="确认密码" v-model="newPwd2" >

      <div class="pass-btn" :class="{open:newPwd2 }">
        <img v-show="!eye" @click="eye= !eye" class="eye" src="@/assets/img/icon/eye.png" alt="">
        <img v-show="eye" @click="eye= !eye" class="eye-close" src="@/assets/img/icon/passbtn.png" alt="">
      </div>
    </div>

    <mt-button @click="submit" class="submit" size="normal" type="primary" >重置</mt-button>

    <!-- <img src="@/assets/img/icon/logo.png" class="logo" > -->

    <!-- <div class="set-pwd">
      <mt-field label="手机号" placeholder="请输入手机号"  v-model="phone"></mt-field>
      <mt-field label="验证码" placeholder="请输入验证码" type="text" v-model="code">
        <mt-button @click="sendCode"  size="small" :disabled="codeBtn">{{codeBtnTxt}}</mt-button>
      </mt-field>
      <mt-field label="新密码" placeholder="请输入新密码"  type="password" v-model="newPwd"></mt-field>
      <mt-field label="确认密码" placeholder="请确认密码"  type="password" v-model="newPwd2"></mt-field>
      <mt-button @click="submit" class="submit" size="normal" type="primary" style="width: 80%;">确认重置</mt-button>
    </div> -->
  </div>
</template>

<script>
import { setPwd, getCode } from '@/api/user'
import { Toast } from 'mint-ui';
import topBack from '@/components/topBack/index.vue';
export default {
  components: {
    topBack
  },
  data() {
    return {
      eye: true,
      eye1: true,
      codeBtn: false, // 验证码按钮状态
      codeBtnTxt: '发送验证码',

      code: '', // 验证码
      newPwd: '', // 新密码
      newPwd2: '', // 新密码
      phone: '' // 手机号
    }
  },

  mounted() {
    this.code = '' 
    this.newPwd = '' 
    this.newPwd2 = '' 
    this.phone = '' 
  },

  methods: {
    submit() {
      // 验证手机号格式
      if (!(/^1[34578]\d{9}$/.test(this.phone))) {
        Toast('手机号码有误，请重填');  
        return false; 
      }

      if (this.newPwd !== this.newPwd2) {
        Toast('两次密码输入不一致');
        return false; 
      }

      if (this.code === '') {
        Toast('请输入验证码');  
        return false; 
      }

      setPwd({
        code: this.code,
        new: this.newPwd,
        phone: this.phone
      }).then(() => {
        Toast('密码重置成功，2秒后跳转登录')
        setTimeout(() => {
          this.$router.push({ name: 'Login' })
        }, 2000);
      }).catch(err => {
        Toast(err.msg)
      })
    },

    sendCode() {
      // 验证手机号格式
      if (!(/^1[34578]\d{9}$/.test(this.phone))) {
        Toast('手机号码有误，请重填');  
        return false; 
      }

      // 发动倒计时逻辑
      clearInterval(timer)
      this.codeBtn = true;
      this.codeBtnTxt = 60;
      let timer = setInterval(() => {
        this.codeBtnTxt--
      }, 1000);
      setInterval(() => {
        clearInterval(timer)
        this.codeBtn = false
        this.codeBtnTxt = '重新发送'
      }, 60000);

      getCode({
        phone: this.phone,
        type: '3'
      }).then(d => {
        if (d.code === 200) {
          Toast('发送成功 请注意查收')
        } else {
          Toast(d.msg)
        }
      }).catch(err => {
        this.codeBtn = false
        this.codeBtnTxt = '重新发送'
        clearInterval(timer)
        Toast(err.msg)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.scoped {
  overflow: hidden;
  background-color: #fff;
  min-height: 100%;
  >.tit {
    margin-left: 51px;
    margin-top: 169px;
    font-size:60px;
    font-family:MicrosoftYaHei;
    font-weight:400;
    color:rgba(22,22,22,1);
    line-height:36px;
  }
  >.tit-b {
    font-size:30px;
    font-family:MicrosoftYaHei;
    font-weight:400;
    color:rgba(210,220,221,1);
    line-height:36px;
    margin-left: 30px;
    margin-bottom: 100px;
  }
  .input-box {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 690px;
      margin:50px 0 50px 30px;
      -webkit-appearance: none;
      border-bottom: 2px solid  rgba(215,226,227,1);
      >.code-btn {
        position: absolute;
        right: 0;
        bottom: 19px;
        color: #4ED8E5;
        background-color: transparent;
        border: none;
        outline: none;
        font-size: 26px;
        font-weight: 400;
      }
      >input {
        -webkit-appearance: none;
        width: 700px;
        border: none;
        outline: none;
        border-radius: 0;
        line-height: 60px;
        height: 60px;
        padding-left: 0;
        padding-bottom: 22px;
        font-size: 28px;
        padding-left: 0;
      }
      >input[type=password] {
        line-height: 60px;
      }
      >input::-webkit-input-placeholder {
        color:rgba(210,220,221,1);
      }
  }
  .submit {
    width: 654px;
    display: block;
    margin: 89px auto 58px;
    background-color: rgba(210,220,221,1);
  }
}
.logo {
  display: block;
  width: 500px;
  margin: 100px auto;
}
.set-pwd {
  box-sizing: border-box;
  height: 100%;
  margin: auto;
  background-color: #fff;
  .submit {
    motion-path: 50px;
    display: block;
    margin: 50px auto;
    background-color: $them-color;
  }
  .b-pwd {
    display: flex;
    justify-content: space-between;
    font-size: 25px;
    color: $them-color;
  }
}


/*二维码*/
.code-input{
  width: 440px !important;
}
.code-box{
  position: relative;
  display: flex;
  justify-content: left;
  width: 100%;
  margin:50px 0 50px 30px;

  >.code-btn {
    position: absolute;
    right: 55px;
    bottom: 10px;
    color: #4ED8E5;
    background-color: transparent;
    border: none;
    outline: none;
    font-size: 28px;
    font-weight: 400;
  }
  >.code-bh{
    width: 500px;
    border-bottom: 2px solid  rgba(215,226,227,1);
    padding-bottom: 22px;
    font-size: 28px;
    padding-left: 0;
  }

  >input::-webkit-input-placeholder {
    color:rgba(210,220,221,1);
  }
}

/*清空按钮显隐*/
.close-btn {
  transition: all .4s ease;
  opacity: 0;
  transform-origin: 50% 50%;
  transform: scale(0);
  width: 35px;
  height: 35px;
  margin-top: 10px;
}
.close-btn.open {
   opacity: 1;
   transform: scale(1);
 }

/*二维码按钮显隐*/
.close-btn-code {
  transition: all .4s ease;
  opacity: 0;
  transform-origin: 50% 50%;
  transform: scale(0);
  width: 35px;
  height: 35px;

}
.close-btn-code.open{
  opacity: 1;
  transform: scale(1);

}

/*密码按钮显隐*/
.pass-btn {
  transition: all .4s ease;
  opacity: 0;
  transform-origin: 50% 50%;
  transform: scale(0);
  width: 35px;
  height: 35px;
}
.pass-btn.open {
  opacity: 1;
  transform: scale(1);
}

/*密码按钮*/
.eye{
  box-sizing: border-box;
  width: 35px;
  height: 35px;

}
.eye-close{
  box-sizing: border-box;
  width: 35px;
  height: 30px;

}
.passClose{
  width: 690px;
  border: none;
  outline: none;
  /*border-bottom: 2px solid  rgba(215,226,227,1);*/
  padding-bottom: 20px;
  height: 35px;
  font-size: 26px;
}
  
</style>

