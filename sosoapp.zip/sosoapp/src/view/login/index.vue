<template>
  <div class="scoped">
    <img src="@/assets/img/icon/logo.png" class="logo" >
    <div class="login-txt">登陆SOSO</div>

    <div class="login-box">
      <div class="input-box">
        <input type="text" placeholder="手机号码" v-model="username">
        <img src="@/assets/img/icon/close.png" class="close-btn"  :class="{open:username }" @click="username = ''">
        <!-- <img src=""> -->
      </div>
      <div class="input-box">
        <input :type="`${!eye ? 'password' : 'text'}`" placeholder="密码" v-model="password">
        <div class="pass-btn" :class="{open:password }">
          <img v-show="!eye" @click="eye= !eye" class="eye" src="@/assets/img/icon/eye-close.png">
          <img v-show="eye" @click="eye= !eye" class="eye-close" src="@/assets/img/icon/open_eye.png">
        </div>

      </div>

      <!-- <mt-field label="用户名" placeholder="请输入用户名" v-model="username"></mt-field>
      <mt-field label="密码" placeholder="请输入密码" type="password" v-model="password"></mt-field> -->
      <mt-button @click="submit" class="submit" :class="{act: this.username && this.password}" size="normal" type="primary" >登录</mt-button>
      <div class="b-pwd">
        <span @click="$router.push({name: 'SetPwd'})">忘记密码</span>
      </div>

      <div class="bottom-txt">
        <span @click="$router.push({name: 'Regist'})">还没有soso账号？<span class="act">注册</span></span>
      </div>
    </div>
  </div>
</template>

<script>
import { login, getInfo } from '@/api/user'
import { Toast } from 'mint-ui';

export default {
  data() {
    return {
      eye: true,
      username: '',
      password: '',
      clear: false
    }
  },

  created() {
    this.username = this.$store.state.username || ''
    this.password = this.$store.state.password || ''
  },

  methods: {
    /**
     * 登录
     */
    submit() {
      if (this.username === '' || this.password === '') {
        Toast('账号密码不能为空');
        return;
      }

      login({
        account: this.username,
        password: this.password
      }).then(d => {
        Toast('登录成功');
        this.$store.commit('setToken', d.data.token)
        this.$store.commit('setUsername', this.username)
        this.$store.commit('setPassword', this.password)
        this.getUserInfo();
      }).catch(err => Toast(err.msg))
    },

    /**
     * 获取用户信息
     */
    getUserInfo() {
      getInfo().then(d => {
        this.$store.commit('setUserInfo', d.data)
        setTimeout(() => {
          this.$router.push({ name: 'Home' })
        }, 1000);
      })
    }
    // inputClear() {
    //   if (this.username !== '') {
    //     this.clear = true;
    //     this.username = '';
    //   } else {
    //     this.clear = false;
    //   }
    // }
  }
};
</script>

<style lang="scss" scoped>
  .scoped {
    overflow: hidden;
    background-color: #fff;
    height: 100%;
  }
  .logo {
    display: block;
    width: 368px;
    margin-left: 57px;
    margin-top: 160px;
  }
  .login-txt {
    width:146px;
    height:28px;
    font-size:28px;
    font-family:MicrosoftYaHei-Bold;
    font-weight:bold;
    color:rgba(210,220,221,1);
    line-height:36px;
    margin-left: 54px;
    margin-top: 32px;
    margin-bottom: 143px;
  }
  .login-box {
    box-sizing: border-box;
    height: 100%;
    margin: auto;
    background-color: #fff;
    padding-bottom: 40px;
    .input-box {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      margin-bottom: 91px;
      >input {
        width: 580px;
        border: none;
        outline: none;
        border-bottom: 2px solid  rgba(215,226,227,1);
        padding-bottom: 10px;
        font-size: 28px;
      }
      >input::-webkit-input-placeholder {
        color:rgba(210,220,221,1);
      }
    }
    .submit {
      // motion-path: 50px;
      width: 654px;
      display: block;
      margin: 89px auto 58px;
      background-color: rgba(210,220,221,1);
      transition: all .4s ease;
    }
    .submit.act {
      background-color: $them-color;
    }
    .b-pwd {
      font-size:28px;
      font-weight:400;
      color:rgba(55,212,226,1);
      line-height:36px;
      width: 654px;
      margin: auto;
    }
    .bottom-txt {
      position: absolute;
      bottom: 52px;
      left: 0;
      right: 0;
      text-align: center;
      font-size:28px;
      font-weight: 400;
      color:rgba(210,220,221,1);
      .act {
        color:rgba(55,212,226,1);
        margin-left: 40px;
      }
    }
  }

/*清空按钮显隐*/
  .close-btn {
    transition: all .4s ease;
    opacity: 0;
    transform-origin: 50% 50%;
    transform: scale(0);
    width: 35px;
    height: 35px;
  }
  .close-btn.open {
    opacity: 1;
    transform: scale(1);
  }
/*eye*/

  /*密码按钮显隐*/
  .pass-btn {
    transition: all .4s ease;
    opacity: 0;
    transform-origin: 50% 50%;
    transform: scale(0);
    width: 35px;
    height: 35px;
  }
  .pass-btn.open {
    opacity: 1;
    transform: scale(1);
  }
  /*密码按钮*/
  .eye{
    width: 35px;
    // height: 28px;
  }
  .eye-close{
    width: 35px;
    // height: 35px;
  }
  .passClose{
    width: 648px;
    border: none;
    outline: none;
    border-bottom: 2px solid  rgba(215,226,227,1);
    padding-bottom: 20px;
    font-size: 26px;
  }
</style>

