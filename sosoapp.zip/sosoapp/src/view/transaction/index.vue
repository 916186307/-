<template>
  <div>
    <mt-header title="法币交易">
      <div @click="$router.go(-1)" slot="left">
        <mt-button icon="back"></mt-button>
      </div>
      <mt-button icon="more" slot="right"></mt-button>
    </mt-header>

    <!--<ul class="list-box" v-infinite-scroll="loadMore" :infinite-scroll-immediate-check="false" @infinite-scroll-listen-for-event="loadFn"  infinite-scroll-distance="10">-->
      <!--<li class="item" v-for="item in list">-->
        <!---->
      <!--</li>-->
    <!--</ul>-->

    <!--列表部分-->
    <ul class="bottom-list" v-infinite-scroll="loadMore" :infinite-scroll-immediate-check="false" @infinite-scroll-listen-for-event="loadFn"  infinite-scroll-distance="10">
      <li v-for="item in list" :key="item.cardTypeName" class="item">
        <div class="left">
          <img src="@/assets/img/image/b1.png" >
        </div>
        <div class="right">
          <div class="name">{{item.name}}({{item.n1}}|{{item.n2}}%)</div>
          <!--<div class="dimond">-->
            <!--<img src="@/assets/img/image/b1.png" >-->
          <!--</div>-->
          <div class="l-b">
            <div class="e h">数量：<span class="font-bj">{{item.number}} BTC</span></div>
            <div class="e h">限额：<span class="font-bj">{{item.limit}} CNY</span></div>
            <div class="e h">单价：<span class="pri">{{item.price}} CNY</span></div>
          </div>
          <div class="btn-mar">
            <button class="btn-bank">银行卡</button>
            <button class="btn-alipay">支付宝</button>
            <button class="btn-buy">购买BTC</button>

          </div>

        </div>

      </li>
    </ul>

    <mt-spinner class="t-c" :type="2" v-show="loading"></mt-spinner>

  </div>
</template>
<!--<style lang="scss" scoped>-->
<!--</style>-->


<script>
export default {
  data() {
    return {
      loading: false,
      list: [
        { name: '出售机构1', n1: 4244, n2: 99, number: '50,483', limit: '2,000-402,785', price: '95,036.18' },
        { name: '出售机构2', n1: 6222, n2: 99, number: '22,483', limit: '2,000-402,785', price: '44,036.18' },
        { name: '出售机构3', n1: 1511, n2: 99, number: '11,483', limit: '2,000-402,785', price: '53,5.18' },
        { name: '出售机构4', n1: 2151, n2: 99, number: '33,483', limit: '2,000-402,785', price: '111,036.18' }
      ]
    }
  },
  methods: {
    loadMore() {
      this.loading = true
      setTimeout(() => {
        let last = this.list[this.list.length - 1]
        for (let i = 1; i <= 4; i++) {
          this.list.push(last + i)
        }
        this.loading = false
      }, 3500)
    },

    loadFn(a, b, c, d) {
      console.log(a, b, c, d)
    }
  }
}
</script>

<style lang="scss" scoped>
  .list-box {
    >.item {
      width: 720px;
      height: 200px;
      line-height: 160px;
      background-color: #fff;
      margin: 20px auto;
    }
  }

  .t-c {
    text-align: center;
    line-height: 100px;
  }
/*列表样式*/
  .bottom-list {
    padding: 10px;
    >li {
      box-sizing: border-box;
      display: flex;
      justify-content: space-between;
      margin-top: 0.1px;
      border: 1px solid #eee;
      border-radius: 5PX;
      padding:50px 50px 50px 100px;
      background-color: #fff;
      box-shadow: 0 10px 16px -16px rgba(174,174,174,1);
      >.right {
        width: 100%;
        >.name {
          /*font-weight: bold;*/
          font-size: 20px;
        }
        >.star {
          display: flex;
          align-items: center;
          color: #a1a1a1;
          >img {
            width: 25px;
            height: 25px;
          }
          >span {
            display: inline-block;
            margin-left: 30px;
          }
        }
        >.l-b {
          display: flex;
          justify-content: space-between;
          flex-wrap: wrap;
          margin-top: 10px;
          >.e {
            width: 100%;
          }
          >.h {
            color: #111;
            margin-top: 5px;
            margin-bottom: 5px;
            font-size: 18px;
          }
          >.n {
            color: $them-color;
          }
        }
      }
      >.left {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 120px;
        > img {
          width: 55px;
          height: 55px;
          border-radius: 50%;
        }
      }
    }
  }
  .font-bj {
    margin-left: 30px;
  }
  .pri{
    margin-left: 30px;
    color: RGB(72,153,114);
    font-weight: bold;
  }
  .dimond{
    width: 5px;
    height: 5px;
  }
  .btn-bank{
    color: darkorange;
    font-size: 15px;
    width: 100px;
    height: 40px;
    border:1px whitesmoke solid;
    border-radius: 5px;
    background-color: white;
  }
  .btn-alipay{
    color: dodgerblue;
    font-size: 15px;
    width: 100px;
    height: 40px;
    border:1px whitesmoke solid;
    border-radius: 5px;
    background-color: white;
  }
  .btn-buy{
    margin-left: 20%;
    color: white;
    font-weight: bold;
    font-size: 20px;
    width: 120px;
    height: 50px;
    border:1px whitesmoke solid;
    border-radius: 5px;
    background-color: dodgerblue;
  }
  .btn-mar{
    margin:40px 0 0 10px;
  }
</style>
