<template>
  <div class="scoped">
    <div class="top">

      <div class="header">
        <div class="top">
          <span>我的资产 <span  class="min">EOS</span> </span>
        </div>

        <div class="price">
          <span v-show="eye"><count-to :decimals="4" :startVal='1' :endVal='user_money.eos/1' :duration='1000'></count-to> </span>
          <span v-show="!eye">￥*.** </span>
          <img v-show="eye" @click="eye= !eye" class="eye" src="@/assets/img/icon/eye.png" alt="">
          <img v-show="!eye" @click="eye= !eye" class="eye" src="@/assets/img/icon/eye-close.png" alt="">
        </div>

        <div class="cny">
           <span>≈{{(eos_price * user_money.eos) | toFixed2}}</span>
           <span>CNY</span>
        </div>

        <div class="bottom">
          <div class="e" @click="$router.push({name: 'Tc'})">
            <img src="@/assets/img/icon/price-out.png" >
            <span>转账</span>
          </div>
          <!-- <div class="e" @click="$router.push({name: 'Receipt'})"> -->
          <div class="e" >
            <img src="@/assets/img/icon/price-in.png" >
            <span>收款</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 中间选择部分 -->
    <div class="search-box">
      <div class="select-box" @click="sheetVisible = true; isTop = true">{{ selectVal }}</div>
      <!--<img class="arr-b" :class="{top: isTop}" src="@/assets/img/icon/eglass-arrow-down.png" >-->
      <div class="input-box">
        <input type="text" placeholder="搜索">
        <img src="@/assets/img/icon/add.png" >
      </div>
    </div>
    <!-- /中间选择部分 -->

    <div class="bottom-list">
      <div class="item" v-for="item in listData" :key="item.cardTypeName">
        <div>
          <div class="left">
            <img :src="item.imgSrc" alt="">
            <div class="name">
              <div class="h1">{{item.leftH1}}</div>
              <div class="h2-1">可用</div>
              <div class="h2">{{user_money.eos}}</div>
            </div>
          </div>
          <div class="center">
            <div class="h2-2">冻结 </div>
            <div class="b">{{user_money.freeze_eos}}</div>
          </div>
          <div class="right">
            <div class="h1">USD  $  {{ ((eos_price * user_money.eos) / 6.7035) | toFixed2 }}</div>
            <div class="h2">CNY  ¥  {{(eos_price * user_money.eos) | toFixed2}}</div>
          </div>
        </div>
      </div>
     
    </div>

    <mt-actionsheet
      :closeOnClickModal="false"
      cancelText=""
      :actions="actions"
      v-model="sheetVisible">
    </mt-actionsheet>
  </div>
</template>

<script>
import countTo from 'vue-count-to';
import { getEos } from '@/api/user'
import { getEosPrice } from '@/api/pay'
export default {
  components: {
    countTo
  },
  data() {
    return {
      eos_price: '',
      user_money: {
        eos: '',
        freeze_eos: ''
      },
      isTop: false, // 控制SELECT箭头
      eye: true, // 控制金额是否 显示
      sheetVisible: false,
      selectVal: '全部资产',
      actions: [
        { name: '选择1', method: () => { this.isTop = false; this.selectVal = '选择1' } },
        { name: '选择2', method: () => { this.isTop = false; this.selectVal = '选择2' } },
        { name: '全部资产', method: () => { this.isTop = false; this.selectVal = '全部资产' } }
      ],

      listData: [
        { imgSrc: 'static/bi/eos_icon.png', leftH1: 'EOS', leftH2: '1.20000000', rightH1: '0.707', rightH2: '1.14', frozen: '0.22222222' }
        // { imgSrc: 'static/bi/youzi_icon.png', leftH1: 'ETH', leftH2: '1.20000000', rightH1: '0.707', rightH2: '1.14', frozen: '0.22222222' }
        // { imgSrc: 'static/bi/btc_icon.png', leftH1: 'BTC', leftH2: '1.20000000', rightH1: '0.707', rightH2: '1.14', frozen: '0.22222222' },
        // { imgSrc: 'static/bi/xrp_icon.png', leftH1: 'XRP', leftH2: '1.20000000', rightH1: '0.707', rightH2: '1.14', frozen: '0.22222222' },
        // { imgSrc: 'static/bi/hb_icon.png', leftH1: 'HT', leftH2: '1.00000002', rightH1: '0.707', rightH2: '1.14', frozen: '0.22222222' }
      ]
    }
  },

  created() {
    this.init()
  },

  methods: {
    init() {
      getEos().then(d => {
        this.user_money = d.data
      })

      getEosPrice().then(d => {
        this.eos_price = d.data.coin_price
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  // .top {}
  .scoped {
    // background-color: #eee;
  }
  .tip {
    text-align: center;
    // color: #eaeaea;
  }
  .search-box {
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 710px;
    margin: 20px auto 0;
    padding: 0 30px;
    overflow: hidden;
    background-color: #fff;
    border-radius: 5px;
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
    >.select-box {
      width: 120px;
      font-size: 30px;
      color: #242424;
      margin: 20px 20px 20px 10px;
    }
    >.arr-b {
      transition: all .4s ease;
      width: 30px;
      height: 30px;
    }
    >.arr-b.top {
      transform: rotate(180deg);
    }
    >.input-box {
      margin-left: 40px;
      display: flex;
      align-items: center;
      >img {
        margin-left: 20px;
        width: 40px;
      }
      >input {
        border: 1px solid #f5f5f5;
        -webkit-appearance: none;
        border-radius: 5px;
        font-size: 22px;
        /*border: none;*/
        width: 360px;
        height: 40px;
        padding-left: 10px;
        outline: none;
      }
      >input::-webkit-input-placeholder{
        color: #161616;
        opacity: .2;
      }
    }
  }

  .header {
    box-sizing: border-box;
    width: 710px;
    // height: 288px;
    background-color: #fff;
    border-radius: 5px;
    padding: 40px;
    margin: 20px auto 0;
    overflow: hidden;
    >.cny {
      color: #9F9F9F;
      margin-top: 32px;
      font-size: 28px;
    }
    >.top {
      display: flex;
      align-items: center;
      color: #131313;
      font-size: 32px;
      .min {
        color: #8F8F8F;
        font-size: 24px;
      }
    }
    >.price {
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: #2d2d2d;
      font-size: 48px;
      margin-top: 20px;
      margin-right: 30px;
      font-weight: bold;
      >img {
        width: 35px;
        height: 35px;
      }
    }
    .bottom {
      width: 500px;
      margin: 60px auto 0;
      font-size: 30px;
      color: #2d2d2d;
      display: flex;
      justify-content: space-between;
      >.e {
        width: 50%;
        >img {
          width: 30px;
          margin-right: 20px;
        }
      }
      >.e:nth-child(1) {
        border-right: 2px solid #eaeaea;
      }
      >.e:nth-child(2) {
        text-align: right;
        border-left: 1PX dashed #fff;
        text-align: right;
      }
    }
  }

  .icon-box {
    width: 720px;
    margin: auto;
    margin-top: 30px;
    display: flex;
    justify-content: space-between;
    >.e {
      width: 20%;
      text-align: center;
      color: #a9a9a9;
      background-color: #fff;
      padding: 15px 0;
      border-radius: 10PX;
      box-shadow: 0 14px 16px -16px rgba(174,174,174,.3);
      >img {
        margin-bottom: 10px;
      }
      >img:nth-child(1)  {
        width: 38px;
        height: 42px;
      }
      >img:nth-child(2)  {
        width: 34px;
        height: 35px;
      }
      >img:nth-child(3)  {
        width: 30px;
        height: 34px;
      }
      >img:nth-child(4)  {
        width: 32px;
        height: 32px;
      }
    }
  }

  .bottom-list {
    background-color: #fff;
    overflow: hidden;
    width: 710px;
    margin:  0 auto 20px;
    padding-top: 58px;
    border-radius: 5px;
    border-top-left-radius: 0;
    border-top-right-radius: 0;
    >.item {
      >div {
      display: flex;
      justify-content: space-between;
      width: 650px;
      margin: 0 auto 28px;
      border-bottom: 2px solid #f3f3f3;
      padding-bottom: 30px;
        >.left {
          display: flex;
          align-items: center;
          >img {
            width: 97px;
            height: 97px;
            margin-right: 20px;
          }
          >.name {
            >.h1 {
              font-weight: bold;
              font-size: 30px;
              color: #1f1f1f;
            }
            >.h2 {
              font-size: 26px;
              color:#909090;
              margin-top: 20px;
            }
          }
        }
        .center {
          padding-top: 60px;
          .b {
            margin-top: 20px;
            color: #909090;
            font-size: 26px;
          }
        }
        >.right {
          padding-top: 28PX;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          >.h1 {
            font-weight: bold;
            color: #0a0a0a;
            font-size: 26px;
          }
          >.h2 {
            margin-top: 20px;
            font-size: 28px;
            color: #8e8d8d;
          }
        }
      }
    }
    >.item:nth-last-child(1) {
      border-bottom: none;
    }
  }
  .h2-1{
    padding-top: 10PX;
    font-size: 26px;
    color:#909090;
  }
  .h2-2{

    font-size: 28px;
    color:#909090;
  }
</style>
