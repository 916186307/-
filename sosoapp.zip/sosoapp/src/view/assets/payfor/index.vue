<template>
  <div class="bgc">

    <!--topback-->
    <div class="all">
      <div class="top-back" @click="$router.go(-1)">
        <img class="top-back-logo" src="static/home/topBack.png" alt="">
        <div class="tit">
          <slot></slot>
        </div>
      </div>
    </div>
    
    <div class="tit-wz top-bgc" v-for="item in payList">
      <div>
        <div class="tit-font" v-show="rowData.status === 1 && rowData.identity === 'buyer'">请付款</div>
        <div class="tit-font" v-show="rowData.status === 1 && rowData.identity === 'seller'">等待对方付款</div>
        <div class="tit-font" v-show="rowData.status === 2">已付款</div>
        <div class="tit-font" v-show="rowData.status === 3">已完成</div>
        <div class="tit-font" v-show="rowData.status === 4">已取消</div>
        <div class="tit-font" v-show="rowData.status === 5">申诉中</div>
        <div class="tit-time"  v-show="rowData.status === 1 && rowData.identity === 'buyer'">请在<span class="tit-time-font">{{overTime}}</span>内付款给商家</div>
      </div>

      <!-- <div>
        <img class="img-sl" src="static/home/content.png" alt="">
        <div class="tit-time2">联系对方</div>
      </div> -->
    </div>

    <div class="center-bgc">
      <div  class="tit-wz tit-info" v-for="item in payList">
        <div v-if="rowData.status === 1 && rowData.identity === 'buyer'">
          <div class="tit-font2">请向以下账户付款</div>
          <div class="tit-blue tit-mar" > ¥{{rowData.total_price}}</div>
        </div>
        <div v-if="rowData.status === 2 && rowData.identity === 'buyer'">
          <div class="tit-font2">订单状态</div>
          <div class="tit-blue tit-mar" >待对方确认</div>
        </div>
        <div v-if="rowData.status === 2 && rowData.identity === 'seller'">
          <div class="tit-font2">订单状态</div>
          <div class="tit-blue tit-mar" >对方已标注付款请确认</div>
        </div>
        <div class="tit-mar-t tit-ri">
          <div>交易单价</div>
          <div class="tit-mar">交易数量</div>
        </div>
        <div class="tit-mar tit-dq">
          <div>{{rowData.price}}¥</div>
          <div class="tit-mar">{{rowData.number}} Eos</div>
        </div>
      </div>

      <div class="tit-wz">
        <div class="lo-txt">
          <img class="lo-kg" v-show="payType === 'wx'" src="static/home/we-lo.png" alt="">
          <img class="lo-kg" v-show="payType === 'zfb'" src="static/home/zhi-lo.png" alt="">
          <span>{{ payType === 'wx' ? '微信' : '支付宝'  }} </span>
        </div>
        <div class="tit-wz-ri">
          <div class="lo-txt-qh" @click="onShow">切换方式</div>
          <img class="righticon" src="static/home/righticon.png" alt="">
        </div>

      </div>
      <div class="bor-top"></div>

      <div v-for="item in payList">
        <div class="tit-wz ">
          <!-- <div class="txt-left">收款人</div> -->
          <div class="txt-left"  v-if="rowData.identity === 'buyer'">收款人</div>
          <div class="txt-left"  v-if="rowData.identity === 'seller'">付款人</div>
          <div class="txt-right">{{rowData.nickname}}</div>
        </div>
        <div class="tit-wz txt-di">
          <div class="txt-left">{{payType === 'wx' ? '微信' : '支付宝'}}账号</div>
          <div class="txt-di">
            <span class="txt-right1" @click="copy(item.account)">{{item.account}}</span>
            <img class="code txt-right2" src="static/home/copy.png" @click="copy(item.account)">
          </div>
        </div>
        <div class="tit-wz ">
          <div class="txt-left">收款二维码</div>
          <!-- <img class="code txt-right" :src="rowData.wx" alt="">
          <img class="code txt-right" :src="rowData.ali" alt=""> -->
          <div class="tow-code txt-right">
            <!-- <img class="two-code" src="static/home/pay-code.png" @click="towCodePop = true"> -->
            <img class="two-code" @click="towCodePop = true" v-show="payType === 'zfb'" :src="rowData.ali" >
            <img class="two-code" @click="towCodePop = true" v-show="payType === 'wx'" :src="rowData.wx" >
          </div>
        </div>
      </div>
      <div class="tit-blue-s">如您已向卖家转账付款,请务必点击"标记为支付"按钮,否则有可能造成资金损失</div>
      <div class="tit-wz-jz">
        <button class="btn-cancel" @click="signPay()" v-show="rowData.status === 1 && rowData.identity === 'buyer'">取消订单</button>
        <button class="btn-deal" @click="markPayClick" v-show="rowData.status === 1 && rowData.identity === 'buyer'">标记为已支付</button>
        <button class="btn-deal" @click="releaseEosClick" v-show="rowData.status === 2 && rowData.identity === 'seller'">放行EOS</button>
      </div>
    </div>

    <mt-popup v-model="popupVisible" position="bottom" style="width: 100%;height: 10%">
      <div class="img-zf">
        <div class="zf-li bor" @click="checkPay('zfb')">
          <img class="img-zf-sl" src="static/home/zhi-lo.png" alt="">
          <span class="img-zf-sl1">支付宝</span>
        </div>
        <div class="zf-li" @click="checkPay('wx')">
          <img class="img-zf-sl" src="static/home/we-lo.png" alt="">
          <span class="img-zf-sl1" @click="checkPay">微信</span>
        </div>
      </div>
    </mt-popup>

    <!--切换方式-->
    <mt-popup  v-model="towCodePop" position="bottom" style="width: 90%;height: 90%">
      <img style="width: 100%" v-show="payType === 'zfb'" :src="rowData.ali" >
      <img style="width: 100%" v-show="payType === 'wx'" :src="rowData.wx" >
    </mt-popup>

    <!--购买界面-->
    <!--取消交易弹框-->
    <mt-popup v-model="signPayPupop" popup-transition="popup-fade" class="payPopup">
      <div class="pop-tit">确认取消交易</div>
      <div class="pop-txt-b">如果您已经向卖家付款,请千万不要取消交易</div>
      <div class="pop-txt-h">取消规则：买家当日累积三笔取消订单，<br>
      会限制当日买入功能</div>
      <div>
        <input class="check" type="checkbox" v-model="isCancel"><span class="check-txt">我确认还没付款给对方</span>
      </div>
      <div class="btn-wz">
        <div @click="close()" class="btn-wz close-btn">我再想想</div>
        <div class="pop-txt-h on-btn" @click="cancelBtn" v-show="isCancel">确认</div>
      </div>
    </mt-popup>

  </div>
</template>

<script>
    import topBack from '@/components/topBack/index.vue';
    import { Toast } from 'mint-ui';
    import { markPay, cancelOrder, getOrderDetail, releaseEos } from '@/api/pay'
    let timer = null
    export default {
      components: {
        topBack
      },
      data() {
        return {
          signPayPupop: false,
          isCancel: false,
          payType: 'wx',
          overTime: '',
          rowData: {},
          sun: 0.000,
          sunEos: 0,
          popupVisible: false,
          towCodePop: false,
          payList: [
            { time: '13:34', allMoney: '1000.00', unitMoney: '26298.00', num: '0.038512', account: 'aqq3936' }
          ]
        }
      },
      created() {
        clearInterval(timer)
        this.init()
        // this.rowData = this.$route.query.rowData
        // this.sun = this.$route.query.sun
        // this.sunEos = this.$route.query.sunEos
        // console.log(this.rowData)
      },
      methods: {
        init() {
          getOrderDetail(this.$route.query.id).then(d => {
            this.rowData = d.data
            if (d.data.status === 1 && d.data.identity === 'buyer') {
              this.startTimer(this.rowData.user_expire_time / 1 * 1000)
            }
          })
        },

        onShow: function() {
          this.popupVisible = true;
        },
        signPay: function() {
          this.signPayPupop = true;
        },
        close: function() {
          this.signPayPupop = false;
        },

        checkPay(type) {
          this.popupVisible = false
          this.payType = type
        },

        copy(val) {
          var oInput = document.createElement('input')
          oInput.value = val
          document.body.appendChild(oInput)
          oInput.select()
          document.execCommand('Copy')
          oInput.className = 'oInput'
          oInput.style.display = 'none'
          Toast('复制成功')
        },

        markPayClick() {
          markPay(this.rowData.id).then(d => {
            Toast(d.msg)
            this.init()
          }).catch(err => Toast(err.msg))
        },

        /**
         * 确认取消方法
         */
        cancelBtn() {
          cancelOrder(this.rowData.id).then(d => {
            Toast(d.msg)
            this.close()
            this.init()
          }).catch(err => Toast(err.msg))
        },

        /**
         * 倒计时支付
         */
        startTimer(endTime) {
          // clearInterval(timer)
          let gapTimer = endTime - new Date().getTime()
          timer = setInterval(() => {
            gapTimer -= 1000
            let f = Math.floor(gapTimer / (1000 * 60))
            let m = Math.floor(Math.floor(gapTimer / 1000) % 60)
            this.overTime = f + '分' + m + '秒'
            if (f <= 0 && m <= 0) {
              clearInterval(timer)
            }
          }, 1000);
        },

        /**
         * 放行eos
         */
        releaseEosClick() {
          releaseEos({
            id: this.rowData.id
          }).then(d => {
            Toast(d.msg)
            this.init()
          }).catch(err => Toast(err.msg))
        }
      },
      destroyed() {
        clearInterval(timer)
      }
    }
</script>

<style scoped lang="scss">
  .bgc{
    background-color:  rgb(245,245,245);
    height: 100%;
  }
  .tit-font{
    margin: 30px 0 10px 30px;
    font-size: 35px;
    font-weight: bold;
  }
  .tit-font2{
    font-size: 25px;
    margin-bottom: 10px;
  }
  .tit-blue{
    color: #48d8e3;
    font-size: 40px;
    font-weight: bold;
  }
  .tit-blue-s{
    color: #48d8e3;
    background-color: #fff;
    padding: 10px 30px 10px 30px;
  }
  .tit-mar-t{
    margin-top: 15px;
  }
  .tit-mar{
    margin-top: 15px;
  }
  .tit-time{
    margin: 30px 20px 10px 30px;
    color: #161616;
    opacity: .5;
  }
  .tit-time2{
    margin: 10px 40px 10px  10px;
    color: #161616;
    opacity: .5;
  }
  .tit-time-font{
    color: black;
    opacity: 1;
  }
  .tit-wz{
    display: flex;
    justify-content: space-between;
    background-color: #fff;
  }
  .tit-wz-ri{
    display: flex;
    justify-content: right;
    padding-right: 30px;
  }
  .tit-wz-jz{
    padding: 12PX;
    background-color: #fff;
    display: flex;
    justify-content: center;
    padding: 30px;
    background-color: #fff;
    border-radius: 0 0 10px 10px;
  }
  .tit-info{
    box-sizing: border-box;
    padding: 30px;
  }
  .top-bgc{
    background-color: rgb(245,245,245);
  }
  .center-bgc{
    background-color: #f5f5f5;
    border-radius: 5PX;
    margin: auto;
    width: 710px;
    overflow: hidden;
  }
  .bor-b{
    border-radius: 5px!important;
  }
  .tit-ri{
    margin-left:100px;
    color: #161616;
    opacity: .4;
  }
  .img-sl{
    width: 60px;
    height: 60px;
    margin: 30px 30px 0 30px ;
  }
  .tit-dq{
    text-align: right;
    color: #161616;
    opacity: .4;
  }
  .lo-kg{
    margin: 30px 10px 30px 30px;
    width: 50px;
    height: 50px;
  }
  .lo-txt{
    font-size: 30px;
    display: flex;
    align-items: center;
  }
  .lo-txt-qh{
    font-size: 22px;
    display: flex;
    align-items: center;
    color: #161616;
    opacity: .4;
    padding-right: 20px;
  }
  .img-zf{
    display: flex;
    /*justify-content: center;*/
  }
  .img-zf-sl{
    width: 30px;
    height: 30px;
    margin: 50px 10px 50px 50px;
  }
  .img-zf-sl1{
    width: 100px;
    height: 30px;
    margin: 50px 0 50px 0;
  }
  .zf-li{
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    /*padding-left: 20PX;*/
    /*text-align: center;*/
  }
  .bor{
    border-right: 1px solid #e7e7e7;
  }
  .code{
    width: 30px;
    height: 30px;
  }
  .two-code {
    width: 230px;
    // height: 160px;
    >img {
      width: 100%;
    }
  }
  .txt-left{
    color: #161616;
    opacity: .4;
    margin: 30px 0 30px 30px;
  }
  .txt-right{
    margin: 30px;
  }
  .txt-right1{
    margin: 30px 10px 30px 0;
  }
  .txt-right2{
    margin: 30px;
  }
  .lo-help{
    width: 25px;
    height: 25px;
  }
  .txt-di{
    /*margin: 10px 0 10px 0;*/
    display: flex;
    align-items: center;
  }
  .btn-cancel{
    margin: 5px;
    background-color: #F5F5F5;
    border-radius: 10px;
    width: 250px;
    height: 80px;
    font-size: 30px;
    border:none;
  }
  .btn-deal{
    margin: 5px;
    background-color: deepskyblue;
    color: white;
    font-size: 30px;
    border-radius: 10px;
    width: 400px;
    height: 80px;
    border:none;
  }
  /*1px solid #ced0ce*/
  .payPopup{
    width: 80%;
    height: 26%;
    border-radius: 10px;
    padding: 30px;
  }
  .pop-tit{
    font-size: 35px;
    margin: 20px;
  }
  .pop-txt-b{
    color: rgb(55,212,236);
    margin: 20px;
  }
  .pop-txt-h {
    color: rgb(157,157,157);
    margin: 20px;
  }
  .check{
    margin: 20px 0 20px 20px;
  }
  .check-txt{
    color:rgb(157,157,157);;
    margin: 20px 20px 20px 0;
    vertical-align: 4px;
  }
  .btn-wz{
    display: flex;
    justify-content: flex-end;
    /*margin-top: 50px;*/
  }
  .close-btn{
    margin: 20px;
    font-size: 25px;
  }
  .on-btn{
    font-size: 25px;
  }
  .righticon{
    margin-top: 40px;
    display: inline;
    width: 20px;
    height: 25px;
    padding-top: 5px;
  }
  .bor-top{
    border-top:1PX solid #f5f5f5;
    opacity: .2;
  }
/*topback*/
  .top-back{
    width: 100%;
    /* padding: 20px; */
    background-color: #f5f5f5;
    line-height: 60px;
    /* margin-top: 20px; */
    overflow: hidden;
  }
  .top-back img {
    display: inline-block;
    margin-left: 50px;
    margin-top: 50px;
    line-height: 70px;
  }
  .top-back-logo{
    width: 30px;
  }
  .tit {
    display: block;
    font-weight: bold;
    font-size:36px;
    font-family:MicrosoftYaHei-Bold;
    font-weight:bold;
    color:rgba(31,31,31,1);
    margin-left: 41px;
    margin-top: 10px;
  }
</style>
