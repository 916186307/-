<template>
    <div class="bgc-all">

      <div class="all">
        <div class="top-back" @click="$router.go(-1)">
          <img class="top-back-logo" src="static/home/topBack.png" alt="">
          <div class="tit">
            <slot></slot>
          </div>
        </div>
      </div>

      <div class="bgc-kg" v-for="item in statusList">
        <div class="btw">
          <div>
            <img  class="pic-lo" src="static/home/we-lo.png" alt="">
            <span class="sTit">微信</span>
          </div>
          <!-- <span class="statuTxt">{{item.status}}</span><mt-switch v-model="value"></mt-switch> -->
        </div>
        <img v-show="!wxCodeImg" src="@/assets/img/icon/to-code.jpg" class="to-code">
        <img :src="wxCodeImg" class="to-code">
        <!-- <div class="stxt">张媛</div>
        <div class="btxt">一只乌鸦</div> -->
        <div class="btn" @click="upBtn('wxCodeImg')">点击上传</div>
      </div>

      <div class="bgc-kg">
        <div class="btw" v-for="item in statusList">
          <div>
            <img  class="pic-lo" src="static/home/zhi-lo.png" >
            <span class="sTit">支付宝</span>
          </div>
          <!-- <span class="statuTxt1">{{item.status}}</span><mt-switch v-model="value"></mt-switch> -->
        </div>
        <img v-show="!zfbCodeImg" src="@/assets/img/icon/to-code.jpg" class="to-code">
        <img v-show="zfbCodeImg" :src="zfbCodeImg" class="to-code">
        <!-- <div class="stxt">张媛</div>
        <div class="btxt">1109480071@qq.com</div> -->
        <div class="btn" @click="upBtn('zfbCodeImg')">点击上传</div>
      </div>
      <input type="file" style="display: none;" id="file" accept="image/png, image/jpeg, image/jpg" ref="file" @change="upFile($refs.file, imgKey)">
    </div>
</template>

<script>
  import { upfile } from '@/api/public'
  import { setToCode, getToCode } from '@/api/user'
  export default {
    components: {
    },
    data() {
      return {
        value: '',
        wxCodeImg: '', // 微信二维码图片地址
        zfbCodeImg: '', // 支付宝二维码图片地址
        statusList: [
          { status: '未激活' }
        ]
      }
    },

    created() {
      this.init()
    },

    methods: {
      init() {
        getToCode().then(d => {
          this.wxCodeImg = d.data.wx
          this.zfbCodeImg = d.data.ali
        })
      },
      upBtn(key) {
        this.imgKey = key
        document.getElementById('file').click()
      },
      upFile(dom, key) {
        let file = dom.files[0]
        const windowURL = window.URL || window.webkitURL
        let dataUrl = windowURL.createObjectURL(file)
        this[key] = dataUrl
        let reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = function(e) {
          upfile({
            type: 1,
            file: e.target.result  
          }).then(d => {
            let obj = {}
            
            if (key === 'wxCodeImg') {
              obj.wx = d.data.url
            } else if (key === 'zfbCodeImg') {
              obj.ali = d.data.url
            }
            dom.value = ''
            setToCode(obj).then(d => {
              this.init()
            })
            // console.log(d.data.url)
          })
        }
        // dom.value = ''
      }
    }

  }
</script>

<style scoped lang="scss">
  .bgc-all{
    box-sizing: border-box;
    height: 100%;
    background-color: rgb(245,245,245);
  }
  .tit-font{
    position:relative ;
    font-weight: bold;
    font-size: 35px;
    margin: 30px;
  }
  .sTit{
    font-size: 30px;
    vertical-align: 5px;
  }
  .pic-lo{
    width: 38px;
    height: 38px;
  }
  .btw{
    display: flex;
    justify-content: space-between;
    margin: 30px;
  }
  .stxt{
    margin: 20px;
    font-size: 10px;
  }
  .btxt{
    margin: 20px;
    font-size: 28px;
  }
  .bgc-kg{
    border-radius: 5px;
    background-color: #fff;
    /* height: 500px; */
    margin: 20px;
    padding: 5px;
  }
  .statuTxt{
    position: absolute;
    right: 120px;
    line-height: 2;
  }
  .statuTxt1{
    position: absolute;
    right: 120px;
    line-height: 2;
  }
  .to-code {
    display: block;
    margin: 30px auto;
    width: 300px;   
  }
  .btn {
    display: block;
    width: 300px;
    height: 80px;
    background-color: $them-color;
    margin: auto;
    border-radius: 5PX;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    margin-bottom: 30px;
  }
/*topback*/
  .top-back{
    width: 100%;
    /* padding: 20px; */
    background-color: #f5f5f5;
    line-height: 60px;
    /* margin-top: 20px; */
    overflow: hidden;
  }
  .top-back img {
    display: inline-block;
    margin-left: 50px;
    margin-top: 50px;
    line-height: 70px;
  }
  .top-back-logo{
    width: 30px;
  }
  .tit {
    display: block;
    font-weight: bold;
    font-size:36px;
    font-family:MicrosoftYaHei-Bold;
    font-weight:bold;
    color:rgba(31,31,31,1);
    margin-left: 41px;
    margin-top: 32px;
    margin-bottom: 51px;
  }
</style>
