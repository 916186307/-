<template>
  <div class="allbgc">
    <div class="all">
      <div class="top-back" @click="$router.go(-1)">
        <img class="top-back-logo" src="static/home/topBack.png" alt="">
        <div class="tit">
          <slot>挂单</slot>
        </div>
      </div>
    </div>
    <!--<topBack>挂单</topBack>-->

    <div>
      <div class="tab-nav">
        <span :class="{act: $store.state.menu.suborder === 2}" @click="setMenu(2)"  >出售</span>
        <span :class="{act: $store.state.menu.suborder === 1}" @click="setMenu(1)"  >购买</span>
        <!-- <span :class="{act: navIndex === 3}" @click="navIndex = 3" >关于我们</span>
        <span :class="{act: navIndex === 4}" @click="navIndex = 4" >系统设置</span> -->
      </div>

      <div v-show="$store.state.menu.suborder === 2"  class="div-first">
        <div class="div-s">
          <div class="div-s-s txt-left">行情价格</div><input class="txt-blue" v-model="eosPrice" disabled="disabled">
        </div>
        <div class="div-s">
          <div class="div-s-s txt-left">浮动比例</div>
          <input style="width: 50px;" class="txt-blue" v-model="orderData.rate"   placeholder="">
          <span>%</span>

        </div>
        <!-- <div class="div-s">
          <div class="div-s-s txt-left">出售价格</div><input class="txt-blue" v-model="eosPrice" disabled="disabled" placeholder="=行情价 +（行情价*上浮比例)">
        </div> -->
        <div class="div-s">
          <div class="div-s-s txt-left div-wz">
            <div>限</div>
            <div>额</div>
          </div>
          <div class="txt-blue num-num">
            <input type="text" v-model="orderData.price_down">
            <span>--</span>
            <input type="text" v-model="orderData.price_up">
            <span>CNY</span>
            <!-- {{item.limit1}}--{{item.limit2}}  EOS -->
          </div>
        </div>
        <div class="div-s ">
          <div class="div-s-s txt-left div-wz">
            <div>数</div>
            <div>量</div>
          </div>
          <input class="txt-blue input-number" disabled="disabled" type="number" v-model="orderData.eos_down">
          <span>个</span>
        </div>
        <div class="div-s">
          <div class="div-s-s txt-left">账户余额</div><input class="txt-blue" v-model="userEos" disabled="disabled">
        </div>

        <div class="btn-div">
          <button class="btn-blue" @click="popupVisible = true">确定</button>
        </div>

      </div>

      <div v-show="$store.state.menu.suborder === 1"  class="div-first">
        <div class="div-s">
          <div class="div-s-s txt-left">行情价格</div><input class="txt-blue" v-model="eosPrice" disabled="disabled">
        </div>
        <div class="div-s">
          <div class="div-s-s txt-left">浮动比例</div>
          <input class="txt-blue" style="width: 50px;" v-model="orderData.rate"  placeholder="">
          <span>%</span>
        </div>
        <!-- <div class="div-s">
          <div class="div-s-s txt-left">购入价格</div><input class="txt-blue" v-model="eosPrice" disabled="disabled" placeholder="=行情价 +（行情价*下浮比例)">
        </div> -->
        <div class="div-s">
          <div class="div-s-s txt-left div-wz">
            <div>限</div>
            <div>额</div>
          </div>
          <div class="txt-blue num-num">
            <input type="text" v-model="orderData.price_down">
            <span>--</span>
            <input type="text" v-model="orderData.price_up">
            <span>CNY</span>
          </div>
        </div>
        <div class="div-s ">
          <div class="div-s-s txt-left div-wz">
            <div>数</div>
            <div>量</div>
          </div>
          <input class="txt-blue input-number"  type="number" v-model="orderData.eos_down">
          <span>个</span>
        </div>
        <div class="div-s">
          <div class="div-s-s txt-left">账户余额</div><input class="txt-blue" v-model="userEos" disabled="disabled">
        </div>

        <div class="btn-div">
          <button class="btn-blue" @click="popupVisible = true">确定</button>
        </div>

      </div>
    </div>
    <mt-popup v-model="popupVisible" position="bottom" class="pop" >
      <div class="buy-kg">
        <h1>请输入交易密码</h1>
        <input type="password" ref="pwd" v-model="orderData.pay_pwd">
        <button class="ok" @click="submitOrder">确定</button>
      </div>
    </mt-popup>

  </div>
</template>

<script>
  import { getEosPrice, createOrder } from '@/api/pay'
  import topBack from '@/components/topBack/index.vue';
  import { getEos } from '@/api/user'
  import { Toast } from 'mint-ui'
  export default {
    components: {
      topBack
    },
    data() {
      return {
        orderData: {
          type: 1,
          rate: '',
          eos_up: '',
          eos_down: '',
          price_up: '',
          price_down: '',
          pay_pwd: ''
        },
        eosPrice: 0,
        popupVisible: false,
        numMin: 0,
        numMax: 0,
        userEos: '', // 用户eos 余额
        navIndex: 1,
        orderList: [
          // { market: '24.5629', scale: '', sellPrice: '', limit1: '10', limit2: '1000', balance: '13455.8943 EOS' }
        ]
      }
    },

    watch: {
      orderData: {
        deep: true,
        handler: function(old, newData) {
          this.orderData.eos_down = (this.orderData.price_down / this.eosPrice).toFixed(4)
          this.orderData.eos_up = (this.orderData.price_up / this.eosPrice).toFixed(4)
        }
      }
    },

    created() {
      this.orderData.type = this.$store.state.menu.suborder
      // 获取用户余额
      getEos().then(d => {
        this.userEos = d.data.eos
      })
      // 获取币价格
      getEosPrice().then(d => {
        this.eosPrice = d.data.coin_price || 0
      })
    },

    methods: {
      setMenu(num) {
        let menu = this.$store.state.menu
        menu.suborder = num
        this.orderData = {
          type: num,
          rate: '',
          eos_up: '',
          eos_down: '',
          price_up: '',
          price_down: '',
          pay_pwd: ''
        }
        this.$store.commit('setMenu', menu)
      },

      submitOrder() {
        createOrder(this.orderData).then(d => {
          Toast(d.msg)
          this.popupVisible = false
        }).catch(err => {
          this.popupVisible = false
          Toast(err.msg)
        }).then(() => {
          this.orderData = {
            type: 1,
            rate: '',
            eos_up: '',
            eos_down: '',
            pay_pwd: ''
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .allbgc{
   height: 100%;
    background-color: #f5f5f5;
  }

  .tab-nav {
    box-sizing: border-box;
    padding: 0 16px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    height: 94px;
    background-color: #fff ;
    border-radius: 10PX 10PX  0 0;
    margin: 30px 30px 0 30px;
    font-size: 30px;
    >span {
      width: 150px;
      text-align: center;
      font-size: 32px;
      letter-spacing: 0px;
      color: #161616;
      padding: 20px 0 20px 0;
      border-bottom: 4px solid white;
      opacity: .2;
    }
    >span.act {
      opacity: 1;
      color: #202020;
      border-bottom: 4px solid #37d4e2;
      padding-bottom: 20px
    }
  }
  
  .div-first{
    background-color: #fff;
    border-radius: 0 0 20px 20px;
    margin: 0 30px 0 30px;
    padding: 40px;
    >.div-s{
      margin: 20px 20px 20px 30px;
      display: flex;
      align-items: center;
      >.div-s-s{
        margin-right: 20px;
        width: 150px;
      }
      >.txt-left{
        /*text-align-last:justify;*/
        /*text-justify:distribute-all-lines; //兼容ie浏览器*/
        /*width: 120px;*/
        /*text-align: justify;*/
        width: 120px;
        font-size: 28px;
        color: #161616;
        opacity: .5;
      }
      >.txt-blue{
        width: 425px;
        margin-top: 3PX;
        border: none;
        font-size: 30px;
        color: #37d4e2;
      }
      >.txt-blue.input-number {
        border: 1PX solid #eaeaea;
        border-radius: 2PX;
        width: 100px;
        height: 50px;
        text-align: center;
        margin-right: 20px;
      }
      >.txt-blue.num-num {
        display: flex;
        align-items: center;
        >.span{
          color: #37d4e2;
        }
        >input {
          width: 80px;
          height: 50px;
          outline: none;
          border: none;
          text-align: center;
          border: 1PX solid #eaeaea;
          border-radius: 2PX;
          -webkit-appearance: none;
        }
      }
      >input::-webkit-input-placeholder{
        color: #d2d2d2;
      }
      >.div-wz{
        padding-right: 30px;
        width: 120px;
        display: flex;
        justify-content: space-between;
      }
    }

    >.btn-div{
      padding-top: 50px;
      display: flex;
      justify-content: center;
      >.btn-blue{
        color: white;
        background-color: rgb(55,212,226);
        font-size: 30px;
        width: 300px;
        height: 60px;
        border-radius: 5px;
        border: none;
      }
  }
  }

  .pop {
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    .buy-kg {
      position: relative;
      margin: auto;
      width: 700px;
      height: 250px;
      text-align: center;
      background-color: #fff;
      >.ok {
        position: absolute;
        top: 20px;
        right: 0;
        color: $them-color;
      }
      >h1 {
        font-size: 40px;
        margin-top: 30px;
      }
      >input {
        padding: 0 20px;
        box-sizing: border-box;
        outline: none;
        border: none;
        border: 1PX solid #eee;
        width: 250px;
        height: 60px;
        text-align: center;
      }
    }
  }


  .top-back{
    width: 100%;
    /* padding: 20px; */
    /*background-color: #fff;*/
    line-height: 60px;
    /* margin-top: 20px; */
    overflow: hidden;
  }
  .top-back img {
    display: inline-block;
    margin-left: 30px;
    margin-top: 50px;
    line-height: 70px;
  }
  .top-back-logo{
    width: 50px;
  }
  .tit {
    display: block;
    font-weight: bold;
    font-size:36px;
    font-family:MicrosoftYaHei-Bold;
    font-weight:bold;
    color:rgba(31,31,31,1);
    margin-left: 30px;
    margin-top: 32px;
    margin-bottom: 51px;
  }
  
</style>
