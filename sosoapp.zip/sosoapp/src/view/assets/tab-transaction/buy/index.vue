<template>
  <div class="buy-box">
    <div class="top">
      <div class="tit">{{typ == 1 ? '买' : '卖'}}币</div>
      <div class="eos">
        <div>参考单价</div>
        <div>{{eosNum}}CNY/EOS</div>
      </div>
    </div>
    <div class="input-box">
      <div class="input-swiper">
        <input typ="text" v-model="cnyInput">
        <div class="txt">CNY</div>
      </div>
      <img class="icon" src="@/assets/img/icon/concat.png" >
      <div class="input-swiper">
        <input typ="text" v-model="eosInput">
        <div class="txt">EOS</div>
      </div>
    </div>
    <div class="buy-btn" @click="submit">{{typ == 1 ? '购买' : '出售'}}</div>
  </div>
</template>

<script>
import { addDeal } from '@/api/pay'
import { Toast } from 'mint-ui'
export default {
  name: 'buy',
  props: ['typ'],
  data() {
    return {
      eosNum: 24.7282,
      cnyInput: '',
      eosInput: ''
    }
  },
  created() {
  },
  watch: {
    cnyInput() {
      this.eosInput = this.cnyInput / this.eosNum
    },
    eosInput() {
      this.cnyInput = this.eosNum * this.eosInput
    }
  },
  methods: {
    submit() {
      addDeal({
        type: this.typ,
        eos: this.eosInput,
        eos_price: this.eosNum
      }).then(d => {
        Toast(d.msg)
        this.cnyInput = 0
        this.eosInput = 0
      }).catch(err => {
        Toast('购买失败' + err.msg)
      })
    }
  }
}
</script>


<style lang="scss" scoped>
 .buy-box {
    box-sizing: border-box;
    padding: 10px 20px;
    width: 710px;
    background-color: #fff;
    margin: 0 auto 20px;
    .top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      .tit {
        font-weight: bold;
        font-size: 40px;
        margin-bottom: 20px;
      }
      .eos {
        text-align: center;
        color: #9b9b9b;
        line-height: 40px;
      }
    }

    >.input-box {
      display: flex;
      justify-content: space-between;
      align-items: center;
      >.icon {
        width: 40px;
        height: 40px;
      }
      .input-swiper {
        display: flex;
        align-items: center;
        border: 1PX solid #eaeaea;
        width: 270px;
        height: 60px;
        input {
          border: none;
          outline: none;
          width: 180px;
          margin-left: 20px;
          // padding: 10px 20px;
        }
        >.txt {
          color: #9b9b9b;
          margin-right: 10px;
        }
      }
    }
    >.buy-btn {
      width: 600px;
      background-color: $them-color;
      color: #fff;
      border-radius: 5px;
      margin: 50px auto 20px;
      text-align: center;
      font-size: 30px;
      line-height: 70px;
    }
  }
</style>

