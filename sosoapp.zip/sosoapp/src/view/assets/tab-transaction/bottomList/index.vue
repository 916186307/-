<template>
  <div>
    <div>
      <ul class="bottom-list">
        <li :key="item.cardTypeName"  v-for="item in data">
          <div class="left">
            <img class="pic-le" :src="item.avatar" >
            <span class="name">{{item.nickname}}</span>
            <img class="pic-wz" src="static/home/vip-y.png" alt="">
            <!-- <div class="deal">成交 213    成交率 1.22%</div> -->
            <div class="l-b">
              <div class="zf-btw">
                <span class="cny_font">{{item.n1}}CNY</span>
                <div>
                  <img class="pic-zf" v-show="item.ali" src="static/home/alipay.png" >
                  <img class="pic-zf" v-show="item.ali" src="static/home/wechat.png" >
                </div>
              </div>
              <div style="width: 50%">
                <!-- <div class="xe-col">限额 1000.00-25 , {{item.xianE}} CNY</div> -->
                <div class="xe-col">手机号  {{item.phone}}</div>
                <div class="xe-col">
                  <span>CNY 下限</span>
                  <span>{{item.price_down}}</span>
                  <span>-</span>
                  <span>CNY 上限</span>
                  <span>{{item.price_up}}</span>
                </div>
                <div class="xe-col">
                  {{item.created_at}}
                </div>
              </div>
              <!-- <div class="img-box">
                <div class="img">
                  <img :src="item.wx"  v-show="item.wx" alt="">
                  <div>微信</div>
                </div>
                <div class="img">
                  <img :src="item.ali"  v-show="item.ali" alt="">
                  <div>支付宝</div>
                </div>
              </div> -->
              <div class="right-jt">
                <div class="price">{{(item.rate_price/1).toFixed(2)}}￥</div>
                <button @click="goumai(item)">{{typ === 1 ? '购买' : '出售'}}</button>
              </div>
            </div>
            <hr class="hr-h">
          </div>
        </li>
        <Loading v-show="pageStatus === 1"></Loading>
        <img v-show="pageStatus === 3" src="@/assets/img/icon/pay_null.png" class="pay-null">
      </ul>
    </div>
  </div>
</template>

<script>
// import { placeOrder } from '@/api/pay'
// import { Toast } from 'mint-ui'
export default {
  props: ['typ', 'data'],
  data() {
    return {
      pageStatus: 1 // 页面状态 1 loading 2 列表 3 暂无数据
    }
  },
  watch: {
    data() {
      if (this.data.length === 0) {
        this.pageStatus = 3
      } else {
        this.pageStatus = 2
      }
    }
  },
  mounted() {
    this.init()
  },

  methods: {
    init() {
      // getDealList({
      //   type: this.typ === 1 ? 2 : 1
      // }).then(d => {
      //   console.log(d)
      //   this.data = d.data.date
      // }).catch(() => {
      //   this.data = []
      // })
    },
    goumai(item) {
      item.type = this.typ
      // placeOrder(item.id).then(d => {
      //   Toast('下单成功')
      //   this.$router.push({
      //     name: 'Order'
      //   })
      //   // console.log(d)
      // })
      this.$emit('goumai', item)
    }
  }
}
</script>


<style lang="scss" scoped>

.bottom-list {
  background-color: #fff;
  width: 710px;
  margin: auto;
  overflow: hidden;

  .pay-null {
    width: 200px;
    display: block;
    margin: 50px auto;
  }
  >li {
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
    margin: 10pt 0 10pt 0;
    width: 710px;
    margin: auto;
    // border: 1px solid #eee;
    border-radius: 5PX;
    padding: 20px 0 20px 20px;
    background-color: #fff;
    // box-shadow: 0 10px 16px -16px rgba(174,174,174,1);
  >.left {
    width: 100%;
  >.name {
    /*justify-content: space-between;*/
    /*display: flex;*/
    /*align-items: center;*/
    vertical-align: 20px;
    font-size: 25px;
  }
  >.star {
    display: flex;
    align-items: center;
    color: #a1a1a1;
  >img {
    width: 25px;
    height: 25px;
  }
  >span {
    display: inline-block;
    margin-left: 30px;
  }
  }
  >.l-b {
    margin: 10px;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
  >.e {
    width: 33.333%;
  }
  >.h {
    color: #111;
    margin-bottom: 10px;
  }
  >.n {
    color: rgb(187,187,187);
  }
  }
  }
  >.right {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 120px;
    padding-right: 50px;
  > img {
    width: 50pt;
    height: 50pt;
    border-radius: 50%;
  }
  }
  }
  }
  .pic-le{
    width: 60px;
    height: 60px;
    border-radius: 100px;
    overflow: hidden;
  }
  .pic-zf{
    width: 30px;
    height: 30px;
    border-radius: 100px;
    overflow: hidden;
  }
  .pic-wz{
    margin-left: 20px;
    vertical-align: 18px;
    width: 20px;
  }
  .sel-div{
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
    background-color: #fff;
    /*margin: 15pt;*/
    width: 710px;
    margin: auto;
    padding: 20px;
  }
  .sel{
    border: 0;
    border-radius: 5px;
    margin: 10px;
    margin-left: -9px;
    font-size: 30px;
  }
  .btn-sl{
    margin: 20px 25px 20px 25px;
    width: 30px;
    height: 30px;
  }
  .deal{
    color: rgb(187,187,187);
    /*vertical-align: 30px;*/
    float: right;
    line-height:3;
    display: inline;
    padding-right: 20px;
  }
  .cny_font{
    margin-top: 20px;
    font-size: 30px;
    font-weight: bold;
  }
  .zf-btw{
    width: 100%;
    display: flex;
    justify-content: space-between;
    padding-right: 15px;
  }
  .img-box {
    display: flex;
    justify-content: space-around;
    width: 100%;
    height: 200px;
    padding-bottom: 30px;
    .img {
      width: 200px;
      height: 200px;
      text-align: center;
      >img {
        width: 100%;
        height: 100%;
      }
    }
  }
  .xe-col{
    margin-top:10px;
    color: rgb(155,155,155);
    width: 100%;
  }
  .right-jt{
    margin-right: 10px;
    >button {
      height: 60px;
      width: 180px;
      color: #fff;
      font-size: 28px;
      border: 0;
      border-radius: 10px;
      background-color: rgb(55,212,226);
    }
    >.price {
      text-align: center;
      font-size: 30px;
      color: $them-color;
      font-weight: bold;
      margin-bottom: 20px;
    }
  }
  .btn{
    border: 0;
    background-color: rgb(238,238,238);
    border-radius: 5px;
    text-align: center;
    height: 30px;
    width: 60px;
    margin: 10px;
    margin-left: 0;
  }
  .pos-di{
    position: relative;
  }
  .pos-ul{
    box-shadow: 5px 5px 5px rgba(0,0,0,0.2);
    position: absolute;
    width: 160px;
    text-align: center;
    background-color: #fff;
    right: 50px;
    top: 30px;
    padding: 20px 0 20px 0;
  }
  .pos-ul>div{
    padding: 10px;
  }
  .pic-logo-sl{
    margin: 0 5px 0 5px;
    width: 15px;
    height: 15px;
  }
  .Buy-kg{
    background-color: #fff;
    width: 100%;
    height: 65%;
    border-radius: 30px 30px 0 0;
    z-index: 999;
  }
  .Buy-font-tit{
    margin: 45px 0 10px 45px;
    font-size: 50px;
    font-weight: bold;
  }
  .Buy-font-price{
    margin:10px 0 10px 45px;
    font-size: 30px;
    color: rgb(145,145,145);
  }
  .tit-pos{
    display: flex;
    justify-content: space-between;
  }
  .Buy-pic{
    margin: 50px 30px 0 0;
    width: 90px;
    height: 90px;
  }
  .tab-nav {
    box-sizing: border-box;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    width: 672px;
    height: 94px;
    background-color: #fff;
    border-radius: 5PX;
    margin: 0 auto 38px;
    /*padding: 0 200px 0 200px;*/
    >span {
      border-bottom: 2px white solid;
      font-size: 28px;
      letter-spacing: 0;
      color: #161616;
      opacity: .2;
      padding: 20px;
    }
    >span.act {
      opacity: 1;
      color: #202020;
      border-bottom: 5px black solid;
    }
  }
  .top-head {
    position: relative;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 30px;
    padding: 10px 0 10px 10px;
    overflow: hidden;
    border: 1PX solid gainsboro;
    margin: 30px;
    border-radius: 5px;
    >input {
      opacity: .3;
      color: #161616;
      font-size: 24px;
      box-sizing: border-box;
      padding: 20px 70px 20px 70px;
      line-height: 1;
      width: 410px;
      height: 76px;
      border-radius: 5px;
      border: none;
      outline: none;
      background-color: #fff;
    }
    >.search {
      position: absolute;
      left: 59px;
      top: 30px;
      width: 40px;
      height: 40px;
    }
    >.ling {
      width: 34px;
      height: 44px;
    }
  }
  .wz-pos{
    margin: 15px;
  }
  .wz-pos2{
    margin: 15px ;
    color: deepskyblue;
    opacity: .6;
  }
  .xianE{
    margin-left: 30px;
    color: #161616;
    opacity: .5;
    font-size: 25px;
  }
  .sell-font{
    margin: 30px;
    display: flex;
    justify-content: flex-end;
    color: #161616;
    opacity: .5;
    font-size: 22px;
  }
  .countPrice{
    margin: 30px;
    display: flex;
    justify-content: flex-end;
    font-size: 40px;
    font-weight: bold;
    color: deepskyblue;
    opacity: 0.7;
  }
  .btn-wz{
    display: flex;
    justify-content: center;
  }
  .btn-buy{
    background-color: #161616;
    opacity: 0.3;
    margin: 30px;
    width: 300px;
    height: 80px;
    border: none;
    border-radius: 10px;
    color: white;
  }
  .btn-buy1{
    background-color: #161616;
    opacity: 0.1;
    margin: 30px;
    width: 300px;
    height: 80px;
    border: none;
    border-radius: 10px;
    color: white;
  }
  .hr-h{
    margin: 30px 30px 0 15px;
    color: #f5f5f5;
    opacity: .1;
  }
</style>
