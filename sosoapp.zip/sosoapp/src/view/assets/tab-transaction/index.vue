<template>
    <div @click="onShow = false">
      <!-- select -->
      <div class="sel-div">
        <div>
          <select class="sel" @change="buy= !buy" >
            <option value ="buy">我要买</option>
            <option value ="sell">我要卖</option>
          </select>
          <div class="btn">EOS </div>
        </div>
        <div class="pos-di">

          <img class="btn-sl" src="static/home/screen.png">
          <img class="btn-sl" src="static/home/morebtn.png" @click.stop="toggle()"><br>
          <div class="pos-ul" v-show="onShow">
            <div @click="$router.push({name: 'Order'})"><img class="pic-logo-sl" src="static/home/logo-order.png" alt=""><span>订单记录</span></div>
            <div @click="$router.push({name: 'payWay'})"><img class="pic-logo-sl" src="static/home/logo-pay.png" alt=""><span>收款方式</span></div>
            <div @click="$router.push({name: 'SetPwd'})"><img class="pic-logo-sl" src="static/home/logo-pass.png" alt=""><span>修改密码</span></div>
            <div class="div-wz" v-if="$store.state.userInfo.type === 3" @click="$router.push({name: 'SubmitOrder'})">
              <div class="div-wz-1"><img class="pic-logo-sl1" src="@/assets/img/icon/submitorder.png" alt=""></div>
              <span class="menu-font">挂</span>
              <div class="menu-font-r">单</div>
            </div>
          </div>
        </div>

      </div>

      <!--buyList-->
      <div v-show="buy">
        <!-- <buy :typ="1"></buy> -->
        <bottomList @goumai="goumai" :typ="1" :data="bottomList1"></bottomList>
      </div>
      <!--buyList-->
      <div v-show="!buy">
        <!-- <buy :typ="2"></buy> -->
        <bottomList @goumai="goumai" :typ="2" :data="bottomList2"></bottomList> 
      </div>

    <!--购买界面-->
    <mt-popup v-model="popupVisible" position="bottom" class="Buy-kg">
      <div class="tit-pos">
        <div>
          <div class="Buy-font-tit">{{rowData.type == 1 ? '购买' : '出售'}}Eos</div>
          <div class="Buy-font-price">单价  ¥ {{rowData.rate_price}}</div>
        </div>
        <img class="Buy-pic" src="static/home/bite.png" alt="">
      </div>
      <div class="tab-nav">
        <span :class="{act: tabIndex === 1}" @click="tabIndex = 1" >按价格{{rowData.type == 1 ? '购买' : '出售'}}</span>
        <span :class="{act: tabIndex === 2}" @click="tabIndex = 2" >按数量{{rowData.type == 1 ? '购买' : '出售'}}</span>
      </div>
      
      <div>
        <div class="top-head">
          <input :placeholder="`请输入${rowData.type == 1 ? '购买' : '出售'}法币总额`" type="search" v-model="inputNum">
          <div class="wz-pos" v-show="tabIndex === 1">CNY</div>
          <div class="wz-pos" v-show="tabIndex === 2">个</div>
          
          <div class="wz-pos2" @click="allBtn(rowData.type)">| 全部{{rowData.type == 1 ? '买入' : '出售'}}</div>
        </div>
        <!-- <div>
          <div class="xianE">限额 ¥12- ¥213</div>
        </div> -->

        <div class="countPrice-box">
          <div class="l">
            <span>限额{{rowData.price_down}}￥ - {{rowData.price_up}}￥</span>
          </div>
          <div class="r">
            <div class="countPrice">
              <div> ¥ {{sun}}</div>
            </div>
            <div class="countPrice">
              <div> Eos {{sunEos}}</div>
            </div>
          </div>
        </div>
 

        <div class="xianE">
          <div>交易总额</div>
        </div>
        <div class="btn-wz">
          <button class="btn-buy1">{{okText}}</button>
          <button class="btn-buy" @click="toPlaceOrder">下单</button>
        </div>
      </div>
    </mt-popup>

    </div>
</template>

<script>
import { getCreateOrder, userCreateOrder, getEosPrice } from '@/api/pay'
// import { setTimeout } from 'timers';
import { Toast } from 'mint-ui'
import bottomList from './bottomList'
import buy from './buy'
let timer = null
let timeout = null
export default {
  components: {
    bottomList,
    buy
  },
  data() {
    return {
      buy: true,
      okText: '确认',
      navIndex: 1,
      tabIndex: 1,
      inputNum: '',
      onShow: false,
      popupVisible: false,
      exchangeRate: 23.9702, // 汇率
      rowData: {}, // 点击数据
      listData: [],
      BuyList: [
        // { price: '23450.00', minMoney: '1000.00', maxMoney: '52546.00', sellNum: '51611', countPrice: '0.00' }
      ],
      bottomList1: [
        // { name1: 'Endless Game', n1: '33,483', xianE: '3,838', num: '111,036.18', deal: '2048', probability: '99' }
      ],
      bottomList2: [
      ]
    }
  },
  watch: {
    popupVisible() {
      if (!this.popupVisible) {
        clearInterval(timer)
        clearTimeout(timeout)
      }
    },

    tabIndex() {
      this.inputNum = ''
    }
  },
  created() {
    this.init();
  },
  mounted() {
  },
  computed: {
    sun: function() {
      // this.
      if (this.tabIndex === 1) {
        return (this.inputNum / 1).toFixed(2)
      } else {
        return (this.inputNum * this.exchangeRate).toFixed(2)
      }
    },

    sunEos: function() {
      if (this.tabIndex === 1) {
        return (this.inputNum / this.exchangeRate).toFixed(4)
      } else {
        return (this.inputNum / 1).toFixed(4)
      }
    }
  },
  methods: {
    toPlaceOrder() {
      userCreateOrder({
        type: this.rowData.type,
        eos: this.sunEos,
        id: this.rowData.id
      }).then(d => {
        Toast('下单成功')
        this.$router.push({
          name: 'payFor',
          query: {
            id: d.data.order_id
          }
        })
      }).catch(err => {
        Toast(err.msg)
        this.popupVisible = false
      })
    },
    toggle: function() {
      this.onShow = !this.onShow;
    },
    onBuy: function() {
      this.popupVisible = true;
    },
    goumai: function(rowData) {
      console.log(rowData)
      this.rowData = rowData
      this.popupVisible = true;
      this.timers()
    },
    // 全部出售 买入按钮
    allBtn(type) {
      console.log(this.rowData)
      if (type === 1 && this.tabIndex === 1) {
        this.inputNum = this.rowData.price_up
      } else if (type === 1 && this.tabIndex === 2) {
        this.inputNum = this.rowData.price_up / this.exchangeRate
      }
      console.log(type)
      // alert(type)
    },
    timers() {
      let number = 40
      this.okText = `${number}s后自动取消`
      // 发动倒计时逻辑
      // this.popupVisible = fa;
      timer = setInterval(() => {
        number--
        this.okText = `${number}s后自动取消`
      }, 1000);
      timeout = setTimeout(() => {
        clearInterval(timer)
        this.popupVisible = false
        this.okText = ''
      }, 40000)
    },
    init() {
      getCreateOrder({ type: 1 }).then(d => {
        this.bottomList1 = d.data.date
      }).catch(() => { this.bottomList1 = [] })
      
      getCreateOrder({ type: 2 }).then(d => {
        this.bottomList2 = d.data.date
      }).catch(() => { this.bottomList2 = [] })

      getEosPrice().then(d => {
        this.exchangeRate = d.data.coin_price / 1
      })
    }
  }
}
</script>

<style lang="scss" scoped>
 

.bottom-list {
  >li {
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
    margin: 10pt 0 10pt 0;
    width: 710px;
    margin: auto;
    // border: 1px solid #eee;
    border-radius: 5PX;
    padding: 20px 0 20px 20px;
    background-color: #fff;
    // box-shadow: 0 10px 16px -16px rgba(174,174,174,1);
  >.left {
    width: 100%;
  >.name {
    /*justify-content: space-between;*/
    /*display: flex;*/
    /*align-items: center;*/
    vertical-align: 20px;
    font-size: 25px;
  }
  >.star {
    display: flex;
    align-items: center;
    color: #a1a1a1;
  >img {
    width: 25px;
    height: 25px;
  }
  >span {
    display: inline-block;
    margin-left: 30px;
  }
  }
  >.l-b {
    margin: 10px;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
  >.e {
    width: 33.333%;
  }
  >.h {
    color: #111;
    margin-bottom: 10px;
  }
  >.n {
    color: rgb(187,187,187);
  }
  }
  }
  >.right {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 120px;
    padding-right: 50px;
  > img {
    width: 50pt;
    height: 50pt;
    border-radius: 50%;
  }
  }
  }
  }
  .pic-le{
    width: 60px;
    height: 60px;
    border-radius: 100px;
    overflow: hidden;
  }
  .pic-zf{
    width: 30px;
    height: 30px;
    border-radius: 100px;
    overflow: hidden;
  }
  .pic-wz{
    margin-left: 20px;
    vertical-align: 18px;
    width: 20px;
  }
  .sel-div{
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
    background-color: #fff;
    /*margin: 15pt;*/
    width: 710px;
    margin: auto;
    padding: 20px;
  }
  .sel{
    border: 0;
    border-radius: 5px;
    margin: 10px;
    margin-left: -9px;
    font-size: 30px;
  }
  .btn-sl{
    margin: 20px 25px 20px 25px;
    width: 30px;
    height: 30px;
  }
  .deal{
    color: rgb(187,187,187);
    /*vertical-align: 30px;*/
    float: right;
    line-height:3;
    display: inline;
    padding-right: 20px;
  }
  .cny_font{
    margin-top: 20px;
    font-size: 30px;
    font-weight: bold;
  }
  .zf-btw{
    width: 100%;
    display: flex;
    justify-content: space-between;
    padding-right: 15px;
  }
  .img-box {
    display: flex;
    justify-content: space-around;
    width: 100%;
    height: 200px;
    padding-bottom: 30px;
    .img {
      width: 200px;
      height: 200px;
      text-align: center;
      >img {
        width: 100%;
        height: 100%;
      }
    }
  }
  .xe-col{
    margin-top:10px;
    color: rgb(155,155,155);
    width: 100%;
  }
  .right-jt{
    margin-top: 32px;
    height: 60px;
    width: 180px;
    color: #fff;
    font-size: 28px;
    border: 0;
    border-radius: 10px;
    background-color: rgb(55,212,226);
    margin-right: 10px;
  }
  .btn{
    border: 0;
    background-color: rgb(238,238,238);
    border-radius: 5px;
    text-align: center;
    height: 30px;
    width: 60px;
    margin: 10px;
    margin-left: 0;
  }
  .pos-di{
    position: relative;
  }
  .pos-ul{
    font-size: 25px;
    box-shadow: 5px 5px 5px rgba(0,0,0,0.2);
    border-radius: 10px;
    position: absolute;
    width: 180px;
    text-align: center;
    background-color: #fff;
    right: 50px;
    top: 30px;
    padding: 20px 0 20px 0;
    text-align: left;
  }
  .pos-ul>div{
    padding: 10px;
  }
  .pic-logo-sl{
    margin: 0 5px 0 5px;
    width: 20px;
    height: 22px;
    font-size: 28px;
  }
  .pic-logo-sl1{
    margin:10px 0 0 5px;
    width: 20px;
    height: 20px;
    font-size: 28px
  }
  .Buy-kg{
    background-color: #fff;
    width: 710px;
    /*height: 65%;*/
    border-radius: 30px;
    z-index: 999;
  }
  .Buy-font-tit{
    margin: 45px 0 10px 45px;
    font-size: 50px;
    font-weight: bold;
  }
  .Buy-font-price{
    margin:10px 0 10px 45px;
    font-size: 30px;
    color: rgb(145,145,145);
  }
  .tit-pos{
    display: flex;
    justify-content: space-between;
  }
  .Buy-pic{
    margin: 50px 30px 0 0;
    width: 90px;
    height: 90px;
  }
  .tab-nav {
    box-sizing: border-box;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    width: 672px;
    height: 94px;
    background-color: #fff;
    border-radius: 5PX;
    margin: 0 auto 38px;
    /*padding: 0 200px 0 200px;*/
    >span {
      border-bottom: 2px white solid;
      font-size: 28px;
      letter-spacing: 0;
      color: #161616;
      opacity: .2;
      padding: 20px;
    }
    >span.act {
      opacity: 1;
      color: #202020;
      border-bottom: 5px black solid;
    }
  }
  .top-head {
    position: relative;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 30px;
    padding: 10px 0 10px 10px;
    overflow: hidden;
    border: 1PX solid gainsboro;
    margin: 30px;
    border-radius: 5px;
    >input {
      opacity: .3;
      color: #161616;
      font-size: 24px;
      box-sizing: border-box;
      padding: 20px 70px 20px 70px;
      line-height: 1;
      width: 410px;
      height: 76px;
      border-radius: 5px;
      border: none;
      outline: none;
      background-color: #fff;
    }
    >.search {
      position: absolute;
      left: 59px;
      top: 30px;
      width: 40px;
      height: 40px;
    }
    >.ling {
      width: 34px;
      height: 44px;
    }
  }
  .wz-pos{
    margin: 15px;
  }
  .wz-pos2{
    margin: 15px 0;
    color: deepskyblue;
    opacity: .6;
  }
  .xianE{
    margin-left: 30px;
    color: #161616;
    opacity: .5;
    font-size: 25px;
  }
  .sell-font{
    margin: 30px;
    display: flex;
    justify-content: flex-end;
    color: #161616;
    opacity: .5;
    font-size: 22px;
  }
  .countPrice-box {
    display: flex;
    justify-content: space-between;
    .l {
      color: #B9B9B9;
      font-size: 30px;
      margin-left: 30px;
    }
    .r{
      .countPrice {
        margin: 30px;
        display: flex;
        justify-content: flex-end;
        font-size: 40px;
        font-weight: bold;
        color: deepskyblue;
        opacity: 0.7;
      }
    }
  }
  .btn-wz{
    display: flex;
    justify-content: center;
  }
  .btn-buy{
    background-color: #161616;
    opacity: 0.3;
    margin: 30px;
    width: 300px;
    height: 80px;
    border: none;
    border-radius: 10px;
    color: white;
  }
  .btn-buy1{
    background-color: #161616;
    opacity: 0.1;
    margin: 30px;
    width: 300px;
    height: 80px;
    border: none;
    border-radius: 10px;
    color: white;
  }
  .hr-h{
    margin: 30px 30px 0 15px;
    color: #f5f5f5;
    opacity: .1;
  }

  .Buy-kg {
    background-color: #fff;
    width: 100%;
    height: 65%;
    border-radius: 30px 30px 0 0;
    z-index: 999;
    .tit-pos{
      display: flex;
      justify-content: space-between;
      .Buy-font-tit{
        margin: 45px 0 10px 45px;
        font-size: 50px;
        font-weight: bold;
      }
      .Buy-font-price{
        margin:10px 0 10px 45px;
        font-size: 30px;
        color: rgb(145,145,145);
      }
      .Buy-pic{
        margin: 50px 30px 0 0;
        width: 90px;
        height: 90px;
      }
    }
     .tab-nav {
      box-sizing: border-box;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      width: 672px;
      height: 94px;
      background-color: #fff;
      border-radius: 5PX;
      margin: 0 auto 38px;
      /*padding: 0 200px 0 200px;*/
      >span {
        border-bottom: 2px white solid;
        font-size: 28px;
        letter-spacing: 0;
        color: #161616;
        opacity: .2;
        padding: 20px;
      }
      >span.act {
        opacity: 1;
        color: #202020;
        border-bottom: 5px black solid;
      }
    }
  }
  .menu-font{
    margin-right: 50px;
    font-size: 28px;
  }
  .div-wz{
    display: flex;
    justify-content: space-between;
  }
  .div-wz-1{
    margin: 0;
  }
  .menu-font-r{
    margin-right: 10PX;
    font-size: 28px;
  }
  span{
    font-size: 28px;
  }
</style>
