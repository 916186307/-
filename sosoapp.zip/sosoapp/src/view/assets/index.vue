<template>
  <div>
    <div class="tab-nav">
      <span :class="{act: $store.state.menu.assets === 1}" @click="setMenu(1)" >资产</span>
      <span :class="{act: $store.state.menu.assets === 2}" @click="setMenu(2)" >交易</span>
    </div>
    <div v-if="$store.state.menu.assets === 1">
      <tabAsset></tabAsset>
    </div>
    <div v-if="$store.state.menu.assets === 2">
      <div class="tip"> 交易板块由第三方交易平台支持</div>
      <tabTransaction :opclo="opclo"></tabTransaction>
    </div>
  </div>
</template>

<script>
import tabAsset from '@/view/assets/tab-asset';
import tabTransaction from '@/view/assets/tab-transaction';
// import func from './vue-temp/vue-editor-bridge';
export default {
  components: {
    tabAsset,
    tabTransaction
  },
  data() {
    return {
      opclo: true
    }
  },
  methods: {
    setMenu(num) {
      let menu = this.$store.state.menu
      menu.assets = num
      this.$store.commit('setMenu', menu)
    }
  }
}
</script>


<style lang="scss" scoped>
  .tip {
    display: block;
    text-align: center;
    color: #999;
    margin-bottom: 30px;
  }
  .tab-nav {
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 710px;
    height: 94px;
    background-color: #fff;
    border-radius: 5PX;
    margin: 0 auto 20px;
    padding: 0 200px 0 200px;
    >span {
      border-bottom: 2px white solid;
      font-size: 28px;
      letter-spacing: 0;
      color: #161616;
      opacity: .2;
      padding: 20px;
    }
    >span.act {
      opacity: 1;
      color: #202020;
      border-bottom: 5px black solid;
    }
    
  }
  .txt{
    color: #161616;
    opacity: .4;
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
  }
</style>
