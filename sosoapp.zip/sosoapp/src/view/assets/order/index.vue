<template>
  <div>

    <topBack class="top-back">订单记录</topBack>

    <div class="bgc_div">
      <ul class="bottom-list">
        <li v-for="item in bottomList" :key="item.cardTypeName">
          <div class="left">
            <div @click="$router.push({ name: 'payFor', query: { id: item.id } })">
              <div class="state-wz">
                <div class="name"><span class="name-blue">{{item.type === 1 ? '购买' : '出售'}}</span>EOS</div>
                <div class="redSpot" :class="{green: item.status === 3}"></div>
                  <span v-show="item.status === 1" class="status-font">已下单</span>
                  <span v-show="item.status === 2" class="status-font">已付款</span>
                  <span v-show="item.status === 3" class="status-font">已完成</span>
                  <span v-show="item.status === 4" class="status-font">已取消</span>
                  <span v-show="item.status === 5" class="status-font">申诉状态</span>
                  <img class="righticon" src="static/home/righticon.png" alt="">
              </div>
              <div class="l-b">
                <div class="e h">时间</div>
                <div class="e h cen">数量(EOS)</div>
                <div class="e h f">交易总额(CNY)</div>
                <div class="e n">{{item.created_at}}</div>
                <div class="e n cen">{{item.number}}</div>
                <div class="e n f">{{item.total_price}}CNY</div>
              </div>
            </div>

            <div class="foot">
              <div class="peo_font">交易方:{{item.nickname}}</div>
              <div class="cancel" v-show="item.status === 1 && item.user_type !== 3" @click="cancelOrderClick(item.id)">取消</div>
            </div>
          </div>
        </li>
        <Loading v-show="pageStatus === 1"></Loading>
        <img src="@/assets/img/icon/order_null.png" class="order-null" v-show="pageStatus === 3">
      </ul>
    </div>

    
  </div>
</template>

<script>
import topBack from '@/components/topBack/index.vue';
import { getOrderList, cancelOrder } from '@/api/pay'
import { Toast } from 'mint-ui'
export default {
  components: {
    topBack
  },
  data() {
    return {
      bottomList: [],
      pageStatus: 1 // 1 loading 2 有数据 3 无数据
    }
  },

  created() {
    this.init()
  },

  methods: {
    init() {
      this.pageStatus = 1
      getOrderList().then(d => {
        this.bottomList = d.data.date
        if (d.data.date.length === 0) {
          this.pageStatus = 3
        } else {
          this.pageStatus = 2
        }
      })
    },

    cancelOrderClick(id) {
      cancelOrder(id).then(d => {
        Toast(d.msg)
        this.init()
      }).catch(err => Toast(err.msg))
    }
  }
}
</script>

<style lang="scss" scoped>
  .body {
    height: 500px;
    width: 700px;
  }
  .top-back {
    margin-bottom: -50px !important;
  }
  .bgc_div{
    background-color: rgb(245,245,245);
  }
  .bottom-list {
  /*padding: 10px;*/
    background-color: #fff;
    overflow: hidden;
    >.order-null {
      display: block;
      width: 300px;
      margin: 50px auto;
    }
    >li {
      box-sizing: border-box;
      display: flex;
      justify-content: space-between;
      margin-top: 7pt;
      /*border: 1px solid #eee;*/
      border-radius: 5px;
      padding: 30px;
      background-color: #fff;
      /*<!--box-shadow: 0 10px 16px -16px rgba(174,174,174,1);-->*/
      >.left {
        width: 100%;
        // margin-left: 10px;
        .foot {
          display: flex;
          justify-content: space-between;
          align-items: center;
          >.cancel {
            background-color: $them-color;
            padding: 5px 10px;
            border-radius: 5px;
            color: #fff;
          }
        }
      >.name {
        margin: 10px;
        /*font-weight: bold;*/
        font-size: 25px;
      }
      >.star {
        display: flex;
        align-items: center;
        color: #a1a1a1;
        >img {
          width: 25px;
          height: 25px;
        }
        >span {
          display: inline-block;
          margin-left: 30px;
        }
      }
      .l-b {
        width: 100%;
        margin: 10px 0 10px 0;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        >.e {
          width: 33.333%;
        }
        >.e:nth-child(3),
        >.e:nth-child(6) {
          text-align: right
        }
        >.h {
          margin-bottom: 10px;
          color: rgb(209,209,209);
        }
        >.f{
          text-align: right;
          >.n {
            color:rgb(130,130,130);
          }
        }
      }
      }
    >.right {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 120px;
      padding-right: 50px;
    > img {
      width: 50pt;
      height: 50pt;
      border-radius: 50%;
    }
    }
    }
  }
  .tit{
    padding-top: 30px;
    margin: 30px;
    font-size: 30px;
    font-weight: bold;
  }
  .name-blue {
    color: deepskyblue;
  }
  .state-wz{
    display: flex;
    justify-content: space-between;
  }
  .l-b>div{
    padding-top: 5px;
  }
  .redSpot{
    background-color: red;
    width: 12px;
    height: 12px;
    border-radius:50px;
    margin: 12px 0 0 470px;
  }
  .redSpot.green {
    background-color: green;
  }
  .status-font{
    color: rgb(209,209,209);
    /*margin-right: 30px;*/
  }
  .cen{
    text-align: center;
  }
  .righticon{
    width: 15px;
    height: 20px;
    padding-top: 7px;
  }
  .peo_font{
    margin-top: 10px;
    font-size: 28px;
  }

</style>
