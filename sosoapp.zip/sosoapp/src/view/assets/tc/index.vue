<template>
  <div class="scoped">
    <topBack></topBack>
    <div class="h1">转账</div>
    <div class="body">
      <div class="top">
        <span class="key">当前可用EOS额度:</span> 
        <span class="val">{{userEos || '0.000'}}EOS</span>
      </div>
      <div class="top">
        <span class="key">当前冻结EOS额度:</span> 
        <span class="val">{{freezeEos || '0.000'}}EOS</span>
      </div>

      <div class="user-box">
        <span>对方账户:</span>
        <input type="text" class="input" v-model="nickname" placeholder="请输入用户名称">
      </div>
      <div class="tip">数字货币将实时转入对方账户，请仔细确认</div>
      <div class="eos-box">
        <span>EOS:</span>
        <input type="number" v-model="eos" placeholder="请输入EOS个数" />
        <span class="show-hand" @click="eos = userEos">全部</span>
      </div>
      <div @click="submit" class="btn">
        确认转账
      </div>
    </div>

  </div>
</template>

<script>
import topBack from '@/components/topBack'
import { Toast } from 'mint-ui'
import { transfer, getEos } from '@/api/user'
export default {
  data() {
    return {
      freezeEos: '',
      nickname: '',
      userEos: '',
      eos: ''
    }
  },

  components: {
    topBack
  },

  created() {
    getEos().then(d => {
      this.userEos = d.data.eos
      this.freezeEos = d.data.freeze_eos
    })
  },

  methods: {
    submit() {
      transfer({
        nickname: this.nickname,
        eos: this.eos
      }).then(d => {
        Toast({
          message: '转账成功',
          iconClass: 'mintui mintui-success'
        })
        this.nickname = ''
        this.eos = ''
      }).catch(err => {
        Toast({
          message: '转账失败' + err.msg,
          iconClass: 'mintui mintui-error'
        })
      })
    }
  }
}
</script>

<style lang="scss" scoped>
  .scoped {
    background:rgba(245,245,245,1);
    height: 100%;
    overflow: hidden;
    .h1 {
      font-size:44px;
      font-weight:bold;
      color:rgba(31,31,31,1);
      margin-left: 19px;
      margin-bottom: 54px;
    }
    .body {
      background-color: #fff;
      width: 712px;
      margin: auto;
      padding: 24px 0 34px;
      .tip {
        font-size:20px;
        font-family:MicrosoftYaHei;
        font-weight:400;
        color:rgba(255,114,111,1);
        margin-left: 205px;
        margin-top: 10px;
      }
      .top {
        text-align: center;
        >.key {
          font-size:32px;
          font-family:MicrosoftYaHei;
          font-weight:400;
          color:rgba(171,171,171,1);
        }
        >.val {
          margin-left: 16px;
          font-size:32px;
          font-family:MicrosoftYaHei;
          font-weight:400;
          color:rgba(16,16,16,1);
        }
        >.ee {
          font-weight: bold;
          font-size: 50px;
        }
      }
    }
  }
 
  .btn {
    width: 651px;
    height: 69px;
    text-align: center;
    font-size:30px;
    line-height: 69px;
    background-color: $them-color;
    color: #fff;
    border-radius: 3PX;
    margin: 100px auto 0;
  }
  .user-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 600px;
    margin: auto;
    margin-top: 63px;
    input {
      width:418px;
      height:63px;
      border-radius:5px;

      outline: none;
      border: none;
      background-color: #fff;
      padding: 0 30px;
      -webkit-appearance: none;
      border:1PX solid rgba(220,220,220,1);
    }
    ::-webkit-input-placeholder {
      color:rgba(229,229,229,1);
    }
    span {
      width: 140px;
      margin-right: 20px;
      font-size:30px;
      font-family:MicrosoftYaHei;
      font-weight:400;
      color:rgba(33,33,33,1);
      text-align: right;
    }
  }
  .eos-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 600px;
    margin: auto;
    margin-top: 30px;
    .show-hand {
      color:rgba(55,212,226,1);
    }
    span {
      width: 140px;
      margin-right: 20px;
      text-align: right;
      font-size:30px;
      font-family:MicrosoftYaHei;
      font-weight:400;
      color:rgba(33,33,33,1);
    }
    input {
      width:248px;
      height:63px;
      border-radius:5px;

      outline: none;
      border: none;
      background-color: #fff;
      padding: 0 30px;
      -webkit-appearance: none;
      border:1PX solid rgba(220,220,220,1);
    }
    ::-webkit-input-placeholder {
      color:rgba(229,229,229,1);
    }
  }
</style>
