<template>
  <div class="swiper">

    <topBack></topBack>

    <div class="h1">个人转账</div>

    <div class="body">
      <div>扫一扫向我付钱</div>
      <img class="two-code" src="@/assets/img/icon/to-code.jpg" >
      <div class="input-box">
        <span>收款金额</span>
        <input type="text" placeholder="请设置收款金额">
        <span>EOS</span>
      </div>

      <footer>
        <div class="h1">{{$store.state.userInfo.phone}}</div>
        <div class="h2" @click="copy">复制收款账号</div>
      </footer>
    </div>

  </div>
</template>

<script>
import top from '@/components/header/index.vue';
import topBack from '@/components/topBack/index.vue';
import { Toast } from 'mint-ui';
export default {
  components: {
    top,
    topBack
  },
  data() {
    return {
      code: 'theeosportal'
    }
  },
  methods: {
    copy() {
      var val = this.code;
      var oInput = document.createElement('input')
      oInput.value = val
      document.body.appendChild(oInput)
      oInput.select()
      document.execCommand('Copy')
      oInput.className = 'oInput'
      oInput.style.display = 'none'
      Toast('复制成功')
    }
  }
}
</script>

<style lang="scss" scoped>
  .hr {
    height: 40px;
  }
  .swiper {
    background:rgba(245,245,245,1);
    min-height: 100%;
    >.h1 {
      font-size:44px;
      font-weight:bold;
      color:rgba(31,31,31,1);
      margin-left: 19px;
      margin-bottom: 54px;
    }
  }
  .two-code {
    display: block;
    width: 500px;
    margin: 150px auto;
  }
  .input-box {
    padding-bottom: 40px;
    width: 700px;
    margin: 40px auto 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 35px;
    input {
      outline: none;
      border: none;
    }
  }
  
  footer {
    margin-top: 50px;
    text-align: center;
    .h1 {
      font-size: 28px;
      color: #323232;
    }
    .h2 {
      margin-top: 20px;
      font-size: 35px;
      color: #3c91c8;
    }
  }
</style>


