<template>
  <div class="detail-box">
    <img src="static/home/topBack.png" class="arr" @click="$router.go(-1)">
    <!-- <topBack></topBack> -->
    <div class="tit">游戏介绍</div>
    <!-- 图片查看部分 -->
    
    <div class="video-box">
      <div class="play">
        <img :src="bannerLlist[itemIndex]" >
      </div>
      <div class="select-box">
        <div class="swiper-box">
          <div v-for="( item, index ) in bannerLlist" :key="item.cardTypeName" :class="{act: itemIndex === index}" class="item" @click="itemIndex = index"> <img v-lazy.container="item"> </div>
        </div>
      </div>
    </div>
    <!-- /图片查看部分 -->
    <!-- 文字介绍 -->
    <textDoc :types="pageData.tags" :id="pageData.id" :isSc="pageData.isFavorite" @collect="collect">
      <div slot="title" v-text="pageData.name"></div>
      <div slot="fen">8.2</div>
      <div slot="doc" v-text="pageData.one_word"></div>
    </textDoc>

    <!-- /文字介绍 -->

    <!-- 评分 -->
    <!-- <div class="score">
      <div class="num">
        <span class="max">{{ pageData.scores.toFixed(1).split('.')[0] }}</span><span>.{{pageData.scores.toFixed(1).split('.')[1]}}</span>
      </div>
      <img v-for="item in parseInt(pageData.scores.toFixed(1).split('.')[0])" :key="item.number" src="@/assets/img/icon/start-act.png" >
    </div> -->
    <!-- /评分 -->

    <!-- tab切换页 -->
    <div class="foot">
      <mt-navbar class="tab-box" v-model="selected">
        <mt-tab-item id="1"><span class="tab-font">详情</span></mt-tab-item>
        <mt-tab-item id="2"><span class="tab-font">评价</span></mt-tab-item>
      </mt-navbar>

      <mt-tab-container v-model="selected">
        <mt-tab-container-item id="1">
          <detail :data="detailData"></detail>
        </mt-tab-container-item>
        <mt-tab-container-item id="2">
          <comment></comment>
        </mt-tab-container-item>
      </mt-tab-container>
    </div>
    <!-- /tab切换页 -->

    <footer>
      <div class="left" v-show="pageData.isFavorite" @click="collect(true)">
        <img src="@/assets/img/icon/star-green.png" alt="">
        <span>取消收藏</span>
      </div>
      <div class="left" v-show="!pageData.isFavorite" @click="collect(false)">
        <img src="@/assets/img/icon/star-green.png" alt="">
        <span>收藏</span>
      </div>
      <div class="right">
        <!-- pageData.app_url -->
        <!-- 打开官网 -->
        <a :href="pageData.app_url">打开官网</a>
      </div>
    </footer>

  </div>
</template>

<script>
import topBack from '@/components/topBack';
import { getAppDetail } from '@/api/home';
import detail from './details'
import comment from './comment'
import textDoc from './textDoc'
import { scDapp, delDapp } from '@/api/dapp'
import { Toast } from 'mint-ui';

export default {
  components: {
    detail, textDoc, comment, topBack
  },

  mounted() {
    this.id = this.$route.query.id;
    this.init()
  },

  data() {
    return {
      pageData: {
        scores: 0
      },
      selected: '1',
      bannerLlist: [],
      detailData: { // 详情数据
        desc: '', // 简介
        contracts: [],
        vendor: '' // 厂商

      },
      itemIndex: 0

    }
  },

  methods: {
    init() {
      getAppDetail(this.id).then(d => {
        this.pageData = d.data;
        this.bannerLlist = d.data.images;

        this.detailData.desc = d.data.desc; // 简介
        this.detailData.contracts = d.data.contracts; // 智能合约
        this.detailData.vendor = d.data.vendor; // 厂商
      })
    },

    collect(status) {
      if (status) {
        delDapp({ dapp_id: this.id }).then(d => {
          Toast(d.msg)
          this.init()
        }).catch(err => Toast(err.msg))
      } else {
        scDapp({ dapp_id: this.id }).then(d => {
          Toast(d.msg)
          this.init()
        }).catch(err => Toast(err.msg))
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .detail-box {
    background-color: #f5f5f5;
    overflow: hidden;
    padding-bottom: 100px;
    >.tit {
      font-size: 48px;
      letter-spacing: 0px;
      color: #1f1f1f;
      font-weight: bold;
      margin-top: 40px;
      margin-left: 30px;
      margin-bottom: 40px;
    }
  }
  
  .v-swiper {
    background-color: #fff;
  }
  .video-box {
    display: flex;
    flex-wrap: wrap;
    box-sizing: border-box;
    width: 700px;
    padding: 37px;
    border-radius: 5px;
    margin: auto;
    background-color: #fff;
    >.play {
      width: 665px;
      height: 323px;
      margin: auto;
      > img {
        display: block;
        border-radius: 10px;
        width: 100%;
        height: 100%;
        margin: auto;
      }
    }
    >.select-box {
      // height: 125px;
      padding-bottom: 10px;
      overflow: hidden;
      >.swiper-box {
        white-space: nowrap;
        overflow: auto;
        margin-left: 5px;
        -webkit-overflow-scrolling: touch;
        >.item {
          box-sizing: border-box;
          border: 2PX solid transparent;
          display: inline-block;
          width: 155px;
          height: 125px;
          overflow: auto;
          margin-right: 20px;
          margin-top: 21px;
          border-radius: 10px;
          >img {
            width: 100%;
            height: 100%;
          }
        }
        >.item.act {
          border: 2PX solid $them-color;
        }
      }
    }
  }

  .score {
    display: flex;
    align-items: center;
      width: 720px;
      margin: auto;
    >.num {
      font-weight: bold;
      margin-right: 10px;
      font-size: 30px;
      >.max {
        font-size: 35px;
      }
    }
    >img {
      width: 40px;
      height: 40px;
      margin: 0 2px;
    }
  }
  
  .tab-box {
    margin-top: 20px;
  }

  .tab-font{
    font-size: 30px;
  }

  footer {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  justify-content: space-between;
  height: 100px;
  background-color: #fff;
  >.left {
    display: flex;
    flex-direction: column;
    width: 50%;
    justify-content: center;
    align-items: center;
    color: $them-color;
    > img {
      width: 35px;
    }
  }
  >.right {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 50%;
    background-color: $them-color;
    color: #fff;
    >a {
      color: #fff;
    }
  }
}

  .foot {
    background-color: #fff;
    padding-bottom: 50px;
    width: 700px;
    border-radius: 5px;
    overflow: hidden;
    margin: auto;
  }

  .arr {
    width: 50px;
    margin-left: 30px;
    margin-top: 40px;
  }
</style>

