<template>
  <div>
    <div class="text-doc" id="textDoc">
      <div class="title">
        <slot name="title"></slot>
      </div>
      <div class="doc">
        <slot name="doc"></slot>
      </div>
      <div class="fen">
        <img src="@/assets/img/icon/xing@2x.png" alt="">
        <slot name="fen"></slot>
      </div>
      <div class="b">
        <div class="types">
          <span v-for="item in types" :key="item.cardTypeName">{{item.tags}}</span>
        </div>
        <div class="sc" @click="collect">
          <span>收藏</span>
          <img src="@/assets/img/icon/start.png" v-show="!isCollect" >
          <img src="@/assets/img/icon/start-act.png" v-show="isCollect">
        </div>
      </div>
    </div>
    <!-- <img class="arr-b" v-show="close" @click="close = false" src="@/assets/img/icon/eglass-arrow-down.png" alt=""> -->
  </div>
</template>

<script>
// import { scDapp, delDapp } from '@/api/dapp'
// import { Toast } from 'mint-ui';

export default {
  props: ['types', 'id', 'isSc'],
  watch: {
    isSc() {
      this.isCollect = this.isSc
    }
  },

  data() {
    return {
      isCollect: false,
      close: false
    }
  },

  methods: {
    /**
     * 收藏按钮
     *  */
    collect() {
      this.$emit('collect', this.isCollect)
      // if (this.isCollect) {
      //   delDapp({ dapp_id: this.id }).then(d => {
      //     Toast(d.msg)
      //     this.isCollect = false
      //   }).catch(err => Toast(err.msg))
      // } else {
      //   scDapp({ dapp_id: this.id }).then(d => {
      //     Toast(d.msg)
      //     this.isCollect = true
      //   }).catch(err => Toast(err.msg))
      // }
    }
  }
}
</script>

<style lang="scss" scoped>
  .text-doc {
    width: 700px;
    box-sizing: border-box;
    padding: 25px 25px;
    padding-bottom: 40px;
    position: relative;
    margin: 40px auto;
    background-color: #fff;
    border-radius: 5px;
    >.title {
      font-weight: bold;
      margin-bottom: 30px;
      font-size: 35px;
    }
    >.doc {
      color: #acacac;
      line-height: 36px;
      font-size: 28px;

    }
    >.fen {
      position: absolute;
      right: 30px;
      top: 30px;
      display: flex;
      color: #6c6c6c;
      font-size: 30px;
      >img {
        width: 30px;
        height: 32px;
        margin-right: 20px;
      }
    }
    >.b {
      margin-top: 36px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      >.types {
        > span {
          border-radius: 5px;
          padding: 15px 26px;
          background-color: #eee;
          font-size: 24px;
          color: #232323;
          margin-right: 20px;
        }
      }
      >.sc {
        display: flex;
        align-items: center;
        font-size: 24px;
        color: #6c6c6c;
        >img {
          width: 34px;
          height: 33px;
          margin-left: 16px;
        }
      }
    }
    
  }
  .text-doc.close {
    max-height: 140px;
    overflow: hidden;
  }
  .arr-b {
    width: 40px;
    display: block;
    margin: auto;
  }
</style>


