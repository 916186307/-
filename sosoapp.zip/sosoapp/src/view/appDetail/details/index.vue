<template>
  <div class="scoped">
    <!-- 文字介绍 -->
    <div class="dic">
      <div class="val">{{data.desc}}</div>
    </div>
    <!-- /文字介绍 -->

    <div class="data-box">
      <span class="tit">数据</span>
    </div>

    <div class="data-table">
      <div class="item">
        <div class="item-tit">24h活跃用户</div><div class="num">1307</div>
      </div>
      <div class="item">
        <div class="item-tit">24h交易笔数</div><div class="num">2087</div>
      </div>
      <div class="item r">
        <div class="item-tit">24h交易额</div><div class="num">459.2496</div>
      </div>
      <div class="item">
        <div class="item-tit">7天交易笔数</div><div class="num">16051</div>
      </div>
      <div class="item">
        <div class="item-tit">24h交易额</div><div class="num">869.7977</div>
      </div>
      <div class="item r">
        <div class="item-tit">余额(ETH)</div><div class="num">14.8</div>
      </div>
    </div>

    <div class="detailed-box" :class="{close: close}" ref="detailedBx" id="detailedBx">
      <div class="tit">详细信息</div>
      <div class="list">
        <span class="key">平台</span>
        <span class="val">{{data.vendor}}</span>
      </div>
      <div class="list">
        <span class="key">开发时间</span>
        <span class="val">2018-09-21</span>
      </div>
      <div class="list">
        <span class="key">合约地址</span>
        <span class="val">
          <a href="" v-for="item in data.contracts" :key="item.contracts">{{item.contract}}</a>
        </span>
      </div>
      <div class="show-all" v-show="close" @click="close = false">展开全部</div>
    </div>

  </div>
</template>

<script>
import textDoc from '../textDoc'

export default {
  props: ['data'],
  components: {
    textDoc
  },

  mounted() {
    if (document.getElementById('detailedBx').offsetHeight > 180) {
      this.close = true
    }
  },

  data() {
    return {
      close: false // 详情信息是否展开
    }
  }
}
</script>

<style lang="scss" scoped>
  .scoped {
  }
  .dic {
    width: 651px;
    font-size: 26px;
    /*letter-spacing: 1px;*/
    color: #aeaeae;
    margin: 45px auto 77px;
    text-align:justify;
  }
  .tit {
    font-weight: bold;
    font-size: 26px;
    letter-spacing: 0px;
    color: #1f1f1f;
    margin-bottom: 41px;
    margin-left: 20px;
  }

  .data-box {
    display: flex;
    justify-content: space-between;
    width: 671px;
    margin: 0 0 0 25px;
    >.tit{
      font-size: 28px;
      margin: 0 0 20px 0;
    }
    >.right {
      color: $them-color;
    }
  }

  .data-table {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    width: 645px;
    margin: 1px auto 0;
    margin-left: 25px;
    >.item {
      box-sizing: border-box;
      width: 33.333%;
      text-align: left;
      margin-bottom: 20px;

      // border: 1px solid red;
      >.item-tit {
        /*font-weight: bold;*/
        font-size: 28px;
        color: #1f1f1f;
        >.r{
          padding-left: 20px;
      }
      }
      >.num {
        font-size: 28px;
        color: #b0b0b0;
      }
    }
    >.item:nth-child(2),
    >.item:nth-child(5) {
      text-align: center;
    }
    >.item:nth-child(3),
    >.item:nth-child(6)
     {
      text-align: right;
    }
  }

  .detailed-box {
    position: relative;
    width: 671px;
    margin: 0 auto;
    overflow: hidden;
    >.tit {
      margin: 30px 0;
      margin-left: 10px;
      font-size: 28px;
    }
    >.list {
      display: flex;
      align-items: flex-start;
      >.key {
        display: inline-flex;
        align-items: center;
        width: 180px;
        line-height: 1;
        margin: 10px 0;
        margin-left: 11px;
        font-size: 28px;
      }
      >.val {
        display: inline-block;
        padding-top: 10px;
        vertical-align: top;
        width: 410px;
        color: #777;
        overflow-wrap: break-word;
        font-size: 28px;

        > a {
          display: block;
          color: #777;

        }
      }
    }
    >.show-all {
      position: absolute;
      right: 0;
      bottom: 0;
      text-align: right;
      color: $them-color;
    }
  }

  .detailed-box.close {
    max-height: 300px;
  }


</style>


