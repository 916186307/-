<template>
  <div class="scope">
    <!-- 顶部评论分数 -->
    <div class="head">
      <div class="num-box">
        <div class="left">
          <div class="h1">4.7</div>
          <div class="h2">55人评价</div>
        </div>
        <div class="center">
          <div class="star-row">
            <div class="l">
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
            </div>
            <div class="r"><div class="h" style="width: 90%;"></div></div>
          </div>
          <div class="star-row">
            <div class="l">
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
            </div>
            <div class="r"><div class="h" style="width: 30%;"></div></div>
          </div>
          <div class="star-row">
            <div class="l">
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
            </div>
            <div class="r"><div class="h" style="width: 2%;" ></div></div>
          </div>
          <div class="star-row">
            <div class="l">
              <img src="@/assets/img/icon/start-act.png" >
              <img src="@/assets/img/icon/start-act.png" >
            </div>
            <div class="r"><div class="h" style="width: 1%;"></div></div>
          </div>
          <div class="star-row">
            <div class="l">
              <img src="@/assets/img/icon/start-act.png" >
            </div>
            <div class="r"><div class="h" style="width: 0%;"></div></div>
          </div>

        </div>
      </div>
    </div>
    <!-- /顶部评论分数 -->

    <!-- 评论框 -->
    <div class="texde-box">
      <textarea placeholder="说点什么吧"></textarea>
      <div class="btn">发布</div>
    </div>
    <!-- /评论框 -->

    <!-- 评论列表 -->
    <div class="comment-list">
      <div class="sun">评论30</div>
      <div class="item" v-for="item in commentList" :key="item.cardTypeName">
        <div class="item-h">
          <div class="left">
            <img class="user-head" src="@/assets/img/image/b1.png" >
            <div class="txt">
              <div class="h1">jack</div>
              <div class="h2">13小时前</div>
            </div>
          </div>
          <div class="right">
            <img src="@/assets/img/icon/zan.png" ><span v-text="item.zanNum"></span>
            <img src="@/assets/img/icon/msg.png" ><span v-text="item.starNum"></span>
          </div>
        </div>
        <div class="start-box">
          <img src="@/assets/img/icon/start-act.png" >
          <img src="@/assets/img/icon/start-act.png" >
          <img src="@/assets/img/icon/start-act.png" >
          <img src="@/assets/img/icon/start-act.png" >
          <img src="@/assets/img/icon/start-act.png" >
        </div>
        <div class="pl-box">
          <span v-text="item.plVal"></span>
        </div>
      </div>

    </div>
    <!-- /评论列表 -->

  </div>
</template>

<script>
export default {
  data() {
    return {
      commentList: [
        { headSrc: '', zanNum: 2, msgNum: 1, starNum: 1, plVal: '试试，体验一下' },
        { headSrc: '', zanNum: 56, msgNum: 1, starNum: 1, plVal: '试试2，体验一下' },
        { headSrc: '', zanNum: 2, msgNum: 1, starNum: 1, plVal: '试3试，体验一下' }
      ]
    }
  }
}
</script>

<style lang="scss" scoped>
  // 评论分数
  .head {
    width: 720px;
    margin: 40px auto 50px;
    >.tit {
      font-weight: bold;
      font-size: 30px;
    }
    >.num-box {
      margin-top: 40px;
      width: 500px;
      margin: auto;
      display: flex;
      justify-content: space-between;
      >.left {
        text-align: center;
        width: 23.333%;
        >.h1 {
          font-weight: bold;
          font-size: 36px;
          color: #1c1c1c;
        }
        >.h2 {
          font-size: 24px;
          margin-top: 10px;
          color: #b5b5b5;
        }
      }
      >.center {
        width: 43.333%;
        >.star-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          >.l {
            width: 250px;
            display: flex;
            flex-direction: row-reverse;
            img {
              width: 24px;
              height: 24px;
            }
          }
          >.r {
            width: 100%;
            margin-left: 30px;
              height: 10px;
            > .h {
              height: 10px;
              border-radius: 10px;
              background-color: #f5c000;
            }
          }
        }
      }
      >.right {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 23.333%;
        color: $them-color;
        font-size: 30px;
      }
    }
  }

  .texde-box {
    overflow: hidden;
    >textarea {
      box-sizing: border-box;
      display: block;
      padding: 20px 15px;
      border: none;
      outline: none;
      margin: auto;
      width: 667px;
      height: 201px;
      background-color: #eee;
      border-radius: 10px;
    }
    >.btn {
      text-align: center;
      line-height: 49px;
      width: 131px;
      height: 49px;
      background-color: #37d4e2;
      border-radius: 10px;
      color: #fff;
      float: right;
      margin-top: 40px;
      margin-right: 38px;
    }
  }

  // 评论列表
  .comment-list {
    width: 671px;
    margin: auto;
    >.sun {
      font-size: 24px;
      line-height: 40px;
      letter-spacing: 0px;
      color: #8f8f8f;
      margin-left: 20px;
    }
    >.item {
      margin: 20px auto;
      padding-bottom: 40px;
      border-bottom: 2px solid #eee;
      >.item-h {
        display: flex;
        justify-content: space-between;
        align-items: center;
        >.left {
          display: flex;
          width: 220px;
          justify-content: space-between;
          align-items: center;
          >.user-head {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin-left: 20px;
          }
          >.txt {
            >.h1 {
              font-weight: bold;
              font-size: 25px;
            }
            >.h2 {
              margin-top: 10px;
              color: #777;
            }

          }
        }
        >.right {
          display: flex;
          justify-content: space-between;
          width: 120px;
          color: #777;
          margin-right: 20px;
          >img {
            width: 30px;
            height: 30px;
          }
        }
      }
      >.start-box {
        margin: 20px 0 0 120px;
        >img {
          width: 30px;
          height: 30px;
        }
      }
      >.pl-box {
        margin: 20px 0 0 120px;
        font-size: 29px;
      }
    }
  }
</style>


