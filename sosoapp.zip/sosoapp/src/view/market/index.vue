<template>
  <div>
    <!--search-->
    <!-- <head-search></head-search> -->
    <div class="search-head">
      <input placeholder="Search" v-model="name"  type="search" @input="searchInput" @keyup.13="search">
      <img class="search" src="@/assets/img/icon/search.png" >
      <img class="ling" src="@/assets/img/icon/ling.png" >
    </div>

    <div class="sort-box">
      <div class="tiem" @click="listSort('key')">
        <span>名字</span>
      </div>
      <div class="tiem" @click="listSort('current_price')">
        <span>价格</span>
        <img class="updown" src="static/home/market-updown.png" alt="">
      </div>
      <div class="tiem" @click="listSort('change_percent')">
        <span>涨跌幅</span>
        <img class="updown" src="static/home/market-updown.png" alt="">
      </div>
    </div>

    <ul class="bottom-list" v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
      <li v-for="item in bottomList" :key="item.cardTypeName">
        <div class="left">
          <div class="l-b">
            <div class="e h">币种</div>
            <div class="e h ce">价格</div>
            <div class="e h ri">涨跌幅</div>
            <div class="b">{{item.name}}</div>
            <div class="n">￥{{item.current_price}}</div>
            <div class="btc" :class="{red: item.change_percent > 0 , green: item.change_percent < 0 }">{{item.change_percent}}%</div>
          </div>
        </div>
      </li>
    </ul>

    <div class="b" v-show="loading">
      <mt-spinner type="double-bounce"></mt-spinner>
    </div>

  </div>
</template>

<script>
  import headSearch from '@/components/header'
  import { Toast } from 'mint-ui'
  import { getDappData } from '@/api/dapp'
  import { pageInfo } from '@/utils/mixins'
  let timer = null
  export default {
    mixins: [pageInfo],
    components: {
      headSearch
    },
    data() {
      return {
        loading: false,
        sortStatus: false,
        iserr: false,
        name: '',
        b1: false,
        b1val: '24小时用户',
        bottomList: []
      }
    },

    created() {
      this.init()
    },
    methods: {
      init() {
        this.loading = true
        getDappData({
          name: this.name,
          page: this.pageInfo.page,
          limits: this.pageInfo.limits
        }).then(d => {
          this.loading = false
          for (const ele of d.data) {
            this.bottomList.push(ele)
          }
        }).catch(err => {
          Toast('加载错误' + err.msg)
          this.loading = false
          this.iserr = true
          return false
        })
      },

      loadMore() {
        if (this.iserr) return
        this.pageInfo.page++
        this.init()
      },

      search() {
        this.pageInfo.page = 1
        this.loading = true
        this.iserr = false
        getDappData({
          name: this.name,
          page: this.pageInfo.page,
          limits: this.pageInfo.limits
        }).then(d => {
          this.loading = false
          this.bottomList = d.data
        }).catch(() => {
          this.loading = false
          return false
        })
      },

      searchInput() {
        clearTimeout(timer)
        timer = setTimeout(() => {
          this.search()
        }, 400)
      },

      listSort(key) {
        this.sortStatus = !this.sortStatus
        this.bottomList.sort((a, b) => {
          if (this.sortStatus) {
            return a[key] - b[key]
          } else {
            return b[key] - a[key] 
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .top-head {
    position: relative;
    display: flex;
    justify-content: space-between;
    font-size: 30px;
    padding: 10px;

    >input {
      box-sizing: border-box;
      padding: 10px 70px 0 70px;
      line-height: 1;
      width: 603px;
      height: 76px;
      border-radius: 15PX;
      border: none;
      outline: none;
      background-color: #fff;
      margin: 30px auto 0;
    }
    img {
      position: absolute;
      left: 89px;
      top: 60px;
      width: 40px;
      height: 40px;
    }
  }

  .sort-box {
    box-sizing: border-box;
    padding: 0 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 710px;
    height: 100px;
    margin: 40px auto 0;
    background-color: #fff;
    // border: 1px solid #eee;
    border-radius: 5PX;
    // box-shadow: 0 10px 16px -16px rgba(174,174,174,1);
    font-size: 28px;
    >.tiem {
      display: flex;
      align-items: center;
    }
  }

  .input-box {
    box-sizing: border-box;
    margin-bottom: 20px;
    padding: 15px;
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    float: right;
    background-color: #fff;
    border-bottom: 1px solid #eaeaea;
    >.left {
      >img {
        vertical-align: middle;
        margin-left: 20px;
        width: 40px;
        height: 40px;
      }
    }
    img {
      width: 50px;
      height: 50px;
    }
    input {
      padding: 20px;
      outline: none;
      border: none;
      border: 1px solid #eaeaea;
      border-radius: 10PX;
    }
  }

  .btn {
    padding: 0 10px;
    background-color: $them-color;
    border-radius: 5PX;
    img {
      width: 40px;
      height: 40px;
    }
  }

  .select-box {
    box-sizing: border-box;
    padding: 40px 30px;
    width: 720px;
    height: 1000px;
    background-color: #fff;
    >.tit {
      color: #999;
      font-size: 38px;
    }
    >.row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 40px 0;
      height: 70px;
      >.left {
        font-size: 35px;
        color: #111;
      }
      >.right {
        position: relative;
        height: 80px;
        width: 300px;
        text-align: right;
        overflow: hidden;
        >.mint-switch {
          width: 50PX;
          float: right;
        }
        >select {
          display: inline-block;
          appearance: none;
          width: 200px;
          line-height: 80px;
          margin-top: 20px;
          outline: none;
          border: none;
          text-align: right;
          direction: rtl;
          > option {
            outline: none;
            border: none;
            z-index: 999;
          }
        }
      }
    }
  }

  .bottom-list {
    padding: 20px;
    >li {
      height: 200px;
      width: 100%;
      box-sizing: border-box;
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
      // border: 1px solid #eee;
      border-radius: 5PX;
      padding: 30px;
      background-color: #fff;
      // box-shadow: 0 10px 16px -16px rgba(174,174,174,1);
      >.left {
        display: flex;
        align-content: center;
        width: 100%;
        >.name {
          font-weight: bold;
          font-size: 35px;
        }
        >.star {
          display: flex;
          align-items: center;
          color: #a1a1a1;
          >img {
            width: 25px;
            height: 25px;
          }
          >span {
            display: inline-block;
            margin-left: 30px;
          }
        }
        >.l-b {
          width: 100%;
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          >.e {
            width: 33%;
          }
          >.h {
            color: rgb(170,170,170);
            margin-bottom: 10px;
            width: 33%;
          }
          >.n {
            color: $them-color;
            font-size: 30px;
            width: 33%;
            text-align: center;
            text-indent: 20px;
          }
          >.b{
            /*font-weight: bold;*/
            font-size:35px;
          }
          >.btc{
            background-color :rgb(55,212,226) ;
            border-radius:5px;
            text-align: center;
            line-height: 2;
            width: 120px;
            height: 60px;
            color: white;
            font-size:30px;
          }
          >.btc.green {
            background-color: rgba(87,161,134,1);
          }
          >.btc.red {
            background-color: rgba(240,94,98,1);
            
          }
          >.ce{
            text-align: center;
          }
          >.ri{
            text-align: right;
          }
        }
      }
      >.right {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 120px;
        > img {
          width: 100px;
          height: 100px;
          border-radius: 50%;
        }
      }
    }
  }

  .tab-box {
    img {
      display: inline-block;
      vertical-align: middle;
      width: 30px;
      height: 30px;
    }
  }

  .updown{
    width: 25px;
    height: 25px;
  }

  .b {
    display: flex;
    justify-content: center;
  }

.search-head {
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 30px;
  padding: 10px 20px;
  margin: 10px 0 0 30px;
  overflow: hidden;
  >input {
    box-sizing: border-box;
    padding: 10px 70px 0 70px;
    line-height: 1;
    width: 633px;
    height: 76px;
    border-radius: 15px;
    border: none;
    outline: none;
    background-color: #fff;
    margin-right: 60px;
  }
  >input[href=placeholder] {
    color: #aeaeaa;
  }
  >.search {
    position: absolute;
    left: 39px;
    top: 30px;
    width: 40px;
    height: 40px;
  }
  >.ling {
    margin-right: 30px;
    width: 34px;
    height: 44px;
  }
}


</style>
