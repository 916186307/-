<template>
  <div class="foots-box" >
    <keep-alive>
      <router-view class="home-route"></router-view>
    </keep-alive>

    <div class="footer" >
      <div v-for='(item,index) of items'   :key="index" @click="toRoute(item.push,item.indexs)" :class="{act: idx === index}">
        <!-- <img :src="$route.path===item.cls?item.iconSelect:item.icon"> -->
        <div class="img" :style="`background-image: url(${$route.path===item.cls?item.iconSelect:item.icon})`"></div>
        <p :class="['colorChange',{on:$route.path===item.cls}]">{{item.name}}</p>
      </div>
    </div>

  </div>
</template>

<script type="text/javascript">

export default {
  data() {
    return {
      idx: 0,
      items: [{
        cls: '/home',
        name: '首页',
        push: 'Home',
        indexs: 0,
        icon: 'static/home/home-new.png',
        iconSelect: 'static/home/home-new-c.png'
      },
      {
        cls: '/sort',
        name: '排行榜',
        push: 'Sort',
        indexs: 1,
        icon: 'static/home/rank.png',
        iconSelect: 'static/home/rank-c.png'
      },
      {
        cls: '/market',
        name: '行情',
        push: 'market',
        indexs: 2,
        icon: 'static/home/sort-new.png',
        iconSelect: 'static/home/sort-new-c.png'
      },
      {
        cls: '/assets',
        name: '资产',
        push: 'Assets',
        indexs: 3,
        icon: 'static/home/money-new.png',
        iconSelect: 'static/home/money-new-c.png'
      },
      {
        cls: '/my',
        name: '我的',
        push: 'My',
        indexs: 4,
        icon: 'static/home/my-new.png',
        iconSelect: 'static/home/my-new-c.png'
      }
      ]
    }
  },
  mounted() {
    this.idx = this.$store.state.homeIndex
  },
  methods: {
    toRoute(name, indexs) {
      this.idx = indexs
      this.$store.commit('SET_homeIndex', indexs)
      this.$router.push({
        name: name
      })
    }
  }
}

</script>
<style lang="scss" scoped>
.foots-box {
  position: relative;
  height: 100%;
  background-color: #f5f5f5;
}
.home-route {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 130px;
  left: 0;
  overflow: auto;
  -webkit-overflow-scrolling: touch;
}
.footer {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  margin: auto;
	display: flex;
	box-sizing: border-box;
  width: 750px;
	height: 130px;
  margin: auto;
	background-color: #fff;
	box-shadow: 0 -5px 30px 0	rgba(4, 0, 0, 0.1);
  z-index: 10;
  div {
    position: relative;
    flex: 1;
    transition: all .2s ease;
    transform: scale(1);
    transform-origin: 50% 50%;
    .img {
      height: 90px;
      background-size: 40px 40px;
      background-position: center center;
      background-repeat: no-repeat;
      transition: all .4s ease;
    }
  }
  // div.act {
  //   transform: scale(1.2);
  // }
  div p{
    position: absolute;
    right: 0;
    bottom: 0;
    left: 0;
    height: 30px;
    color: #717171;
    font-size: 22px;
    line-height: 36px;
    text-align: center;
  }
  div img{
    position: absolute;
    top: 0;
    right: 0;
    bottom: 36px;
    left: 0;
    margin: auto;
	}
	.on{
		color: $them-color;
	}
	div:nth-child(1) img{
		width: 46px;
	  height: 47px;
	}
  div:nth-child(2) img{
		width: 35px;
	  height: 40px;
  }
  div:nth-child(3) img{
		width: 47px;
	  height: 47px;
  }
  div:nth-child(4) img{
		width: 38px;
	  height: 40px;
	}
  div:nth-child(5) img{
		width: 40px;
	  height: 40px;
	}
  div:nth-child(6) img{
		width: 40px;
	  height: 40px;
	}
}


</style>
