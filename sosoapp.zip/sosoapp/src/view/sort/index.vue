<template>
  <div>
    <!--search模块-->
    <head-search></head-search>

    <div class="clear"></div>

    <!--top-->
    <keep-alive>
      <router-view class="home-route"></router-view>
    </keep-alive>
    <div class="footer">
      <div>
        <img src="static/home/tab-yz-c.png">
        <p class="colorChange act">柚子</p>
      </div>
      <div>
        <img src="static/home/tab-bc.png">
        <p class="colorChange">波场</p>
      </div>
      <div>
        <img src="static/home/tab-yt.png">
        <p class="colorChange">以太坊</p>
      </div>
    </div>

    <ul class="bottom-list"  v-infinite-scroll="loadMore" infinite-scroll-disabled="loading" infinite-scroll-distance="10">
      <li v-for="item in bottomList" :key="item.cardTypeName" >
        <div class="left">
          <div class="name">{{item.name}}</div>
          <div class="star">
            <img v-for="n in Math.floor(item.score)" :key="n.number" src="@/assets/img/icon/start.png" alt="">
            <span v-for="e in item.tags" :key="e.cardTypeName">{{e}}</span>
            <span>抽奖</span>
          </div>
          <div class="l-b">
            <div class="e h">24H用户</div>
            <div class="e h">24H交易数</div>
            <div class="e h">24H交易额</div>
            <div class="e n">{{item.statistics.ua_of_24hours}}</div>
            <div class="e n">{{item.statistics.tx_of_24hours}}</div>
            <div class="e n">{{item.statistics.tx_of_7days}}</div>
          </div>
        </div>
        <div class="right">
          <img :src="item.logo" >
        </div>
      </li>
    </ul>

    <div class="b" v-show="loading">
      <mt-spinner type="double-bounce"></mt-spinner>
    </div>

  </div>
</template>

<script>
import headSearch from '@/components/header';
import { getTop } from '@/api/dapp'
export default {
  components: {
    headSearch
  },
  data() {
    return {
      loading: false,
      pageInfo: {
        page: 1,
        limits: 100,
        total: 0
      },
      selected: '1',
      bottomList: [],
      indexs: 0,
      idx: 0,
      items: [
        {
          cls: '/tab-yz',
          name: '柚子',
          push: 'tab-yz',
          indexs: 0,
          icon: 'static/home/tab-yz.png',
          iconSelect: 'static/home/tab-yz-c.png'
        },
        {
          cls: '/tab-bc',
          name: '波场',
          push: 'tab-bc',
          indexs: 1,
          icon: 'static/home/tab-bc.png',
          iconSelect: 'static/home/tab-bc-c.png'
        },
        {
          cls: '/tab-yt',
          name: '以太坊',
          push: 'tab-yt',
          indexs: 2,
          icon: 'static/home/tab-yt.png',
          iconSelect: 'static/home/tab-yt-c.png'
        }
      ]
    }
  },
  created() {
    this.init()
  },

  mounted() {
    this.idx = this.$store.state.homeIndex
  },
  methods: {
    toRoute(name, indexs) {
      this.idx = indexs
      this.$store.commit('SET_homeIndex', indexs)
      this.$router.push({
        name: name
      })
    },

    init() {
      this.loading = true
      getTop({
        page: this.pageInfo.page,
        limits: this.pageInfo.limits
      }).catch(d => {
        this.loading = false
        for (const ele of d.data) {
          this.bottomList.push(ele)
        }
      })
    },

    loadMore() {
      // this.pageInfo.page++
      // this.init()
    }
  }
}
</script>

<style lang="scss" scoped>
  .input-box {
    box-sizing: border-box;
    margin-bottom: 20px;
    padding: 15px;
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    float: right;
    background-color: #fff;
    border-bottom: 1px solid #eaeaea;
    >.left {
      >img {
        vertical-align: middle;
        margin-left: 20px;
        width: 40px;
        height: 40px;
      }
    }
    img {
      width: 50px;
      height: 50px;
    }
    input {
      padding: 20px;
      outline: none;
      /*border: none;*/
      border: 1px solid #eaeaea;
      border-radius: 10PX;
    }
  }

  .btn {
    padding: 0 10px;
    background-color: $them-color;
    border-radius: 5PX;
    img {
      width: 40px;
      height: 40px;
    }
  }

  .select-box {
    box-sizing: border-box;
    padding: 40px 30px;
    width: 720px;
    height: 1000px;
    background-color: #fff;
    >.tit {
      color: #999;
      font-size: 38px;
    }
    >.row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 40px 0;
      height: 70px;
      >.left {
        font-size: 35px;
        color: #111;
      }
      >.right {
        position: relative;
        height: 80px;
        width: 300px;
        text-align: right;
        overflow: hidden;
        >.mint-switch {
          width: 50PX;
          float: right;
        }
        >select {
          display: inline-block;
          appearance: none;
          width: 200px;
          line-height: 80px;
          margin-top: 20px;
          outline: none;
          border: none;
          text-align: right;
          direction: rtl;
          > option {
            outline: none;
            border: none;
            z-index: 999;
          }
        }
      }
    }
  }

  .bottom-list {
    /*padding: 10px;*/
    >li {
      box-sizing: border-box;
      display: flex;
      justify-content: space-between;      
      margin-top: 7pt;
      // border: 1px solid #eee;
      border-radius: 5PX;
      padding: 20px 0 20px 20px;
      background-color: #fff;
      width: 710px;
      margin: auto;
      margin-bottom: 10px;
      // box-shadow: 0 10px 16px -16px rgba(174,174,174,1);
      >.left {
        width: 550px;
        >.name {
          margin: 2px;
          font-weight: bold;
          font-size: 30px;
        }
        >.star {
          display: flex;
          align-items: center;
          color: #a1a1a1;
          font-size: 20px;
          margin-bottom: 20px;
          >img {
            width: 25px;
            height: 25px;
          }
          >span {
            display: inline-block;
            margin-left: 30px;
            padding: 5px 10px;
            border-radius: 5px;
            background-color: #eee;
          }
        }
        >.l-b {
          margin: 10px;
          display: flex;
          justify-content: space-between;
          flex-wrap: wrap;
          >.e {
            width: 33.333%;
          }
          >.h {
            font-size: 24px;
            color: #111;
            margin-bottom: 10px;
          }
          >.n {
            font-size: 24px;
            color:rgb(130,130,130);
          }
        }
      }
      >.right {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 120px;
        padding-right: 50px;
        > img {
          width: 50pt;
          height: 50pt;
          border-radius: 5PX;
        }
      }
    }  
  }

  .tab-box{

    height: 150px;
    background-color: RGB(238,238,238);
  }
  .tab-box {
    img {
      line-height: 50px;
      display: inline-block;
      vertical-align: middle;
      width: 30px;
      height: 30px;
    }
  }
  .top-head {
    position: relative;
    display: flex;
    justify-content: space-between;
    font-size: 30px;
    padding: 10px;
    color: RGB(238,238,238);
    >input {
      box-sizing: border-box;
      padding: 10px 70px 0 70px;
      line-height: 1;
      width: 603px;
      height: 76px;
      border-radius: 15PX;
      border: none;
      outline: none;
      background-color: #fff;
      margin: 30px auto 0;
    }
    img {
      position: absolute;
      left: 89px;
      top: 60px;
      width: 40px;
      height: 40px;
    }
  }

  .foots-box {
    position: relative;
    height: 100%;
    background-color: #eee;
  }
  .home-route {
    /*position: absolute;*/
    /*top: 0;*/
    /*right: 0;*/
    /*bottom: 130px;*/
    /*left: 0;*/
    overflow: auto;
    -webkit-overflow-scrolling: touch;
  }
  .footer {
    /*position: fixed;*/
    /*right: 0;*/
    /*top: 0;*/
    /*left: 0;*/
    margin: auto;
    display: flex;
    box-sizing: border-box;
    width: 750px;
    height: 130px;
    margin: auto;
    // background-color: RGB(238,238,238);
    >.colorChange {
      font-size: 24px;
    }
    .act {
      color:  #49d7e4;
    }
    div {
      position: relative;
      flex: 1;
    }
    div p{
      position: absolute;
      right: 0;
      bottom: 0;
      left: 0;
      height: 30px;
      color: #717171;
      font-size: 22px;
      line-height: 36px;
      text-align: center;
    }
    div img{

      width: 17pt;
      height: 21pt;
      position: absolute;
      top: 0;
      right: 0;
      bottom: 36px;
      left: 0;
      margin: auto;
    }
    .on{
      color: $them-color;
    }
    div:nth-child(1) img{
      width: 28px;
      height: 41px;
    }
    div:nth-child(2) img{
      width: 33px;
      height: 39px;
    }
    div:nth-child(3) img{
      width: 26px;
      height: 43px;
    }
    div:nth-child(4) img{
      width: 46px;
      height: 49px;
    }
    div:nth-child(5) img{
      width: 48px;
      height: 49px;
    }
    div:nth-child(6) img{
      width: 48px;
      height: 48px;
    }
  }

  .b {
    display: flex;
    justify-content: center;
  }
</style>
