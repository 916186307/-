// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import './styles/index.scss' // global css
import 'lib-flexible/flexible.js'
import VueI18n from 'vue-i18n'
import LangEn from './lang/en' 
import LangCH from './lang/zh'
import Mint from 'mint-ui'
import Loading from './components/loading/index'
import 'mint-ui/lib/style.min.css'
import filters from './utils/filter'
Object.keys(filters).forEach(k => Vue.filter(k, filters[k]));
Vue.use(Mint);
Vue.use(Loading)

const i18n = new VueI18n({
  locale: 'en',
  messages: {
    'en': LangEn,
    'zhCH': LangCH
  }
})

Vue.filter()

// 务必在加载 Vue 之后，立即同步设置以下内容 配置是否允许 vue-devtools 检查代码
Vue.config.devtools = true
// 设置为 false 以阻止 vue 在启动时生成生产提示
Vue.config.productionTip = false
// 设置为 true 以在浏览器开发工具的性能/时间线面板中启用对组件初始化、编译、渲染和打补丁的性能追踪。只适用于开发模式和支持 performance.mark API 的浏览器上。
Vue.config.performance = true

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  i18n,
  components: { App },
  template: '<App/>'
})
