export default {

  button: {
    payBtn: 'pay'
  }
}
