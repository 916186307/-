export default {
 
  button: {
    payBtn: '去支付'
  }
}
