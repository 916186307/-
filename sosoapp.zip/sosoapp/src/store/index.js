import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    token: '',
    username: '', // 账号
    password: '', // 密码
    userInfo: {
      avatar: '',
      nickname: '',
      phone: '',
      sex: ''
    },
    menu: {
      my: 1, // 1 我的收藏 2 系统设置
      assets: 1, // 1 资产 2 交易
      suborder: 1 // 1 资产 2 交易
    },
    footerShow: true
  },
  mutations: {
    setToken(state, token) {
      state.token = token
    },
    setUsername(state, username) {
      state.username = username
    },
    setPassword(state, password) {
      state.password = password
    },
    setUserInfo(state, userInfo) {
      state.userInfo = userInfo
    },
    setMenu(state, menu) {
      state.menu = menu
    },
    setFooterShow(state, footerShow) {
      state.footerShow = footerShow
    }
  },
  plugins: [createPersistedState()]
})

export default store
