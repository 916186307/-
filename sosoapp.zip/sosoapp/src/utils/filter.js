exports.voerfllow = (value) => {
  if (value.length <= 10) {
    return value
  } else {
    return value.substr(1, 6) + '...'
  }
}

exports.voerfllow50 = (value) => {
  if (value.length <= 50) {
    return value
  } else {
    return value.substr(1, 50) + '...'
  }
}

exports.toFixed2 = (value) => {
  return value.toFixed(2)
}

exports.toFixed4 = (value) => {
  return value.toFixed(4)
}
