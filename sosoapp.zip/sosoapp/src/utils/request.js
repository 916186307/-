import axios from 'axios'
import store from '../store'
// import { Indicator } from 'mint-ui';

// 创建axios实例
const service = axios.create({
  baseURL: 'https://api.sosodapp.io/',
  timeout: 5000 // 请求超时时间
})

// request拦截器
service.interceptors.request.use(
  config => {
    let token = store.state.token;
    if (token) { 
      config.headers.Authorization = 'Bearer' + token;
    }
    return config
  },
  err => {
    return Promise.reject(err);
  })

// respone拦截器
service.interceptors.response.use(
  response => {
    // store.commit('SET_LOADING', true)
    const res = response.data
    // Indicator.close()
    if (res.code !== 200) {
      return Promise.reject(res)
    } else {
      setTimeout(() => {
        store.commit('SET_LOADING', false);
      }, 300);
      return response.data
    }
  },
  error => {
    return Promise.reject(error)
  }
)

export default service
