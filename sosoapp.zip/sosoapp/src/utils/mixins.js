exports.pageInfo = {
  data() {
    return {
      pageInfo: {
        limits: 15,
        page: 1,
        total: 0
      }
    }
  }
}
